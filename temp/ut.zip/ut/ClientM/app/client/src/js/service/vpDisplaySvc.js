// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('vpServiceModule')

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpDisplaySvc
 * @description this service will provide methods to manipulate display.
 */

.factory('vpDisplaySvc', [
    '$q',
    'vpAdminDataSvc',
    'vpErrorHandlerSvc',
    function ($q, vpAdminDataSvc, vpErrorHandlerSvc) {
        "use strict";
        return {

            /**
             * @ngdoc method
             * @name vpServiceModule.vpDisplaySvc#getDisplayList
             * @methodOf vpServiceModule.vpDisplaySvc
             * @param  {boolean} forceUpdated whether  to fetch the updated data
             * @returns {object} Promise
             * @description this method will return display list as a promise
             */

            getDisplayList: function (forceUpdated) {
                var that = this;
                if (that._displayListModule && !forceUpdated) {
                    return $q.when(that._displayListModule);
                }

                return vpAdminDataSvc.getDisplayList().then(function (data) {
                    that._displayListModule = that._initDisplayList(data, data.parsedTree);
                    return that._displayListModule;
                }, function (error) {
                    vpErrorHandlerSvc.propagate(error);
                });
            },

            _initDisplayList: function (data, root) {
                var types = {
                    AREA: 1,
                    DISPLAY: 2
                };

                var iconPaths = {
                    AREA: 'ra-icon-folder',
                    DISPLAY: 'ra-icon-visualization-display'
                };

                var sortAlphaBetically = function (array, propName, desc) {
                    if(!array || !angular.isArray(array) || !array.length) {
                        return false;
                    }

                    return array.sort(function (item1, item2) {
                        var prop1 = item1[propName].toLowerCase();
                        var prop2 = item2[propName].toLowerCase();
                        var ret = desc ? 1 : -1;

                        if (prop1 < prop2){ return ret;}
                        if (prop1 > prop2){ return  -ret;}
                        return 0;
                    });
                };

                return {
                    isDisplay: function  (item) {
                        return item.type && item.type === types.DISPLAY;
                    },

                    getContainerItem: function (areaPaths) {
                        if (!areaPaths) {
                            return root;
                        }

                        areaPaths = areaPaths.replace(/^\/*/, '').split(/\/+/);
                        var container = root;
                        var area = '', areaId;

                        while(areaPaths.length && container){
                           area = areaPaths.shift();
                           areaId = container.arl.areaNameToIds && container.arl.areaNameToIds[area];
                           if (areaId === undefined) {
                                continue;
                           }

                           container = container.arl[areaId];
                        }

                        return container;
                    },

                    getDisplayUrl: function(stateParams, rawLink) {
                        var search = '';
                        if (stateParams) {
                            search = 'raml=' +
                                     stateParams.displayName +
                                     '&area=' +
                                     '/' + stateParams.areaIds;

                        } else if (rawLink) {
                            search = rawLink;
                        }

                        return '/ftvp/m/graphics/index.html?' + search;
                    },

                    getChildItems: function (areaPaths) {
                        var list1 = [];
                        var list2 = [];
                        var areaName = '';
                        var containerItem = this.getContainerItem(areaPaths);

                        if (!containerItem) {
                            return false;
                        }

                        if (containerItem.childList) {
                            return containerItem.childList;
                        }

                        if (containerItem && containerItem.arl) {
                            angular.forEach(containerItem.arl, function(item){
                                areaName = containerItem.fullName || '/';
                                list1.push({
                                    Name: item.an,
                                    areaName: areaName,
                                    label: item.an,
                                    type: types.AREA,
                                    iconClasses: iconPaths.AREA,
                                    hasChevron: true
                                });
                            });

                            sortAlphaBetically(list1, 'Name');
                        }

                        if (containerItem && containerItem.dl) {
                            angular.forEach(containerItem.dl, function (item) {
                                areaName = containerItem.fullName || '/';
                                var displayName = item.dn;
                                list2.push({
                                    Name: displayName,
                                    areaName: areaName,
                                    label: displayName,
                                    type: types.DISPLAY,
                                    iconClasses: iconPaths.DISPLAY,
                                    hasChevron: true
                                });
                            });

                            sortAlphaBetically(list2, 'Name');
                        }

                        containerItem.childList = list1.concat(list2);
                        return containerItem.childList;
                    },

                    getDisplayCount: function() {
                        return data.count;
                    }
                };
            }
        };
    }
]);