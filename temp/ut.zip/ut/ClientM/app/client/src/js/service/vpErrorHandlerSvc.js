// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('vpServiceModule')

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpErrorHandlerSvc
 * @description this service will provide error handling related methods.
 */

.provider('vpErrorHandlerSvc', [
    '$httpProvider',
    'raErrorCollectorSvcProvider',
    function ($httpProvider, raErrorCollectorSvcProvider) {
        "use strict";

        this.config = function () {
            raErrorCollectorSvcProvider.setCommunicationErrorCtrlName('vpHTTPErrorCtrl');
            raErrorCollectorSvcProvider.setGeneralErrorCtrlName('vpGeneralErrorCtrl');

            // Registering raHttpErrorInterceptorSvc
            $httpProvider.interceptors.push('raHttpErrorInterceptorSvc');
        };

        this.$get = [
            '$log',
            'raErrorListenersSvc',
            'raErrorHandlerSvc',
            'raErrorCollectorSvc',
            function ($log, raErrorListenersSvc, raErrorHandlerSvc, raErrorCollectorSvc) {
                var myErrorListener = function ($event, exception, cause, target) {
                    if (!exception.isHandled && !raErrorHandlerSvc.isRAHTTPError(exception)) {
                        if (target === '$log') {
                            $log.error(exception.message);
                            raErrorHandlerSvc.markAsHandled(exception);
                        } else {
                            raErrorCollectorSvc.addError(exception,
                                raErrorHandlerSvc.ui.isErrorButtonsList(target) ? target.errorButtonList : "");
                        }
                    }
                };

                return {

                    /**
                     * @ngdoc method
                     * @name vpServiceModule.vpErrorHandlerSvc#start
                     * @methodOf vpServiceModule.vpErrorHandlerSvc
                     * @param none
                     * @returns none
                     * @description initialize the errorhandler service.
                     */
                    start: function () {
                        this.errorListener = raErrorListenersSvc.addFirst(
                            raErrorHandlerSvc.events.ERROR_APPEARED,
                            myErrorListener
                        );
                    },

                    /**
                     * @ngdoc method
                     * @name vpServiceModule.vpErrorHandlerSvc#getHTTPError
                     * @methodOf vpServiceModule.vpErrorHandlerSvc
                     * @param {string} reason the error reason
                     * @param {string} error  the error description
                     * @returns httperror insance
                     * @description return the RAHTTPError instance
                     */
                    getHTTPError: function (reason, error) {
                        error = error || "Navigation service connection error";
                        return raErrorHandlerSvc.getRAHTTPError(error, reason);
                    },

                    /**
                     * @ngdoc method
                     * @name vpServiceModule.vpErrorHandlerSvc#propagate
                     * @methodOf vpServiceModule.vpErrorHandlerSvc
                     * @param {Error|RAError|RAHTTPError} exception Error object
                     * @param {*} [cause] Optional information about the context
                     * in which the error was thrown
                     * @param {*} [target] Address the recipient of the error
                     * @returns none
                     * @description throw the RAError instance up.
                     */
                    propagate: function (error, cause, target) {
                        if (!raErrorHandlerSvc.isRAError(error)) {
                            error = raErrorHandlerSvc.getRAError(error, '');
                        }

                        raErrorHandlerSvc.propagate(error, cause, target || '$log');
                    },

                    trace: function (msg) {
                        console.log(msg);
                    }
                };
            }
        ];
    }
])
.config([
    'vpErrorHandlerSvcProvider',
    function (vpErrorHandlerSvcProvider) {
        "use strict";
        vpErrorHandlerSvcProvider.config();
    }
]);