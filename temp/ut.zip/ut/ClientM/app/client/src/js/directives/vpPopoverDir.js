/*global angular*/
(function() {
  'use strict';

  angular.module('vpDirectiveModule')
    .directive('vpPopover', vpPopoverDirective)
    .controller('vpPopoverController', vpPopoverController);

  var popoverTemplate = [
    '<div class="vp-popover">',
      '<div class="vp-popover-content">',
      '',
      '</div>',
      '<div class="vp-popover-arrow"></div>',
    '</div>'
  ];

  vpPopoverDirective.$inject = ['$templateRequest', '$compile', '$rootScope'];

  function vpPopoverDirective($templateRequest, $compile, $rootScope) {
    return {
      controller: vpPopoverController,
      link: linkFn
    };

    function linkFn($scope, $element, $attrs, controller) {
      var $window = angular.element(window),
        popoverContentTemplatePath = $attrs.vpPopover,
        popupController = controller,
        $popoverElement,
        offPopoverClose;

      $templateRequest(popoverContentTemplatePath).then(function(response) {
        popoverTemplate[2] = response;
        $popoverElement = $compile(popoverTemplate.join(''))($scope);
        angular.element(document.body).append($popoverElement);

        var onSortBtnClick = function() {
          popupController.togglePopover($popoverElement, $element);
        };
        var onWindowResize = function() {
          if (!popupController.isHidden) {
            popupController.calculatePosition($popoverElement, $element);
          }
        };

        $element.on('click', onSortBtnClick);
        $window.on('resize', onWindowResize);
        offPopoverClose = $rootScope.$on('vp.popover.close', function closePopover() {
          popupController.hidePopover($popoverElement, $element);
        });

        $scope.$on('$destroy', function() {
          $element.off('click', onSortBtnClick);
          $window.off('resize', onWindowResize);
          offPopoverClose();

          document.body.removeChild($popoverElement[0]);
        });
      });
    }
  }

  vpPopoverController.$inject = ['$window'];

  function vpPopoverController($window) {
    var POPOVER_OPEN_CLASS = 'vp-popover-open';
    var POPOVER_IS_OPEN_CLASS = 'vp-popover-is-open';

    // 6px padding within body at least
    var POPOVER_BODY_PADDING = 6;

    this.isHidden = true;

    this.togglePopover = function($popoverElement, $targetElement) {
      this.isHidden ?
        this.showPopover($popoverElement, $targetElement) :
        this.hidePopover($popoverElement, $targetElement);
    };

    this.showPopover = function($popoverElement, $targetElement) {
      this.isHidden = false;
      $targetElement.addClass(POPOVER_IS_OPEN_CLASS);
      $popoverElement.addClass(POPOVER_OPEN_CLASS);
      this.calculatePosition($popoverElement, $targetElement);
    };

    this.hidePopover = function($popoverElement, $targetElement) {
      this.isHidden = true;
      $targetElement.removeClass(POPOVER_IS_OPEN_CLASS);
      $popoverElement.removeClass(POPOVER_OPEN_CLASS);
    }

    this.calculatePosition = function($popoverElement, $targetElement) {
      var popoverContentElement = $popoverElement[0].querySelector('.vp-popover-content'),
        popoverArrowElement = $popoverElement[0].querySelector('.vp-popover-arrow'),
        $popoverContentElement = angular.element(popoverContentElement),
        $arrowElement = angular.element(popoverArrowElement),
        arrowElementHeight = $arrowElement.prop('offsetHeight'),
        targetElementRect = $targetElement[0].getBoundingClientRect(),
        availableSpace = calculateAvailableSpace($targetElement),
        popoverWidth = $popoverElement.prop('offsetWidth'),
        bodyWidth = $window.innerWidth,
        popoverHeight = 0,
        maxPopoverHeight = 0;

      var popoverCSS = {
        left: targetElementRect.left + targetElementRect.width / 2 - popoverWidth / 2
      };

      if (popoverCSS.left < POPOVER_BODY_PADDING) {
        popoverCSS.left = POPOVER_BODY_PADDING;
      } else if (popoverCSS.left + popoverWidth + POPOVER_BODY_PADDING > bodyWidth) {
        popoverCSS.left = bodyWidth - popoverWidth - POPOVER_BODY_PADDING;
      }

      maxPopoverHeight = availableSpace.height - arrowElementHeight - POPOVER_BODY_PADDING;
      $popoverContentElement.css({
        maxHeight: maxPopoverHeight
      });

      popoverHeight = $popoverElement.prop('offsetHeight');
      popoverCSS.top = targetElementRect.top - popoverHeight - arrowElementHeight +
                       Math.abs(document.body.getBoundingClientRect().top);

      $arrowElement.css({
        left: targetElementRect.left + targetElementRect.width / 2 - popoverCSS.left + 'px'
      });

      $popoverElement.css({
        top: popoverCSS.top + 'px',
        left: popoverCSS.left + 'px'
      });
    }

    function calculateAvailableSpace($targetElement) {
      // exclude scrollbar
      return {
        width: document.body.getBoundingClientRect().width,
        height: $targetElement[0].getBoundingClientRect().top
      };
    }
  }
})();
