// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

angular.module('vpDirectiveModule')
    /**
     * @ngdoc directive
     * @name vpDirectiveModule.directive:vpLoading
     * @module vpDirectiveModule
     * @restrict A
     *
     * @description
     * The directive is responsible to remove the splash screen
     * while the application finish loading.
     *
     * @example
     * <example module="mobile-toolkit-ra">
     *  <file name="index.html">
     *      <div vp-stop-event="touchend">
     *      </div>
     *  </file>
     * </example>
     */
    .directive('vpStopEvent', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                element.on(attr.vpStopEvent, function (e) {
                    e.stopPropagation();
                });
            }
        };
    });
