// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

angular.module('vpServiceModule')

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpRouterSvc
 * @description this service will handle routing events and map default routers.
 */

.provider('vpRouterSvc', [
    '$urlRouterProvider',
    function($urlRouterProvider) {
        'use strict';

        this.$get = [
            '$rootScope',
            '$state',
            'vpLayoutSvc',
            '$injector',
            function ($rootScope, $state, vpLayoutSvc, $injector) {
                var StateUtils = {
                    title: (function(){
                       var _caches = {};
                       var sideMenus = $injector.get('Const.SidebarMenuItems');
                       sideMenus = sideMenus && sideMenus.navigationItems;

                       var _stateTitleHelpers = {
                            displays: {
                                getCacheKey: function (stateParams) {
                                    return 'displays/' + stateParams.areaIds;
                                },

                                cache: function(stateParams) {
                                    var key = this.getCacheKey(stateParams);

                                    if(key) {
                                        _caches[key] = stateParams.areaIds.split('\/').pop();
                                    }
                                },

                                getTitle: function (stateParams) {
                                    var title = '';
                                    var key = this.getCacheKey(stateParams);

                                    if (_caches[key]) {
                                        title = _caches[key];
                                    } else {
                                        title = stateParams.areaIds.split('\/').pop();
                                        _caches[key] = title;
                                    }

                                    return title;
                                },

                                getChainedTitles: function(stateParams) {
                                    var fullpath = stateParams.fullpath;
                                    if (!fullpath) {
                                        return false;
                                    }

                                    fullpath = decodeURIComponent(fullpath).replace(/^#/,'').replace(/\/$/,'');
                                    var lastSlash= fullpath.length;
                                    var titles = [];
                                    var title, link;
                                    while (fullpath.length > 0) {
                                        lastSlash = fullpath.lastIndexOf("/");

                                        if (lastSlash <= 0) {
                                            break;
                                        } else {
                                            link = '#' + fullpath;
                                            title = fullpath.substr(lastSlash+1);

                                            if (title) {
                                               titles.push({label: title, link: link});
                                            }

                                            fullpath = fullpath.substr(0, lastSlash);
                                        }
                                    }

                                    return titles.reverse();
                                }
                            },
                            display: {
                                getCacheKey: function (stateParams) {
                                    return 'display/' + stateParams.areaIds + '/' + stateParams.displayName;
                                },

                                getTitle: function (stateParams) {
                                    return stateParams.displayName;
                                },

                                /*
                                * when calculating the title, ignore the /params part from router,
                                * which is used to keep command list and history display while redirecting.
                                */
                                _ignoreParams: function (stateParams) {
                                    stateParams.fullpath = stateParams.fullpath.replace(/([^\/]*)$/, '');
                                },

                                getChainedTitles: function(stateParams) {
                                    this._ignoreParams(stateParams);
                                    var titles = _stateTitleHelpers.displays.getChainedTitles.call(this, stateParams);

                                    for(var i=0,n= titles.length; i<n-1; ++i) {
                                        titles[i].link = titles[i].link.replace('display', 'displays');
                                    }

                                    return titles;
                                }
                            },
                            'display-redirect': 'display',

                            menuItem: function (stateName) {
                                return {
                                    getTitle: function () {
                                        var title = '';

                                        if (_caches[stateName]) {
                                            title = _caches[stateName];
                                        } else {
                                            var menuItem = stateName && sideMenus[stateName];
                                            title = menuItem && (menuItem.headerTitle || menuItem.title);
                                            _caches[stateName] = title;
                                        }

                                        return title;
                                    }
                                };
                            },

                            home: function () {
                                return this.menuItem('home');
                            }
                       };


                       return {
                            get: function (stateName, getterName, stateParams) {
                                var stateTitleHelper = _stateTitleHelpers[stateName];
                                var getter = null;
                                getterName = getterName || 'getTitle';
                                stateParams = stateParams || $injector.get('$stateParams');

                                if(stateTitleHelper && angular.isString(stateTitleHelper)){
                                    stateTitleHelper = _stateTitleHelpers[stateTitleHelper];
                                }

                                if (stateTitleHelper && angular.isFunction(stateTitleHelper)){
                                    stateTitleHelper = stateTitleHelper.apply(_stateTitleHelpers);
                                }

                                if (stateTitleHelper && angular.isObject(stateTitleHelper)) {
                                    getter = stateTitleHelper[getterName] || stateTitleHelper.getTitle;
                                }

                                if (getter && angular.isFunction(getter)) {
                                    return getter.call(stateTitleHelper, stateParams);
                                } else {
                                    return false;
                                }
                           },

                           getChainedTitles: function (stateName, stateParams) {
                                return this.get(stateName, 'getChainedTitles', stateParams);
                           },

                           cache: function (stateName, title, stateParams) {
                                var stateTitleHelper = _stateTitleHelpers[stateName];
                                var setter = stateTitleHelper && stateTitleHelper.cache;

                                if (setter && angular.isFunction(setter)) {
                                    stateParams.title = title;
                                    setter.call(stateTitleHelper, stateParams);
                                } else {
                                    var getter = stateTitleHelper && stateTitleHelper.getCacheKey;
                                    var key = '';

                                    if (getter && angular.isFunction(getter)) {
                                        key = getter.call(stateTitleHelper, stateParams);
                                    }

                                    if (key) {
                                        _caches[key] = title;
                                    }
                                }
                           }
                       };

                    })()
                };

                var initialState = null;
                var StateTitleUtil = StateUtils.title;
                var vpAdminPingDataSvc = $injector.get('vpAdminPingDataSvc');
                return {
                    /**
                     * @ngdoc method
                     * @name vpServiceModule.vpRouterSvc#startMonitoring
                     * @methodOf vpServiceModule.vpRouterSvc
                     * @param  none
                     * @returns none
                     * @description handle router events.
                     *
                     * TODO: template switching issue while orientation is changed on smartphone.
                     */
                    startMonitoring: function () {
                        $rootScope.$on('$stateChangeSuccess',
                        function (event, toState, toParams, fromState) {
                            if (app.isOffline || app.errorLoaded) {
                                return false;
                            }

                            var link = $state.href(toState);

                            if (fromState.name && toState.name !== fromState.name) {
                                vpAdminPingDataSvc.resetSessionTimeout();
                            }

                            if (link) {
                                initialState = StateTitleUtil.getChainedTitles(toState.name, {fullpath: link});
                            }

                            if (fromState.name) {
                                $rootScope.$emit('app:updateTitle');
                                $rootScope.$emit('app:updateTitleIcon', '');

                                if (toState.enableLoadingIndicator) {
                                    $rootScope.$emit('app:toggleLoadingStatus', true);
                                }
                            } else {
                                if (toState.enableLoadingIndicator) {
                                    $rootScope.showLoading = true;
                                    $rootScope.pauseWorkerXhr = true;
                                }
                            }

                            //if(toState.name !== 'login') {
                            //    link = decodeURIComponent(link).replace(/^\#*/, '');
                            //    app.util.topWinLocationSvc.update(link);
                            //}
                        });
                    },

                    updateDisplayTitle: function (data) {
                        var link = '';
                        if (!data) {
                            data = {areaName:'', displayName:'',raw:''};
                        }

                        if (data.displayName) {
                            data.areaName = (data.areaName || '').replace(/^\/*/,'');
                            var toDisplayParams = {
                                areaIds:data.areaName,
                                displayName: data.displayName
                            };
                            link = $state.href('display', toDisplayParams);
                            link = decodeURIComponent(link).replace('///','//').replace(/^\#*/, '');
                            vpAdminPingDataSvc.resetSessionTimeout();

                            initialState = StateTitleUtil.getChainedTitles('display', {fullpath: link});
                            $rootScope.$emit('app:updateTitle');
                        } else {
                            //"false" here mean removing additional header items by force.
                            $rootScope.$emit('app:updateTitle');
                            $rootScope.$emit("app:updateTitleIcon", "");
                        }

                        if (data.raw) {
                            var parsed = app.util.parseSearchFragments(data.raw,true);
                            $state.go('display-redirect', parsed, {
                                notify: false,
                                location: 'replace'

                            }).then(function() {
                                $rootScope.$emit('app:updateTitle', parsed);
                            })
                        }
                    },

                    getInitialState: function () {
                        return initialState;
                    },

                    getStateLink: function (stateName, params) {
                        return $state.href(stateName || 'home', params);
                    },

                    getDisplayLink: function (itemName) {
                        return this.getStateLink('display', {displayName: itemName});
                    },

                    transitionTo: function(stateName, params, options) {
                        stateName = stateName || 'home';
                        $state.go(stateName, params, options);
                    },

                    transitionToDisplay: function (itemName, areaIds, /*optional*/ displayName) {
                        if (itemName) {
                            this.transitionTo('display', {
                                areaIds: areaIds,
                                displayName: itemName
                            });

                            StateTitleUtil.cache('display', itemName, {
                                areaIds: areaIds,
                                displayName: itemName
                            });
                        } else {
                            this.transitionTo('displays', {
                                areaIds: areaIds
                            });

                            StateTitleUtil.cache('displays', displayName, {
                                areaIds: areaIds
                            });
                        }
                    },

                    transitionToAlarmDetail: function (id) {
                        var encodeId =  encodeURIComponent(id);
                        this.transitionTo('alarmDetails', {
                            id: encodeId});
                    }
                };
            }
        ];

        this.bindRouters = function () {
            $urlRouterProvider.otherwise('/home');
        };
    }
])
.config([
    'vpRouterSvcProvider',
    function (vpRouterSvcProvider) {
        "use strict";
        vpRouterSvcProvider.bindRouters();
    }
]);