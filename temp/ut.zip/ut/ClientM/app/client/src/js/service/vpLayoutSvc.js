// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('vpServiceModule')

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpLayoutSvc
 * @description this service will detect device layout information such as dimensions, orientations,etc.
 */

.factory('vpLayoutSvc', [
    '$window',
    'raScreenSizeSvc',
    'RA_SCREEN_SIZE_SVC_CONSTS',
    function ($window, raScreenSizeSvc, RA_SCREEN_SIZE_SVC_CONSTS) {
        'use strict';

	    var ruleName = RA_SCREEN_SIZE_SVC_CONSTS.WIDTHS_ONLY;
        var deviceTypes = {
            'xs' : 'phone',   //Extra small
            'sm' : 'tablet',  //small
            'md' : 'desktop', //medium
            'lg' : 'desktop'  //large
        };

        var orienHandlerQueue = [];

        return {

            /**
             * @ngdoc method
             * @name vpServiceModule.vpLayoutSvc#startMonitoring
             * @methodOf vpServiceModule.vpLayoutSvc
             * @param  none
             * @returns none
             * @description this method will invoke some private method to check the device
             * and monitor the change of the orientation.
             */
            startMonitoring: function () {
                this.isLandscape = raScreenSizeSvc.isLandScape();
                raScreenSizeSvc.startOrientationListening();
                var that = this;

                raScreenSizeSvc.onOrientationChange(function (isLandscape) {

                    setTimeout(function () {
                        that.isLandscape = isLandscape;
                        that._checkDeviceType();
                        that.notifyOrientationChangeHandlers(isLandscape, that.isPhone());
                    }, 0);
                });

                //sometimes UI events are busy, which will cause matchmedia doesn't get the correct value
                //this will cause app mis-check the device type
                //so we delay this action to next event queue
                setTimeout(function () {
                    that._checkDeviceType();
                }, 0);
            },

            notifyOrientationChangeHandlers: function (isLandscape, isPhone) {
                angular.forEach(orienHandlerQueue, function (eaItem) {
                    var handler = eaItem[0];
                    if (handler && typeof handler === "function") {
                        handler.call(eaItem[1], isLandscape, isPhone);
                    }
                });
            },

            onOrientationChanged: function (handler, context) {
                orienHandlerQueue.push([handler, context]);
            },
            /**
             * @ngdoc method
             * @name vpServiceModule.vpLayoutSvc#_checkDeviceType
             * @methodOf vpServiceModule.vpLayoutSvc
             * @param  none
             * @returns none
             * @description this private method will check the dimension of the device.
             */
            _checkDeviceType: function () {
                var that = this;
                for (var key in deviceTypes) {
                    if (raScreenSizeSvc.minScreenDimensionIs(key, ruleName)) {
                        that.deviceType = deviceTypes[key] || deviceTypes.lg;
                        break;
                    }
                }
            },

            isPhone: function () {
                if (!this.deviceType) {
                    this._checkDeviceType();
                }

                return this.deviceType === 'phone';
            },

            matchListLayout: function () {
                return this.isPhone() && !this.isLandscape;
            }
        };
    }
]);