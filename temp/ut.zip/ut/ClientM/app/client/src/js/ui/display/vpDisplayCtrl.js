// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

(function () {
    'use strict';
    angular.module('appModule')

    .config(['$stateProvider',
        '$urlMatcherFactoryProvider',
        '$urlRouterProvider',
        function ($stateProvider, $urlMatcherFactoryProvider, $urlRouterProvider) {

            //I add this custom type because I want the url parameters keep un-encoded
            //when I apply the parameter type to 'any', everything seems ok, but 'any' type doesn't
            //allow empty value.
            //refer to urlMatcherFactory.js for more information.
            function valToString(val) {return val ? val.toString() : val; }
            function valFromString(val) {return val ? val.toString() : val; }
            function regexpMatches(val) { /*jshint validthis:true */ return this.pattern.test(val); }

            $urlMatcherFactoryProvider.type("dispath", {
              encode: valToString,
              decode: valFromString,
              is: regexpMatches,
              pattern: /.*/
            });

            $stateProvider
            .state('display', {
                'url': '/display/{areaIds:dispath}/{displayName}/{params}',
                parent: 'app',
                enableLoadingIndicator: true,
                views: {
                    "content": {
                        templateUrl: 'js/ui/display/vpDisplayCtrl.tpl.html',
                        controller: 'vpDisplayCtrl as display',
                        resolve: {
                            displayList: ['vpDisplaySvc', function (vpDisplaySvc) {
                                return vpDisplaySvc.getDisplayList();
                            }]
                        }
                    }
                }
            })
            .state('display-redirect', {
                'url': '/display/?raml&{area:dispath}&param&macro&{cmd:dispath}&{prev:dispath}&scaletoscreen&retainaspectratio&{preparam:dispath}',
                parent: 'app',
                enableLoadingIndicator: true,
                views: {
                    "content": {
                        templateUrl: 'js/ui/display/vpDisplayCtrl.tpl.html',
                        controller: 'vpDisplayCtrl as display',
                        resolve: {
                            displayList: ['vpDisplaySvc', function (vpDisplaySvc) {
                                return vpDisplaySvc.getDisplayList();
                            }]
                        }
                    }
                }
            });
        }
    ])

    /**
     * @ngdoc controller
     * @module appModule
     * @name appModule.vpDisplayCtrl
     * @description this controller will control the individual "display" state.
     */

    .controller('vpDisplayCtrl', [
        '$scope',
        '$injector',
        '$stateParams',
        'displayList',
        app.createClass({
            constructor: function ($scope, $injector, $stateParams, displayList) {
                this.injector = $injector;
                this.displayList = displayList;

                if(!$stateParams.areaIds && !$stateParams.displayName) {
                    this.showDisplayByRawLink();
                } else {
                    this.showDisplay($stateParams);
                }

                $scope.app.getTabletNavbarHeader().setNavbarActiveItem('VP_APP.MENU.DISPLAYS');
            },

            showDisplayByRawLink: function () {
                var location = this.injector.get('$location');
                var rawLink = decodeURIComponent(location.url().replace(/^[^?]*\?/, ''));
                this.graphicsUrl = this.displayList.getDisplayUrl(false, rawLink);
            },

            showDisplay: function (stateParams) {
                var that = this;

                var graphicsUrl = that.displayList.getDisplayUrl(stateParams);
                if (graphicsUrl) {
                    var rootScope = that.injector.get("$rootScope");
                    app.util.detectNetworkIsOffline(graphicsUrl).then(function (stat) {
                        if (stat.isOffline === true) {
                            app.isOffline = true;
                            that.injector.get('vpWorkerSvc').stopSet();
                            rootScope.$emit("app:toggleLoadingStatus", false);
                            rootScope.$emit('app:displayErrorPage', stat.timeout ? 'serverdown': 'offline');
                        } else {
                            that.graphicsUrl = graphicsUrl;
                        }
                    });
                }
            }
        })
    ]);
})();