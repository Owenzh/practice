// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, Worker, app*/
/*jshint sub:true*/

angular.module('vpServiceModule')

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpWorkerSvc
 * @description this service offer api workers.
 */

.factory('vpWorkerSvc', [
    '$injector',
    function (injector) {
        "use strict";
        var q = injector.get('$q');
        var vpWorkerSvc = null;

        var WorkerBase = {
            init: function () {
            },

            isAvailable: function (/*workerMsger*/) {
                return true;
            },

            onsuccess: function () {
                return true;
            },

            onerror: function () {
                return false;
            },

            notify: function (key, value) {
                if (this._workerMessager && this._workerMessager.notifyPeerMessager) {
                    this._workerMessager.notifyPeerMessager(key, value);
                }
            }
        };

        var SeparateThreadWorker = angular.extend({}, WorkerBase, {
            workerBase: 'workers/',
            pushUp: true,
            service: '', //the worker js file name.
            init: function (workerMsger) {
                var that = this;
                this._workerMessager = workerMsger;
                this.deferred = q.defer();
                var $window = injector.get('$window');
                var filePath = '';

                if ('Worker' in $window && $window.Worker) {
                    if (!that.service) {
                        this.deferred.reject('worker file name not specified');
                    } else {
                        filePath = this.workerBase + this.service + ".js";
                        this._instance = new Worker(filePath);

                        if (!this._instance) {
                            this.deferred.reject('fail to run web worker file:' + filePath);
                        } else {
                            this.employer = this.getEmployer();
                            if (this.employer && this.employer.employeeWorker) {
                                this.employer.employeeWorker(this);
                                this.employer.start();
                            } else {
                                this._instance.addEventListener('message', function (e) {
                                    var data = e.data;
                                    that.handleCommand(data.cmd, data.data);
                                });

                                this._instance.addEventListener('error', function (e) {
                                    that.handleError(e.data);
                                });
                            }
                        }
                    }

                } else {
                    this.deferred.reject('web worker not supported by the device');
                }

                return this.deferred.promise;
            },

            getInstance: function () {
                return this._instance;
            },

            getMessager: function () {
                return this._workerMessager;
            },

            getEmployer: function () {
                return false;
            },

            setConfigData: function (data) {
                this._configData = data;
                this.invoke('config', data);
            },

            getConfigData: function () {
                return this._configData;
            },

            run: function () {
                this.invoke('start');
            },

            stop: function () {
                if (this.employer && this.employer.stop) {
                    this.employer.stop();
                } else {
                    this.invoke('stop');
                }
            },

            terminate: function () {
                this.invoke('stop');
                this._instance.terminate();
            },

            invoke: function (cmd, data) {
                this._instance.postMessage({
                    cmd: cmd,
                    data: data
                });
            },

            handleCommand: function (cmd, data) {
                var method = this['on' + cmd];
                if (method && angular.isFunction(method)) {
                    method.call(this, data);
                }
            },

            onsuccess: function (data) {
                this.deferred.resolve(data);
            },

            onerror: function (err) {
                this.handleError(err);
                this.deferred.reject(err);
            },

            handleError: function (err) {
                injector.get('vpErrorHandlerSvc').propagate('web worker error:' + JSON.stringify(err));
            }
        });

        var MainThreadWorkerHandlers = {};
        var MainThreadWorker = angular.extend({}, WorkerBase, {
            init: function (workerMsger) {
                this._workerMessager = workerMsger;
                this.deferred = q.defer();

                if (this.service) {
                    var svcName = this.service.split(".");
                    var svcInst = null;
                    var svcModule = null;
                    var that = this;

                    if (svcName.length >= 2) {
                        svcModule = injector.get(svcName[0]) || MainThreadWorkerHandlers;
                        svcInst = svcModule[svcName[1]];
                    } else {
                        svcInst = MainThreadWorkerHandlers[svcName[0]];
                    }

                    if (svcInst && angular.isFunction(svcInst)) {
                        svcInst.call(svcModule).then(function () {
                            that.onsuccess.apply(that, arguments);
                        }, function () {
                            that.onerror.apply(that, arguments);
                        });
                    }
                }


                return this.deferred.promise;
            },

            onsuccess: function (data) {
                this.deferred.resolve(data);
            },

            onerror: function (err) {
                this.handleError(err);
                this.deferred.reject(err);
            },

            handleError: function (err) {
                injector.get('vpErrorHandlerSvc').propagate('web worker error:' + JSON.stringify(err));
            }
        });

        var workers = {
            'getLicense': {
                base: MainThreadWorker,
                service: 'vpWebHandlerDataSvc.getClientLicense',

                onsuccess: function (data) {
                    var status = this.checkLicenseAvailable(data);
                    if (status) {
                        MainThreadWorker.onsuccess.apply(this, arguments);
                    } else {
                        MainThreadWorker.onerror.apply(this, arguments);
                    }

                    this._workerMessager.setShared('clientLicense', data);
                },

                checkLicenseAvailable: function (data) {
                    var licenseStatus = Number(data.response);
                    var LicensingStatusCode = injector.get('vpSoapConstSvc').LicensingStatusCode;
                    var rootScope = injector.get('$rootScope');
                    var checkstatus = true;

                    switch (licenseStatus) {
                        case LicensingStatusCode['Success']:
                        case LicensingStatusCode['LicenseAlreadyAssignedForThisSessionAndClientID']:
                            checkstatus = true;
                            break;

                        case LicensingStatusCode['LicenseAllInUse']:
                            vpWorkerSvc.stopSet();
                            checkstatus = false;
                            rootScope.$emit('app:displayErrorPage', 'licenseAllInUse');
                            break;

                        case LicensingStatusCode['ApplicationNotRunning']:
                            vpWorkerSvc.stopSet();
                            rootScope.$emit('app:displayErrorPage', 'applicationNotFound');
                            checkstatus = false;
                            break;

                        case LicensingStatusCode['LoginRequired']:
                            vpWorkerSvc.stopSet();
                            top.location.reload(); //refresh the top window.
                            checkstatus = false;
                            break;

                        default:
                            vpWorkerSvc.stopSet();
                            rootScope.$emit('app:displayErrorPage', 'licenseNotAvailable');
                            checkstatus = false;
                    }

                    return checkstatus;
                },

                onerror: function(status) {
                    MainThreadWorker.onsuccess.apply(this, arguments);
                    this._workerMessager.setShared('clientLicense', status);
                }
            },

            'getRunningViewApplication': {
                base: MainThreadWorker,
                service: 'vpAdminDataSvc.getRunningViewApplication',
                onsuccess: function(status){
                    MainThreadWorker.onsuccess.apply(this, arguments);
                    this._workerMessager.setShared('runningViewApplicationStatus', status);
                },

                onerror: function(status) {
                    MainThreadWorker.onsuccess.apply(this, arguments);
                    this._workerMessager.setShared('runningViewApplicationStatus', status);
                }
            },

            'getProjectVersion': {
                base: MainThreadWorker,
                service: 'vpAppSvc.getProjectVersion',
                onsuccess: function(version){
                    if(version.data){
                        app.env.set('appVersion', version.data);
                    }else {
                        this.onerror();
                    }
                },

                onerror: function() {
                    var version = injector.get('Const.App').productVersion;
                    app.env.set('appVersion', version);
                }
            },

            'licenseDaemon': {
                base: SeparateThreadWorker,
                service: 'licenseDaemon',
                run: function () {
                    this.employer.invoke();
                },

                onsuccess: function(clientStatus){
                    SeparateThreadWorker.onsuccess.apply(this, arguments);
                    this._workerMessager.setShared("licenseClientStatus", clientStatus, this.pushUp);
                },

                onerror: function (clientStatus) {
                    SeparateThreadWorker.onerror.apply(this, arguments);
                    this._workerMessager.setShared("licenseClientStatus", clientStatus, this.pushUp);
                },

                getEmployer: function () {
                    return injector.get('vpLicenseUpdateManagerSvc');
                }
            },
            'alarmGetUpdateJsonDaemon' : {

                base: SeparateThreadWorker,
                service: 'alarmGetUpdateJsonDaemon', 
                run: function () {
                    this.employer.invoke();
                },

                onsuccess: function(){
                    SeparateThreadWorker.onsuccess.apply(this, arguments);
                },

                onerror: function () {
                    SeparateThreadWorker.onerror.apply(this, arguments);
                },

                getEmployer: function () {
                    return injector.get('vpAlarmUpdateManagerSvc');
                }
            }
        };

        /*
        *  the sub array means a group of workers
        *  the first group need to be completed and successfully,
        *  then the next group can run
        *
        *  next group must wait for its previous group complete.
        *  if first element of one group is '!', then we have to return or run after its complete.
        *  if one group only contains one item, it can be the only item, without array container.
        */
        var workerSets = {
            startup: [['!','getLicense'],'getRunningViewApplication', 'licenseDaemon', 'getProjectVersion','alarmGetUpdateJsonDaemon']
        };

        vpWorkerSvc = {
            /**
             * @ngdoc method
             * @name vpServiceModule.vpWorkerSvc#registerWorkers
             * @methodOf vpServiceModule.vpWorkerSvc
             * @param {object} workerMessager the owner worker messager.
             * @returns none
             * @description
             * register damon workers (SeparateThreadWorker or MainThreadWorker)
             */
            registerWorkers: function (workerMessager) {
                if (!workerMessager || !workerMessager.registerWorker) {
                    return false;
                }

                this.workerMessager = workerMessager;
                workerMessager.registerWorkers(workers);
            },

            runSet: function (workerSetName) {
                var set = this.getWorkerSet(workerSetName);
                return set && set.run();
            },

            stopSet: function () {
                this.workerMessager.stopDaemons();
            },

            getWorkerSet: function (workerSetName) {
                var workerset = workerSets[workerSetName];
                var q = injector.get('$q');
                var that = this;

                if (!workerset || !workerset.length) {
                    return false;
                }

                return  {
                    run: function () {
                        var workers, num;
                        var deferred = q.defer();
                        var waitCompleted = false;

                        function handleResolved(data) {
                            if (num === data.length) {
                                if (!workerset.length) {
                                    deferred.resolve(true);
                                } else {
                                    processSet();
                                }
                            }
                        }

                        function handleRejected(data) {
                            if (data) {
                                deferred.reject(data);
                            }
                        }

                        function processSet() {
                            workers = workerset.shift();
                            waitCompleted = false;

                            if (!workers) {
                                processSet();
                                return false;
                            }

                            if (!angular.isArray(workers)) {
                                workers = [workers];
                                num = 1;
                            } else {
                                num = workers.length;
                                if (num && workers[0] === '!') {
                                    waitCompleted = true;
                                    num --;
                                    workers.shift();
                                }
                            }

                            if (num) {
                                if (waitCompleted) {
                                    workers = that.workerMessager.calls(workers);
                                    q.allSettled(workers).then(function(results){
                                        handleResolved(results[0]);
                                        handleRejected(results[1]);
                                    });
                                } else {
                                    workers = [].concat.apply(workers, workerset);
                                    workers = that.workerMessager.calls(workers);
                                    deferred.resolve(true);
                                }
                            } else {
                                processSet();
                                return false;
                            }
                        }

                        processSet();
                        return deferred.promise;
                    }
                };
            }
        };

        return vpWorkerSvc;
    }
]);