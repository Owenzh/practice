/*global angular*/
(function() {
  'use strict';

  angular.module('vpDirectiveModule')
    .directive('vpSelect', vpSelectDirective)
    .controller('vpSelectController', vpSelectController);

  var selectNextId = 0;

  var SELECT_MENU_BODY_PADDING = 6;
  var SELECT_MENU_ACTIVE_CLASS = 'vp-select-active';
  var SELECT_CONTAINER_ID_PREFIX = 'vp_select_container_';

  vpSelectDirective.$inject = ['$templateCache', '$rootScope', '$timeout'];

  function vpSelectDirective($templateCache, $rootScope, $timeout) {
    return {
      restrict: 'E',
      require: ['ngModel', 'vpSelect'],
      replace: true,
      scope: {
        currentValue: '=ngModel',
        options: '=vpOptions'
      },
      template: $templateCache.get('js/directives/vpSelectDir.tpl.html'),
      controller: vpSelectController,
      controllerAs: 'selectCtrl',
      bindToController: true,
      link: function($scope, $element, $attrs, controllers) {
        var selectCtrl = controllers[1],
          $window = angular.element(window);

        var selectMenuContainer = $element.children()[1],
          $selectMenuContainer = angular.element(selectMenuContainer);

        selectCtrl.$targetElement = $element;
        selectCtrl.$selectMenuContainer = $selectMenuContainer;

        $selectMenuContainer.detach();

        selectCtrl.setValue(selectCtrl.currentValue);

        var offSelectMenuClose = $rootScope.$on('vp.select.close', function closeSelectMenu() {
          selectCtrl.hideSelectMenu();
        });

        var unwatchValueChanged = $scope.$watch(function() {
          return selectCtrl.currentValue;
        }, function() {
          selectCtrl.setValue(selectCtrl.currentValue);
        });

        var onWindowResize = function() {
          if (selectCtrl.isMenuShown) {
            selectCtrl.hideSelectMenu();

            // Add 400ms delay to fix resize position issue.
            // Because we use dropdown menu on a `raOverlay` component, so when resize window
            // we have to wait for `raOverlay` resizing done.
            // 400ms is a proper value after testing on mobile.
            $timeout(function() {
              selectCtrl.showSelectMenu();
            }, 400);
          }
        };

        $window.on('resize', onWindowResize);

        $scope.$on('$destroy', function() {
          offSelectMenuClose();
          unwatchValueChanged();
          $window.off('resize', onWindowResize);
        });
      }
    };
  }

  vpSelectController.$inject = ['$rootScope', '$window'];

  function vpSelectController($rootScope, $window) {
    var isInit = false;

    this.isMenuShown = false;

    this.initSelectMenu = function() {
      isInit = true;
      angular.element(document.body).append(this.$selectMenuContainer);
    };

    this.setValue = function(value) {
      for (var i = 0; i < this.options.length; i++) {
        if (this.options[i].value === value) {
          this.currentOption = this.options[i];
          break;
        }
      }
      this.currentValue = value;
      this.hideSelectMenu();
    };

    this.toggleSelect = function() {
      if (!isInit) {
        this.initSelectMenu();
      }

      this.isMenuShown ? this.hideSelectMenu() : this.showSelectMenu();
    };

    this.showSelectMenu = function() {
      $rootScope.$emit('vp.select.close');
      this.calculateMenuPosition();
      this.$selectMenuContainer.addClass(SELECT_MENU_ACTIVE_CLASS);
      this.isMenuShown = true;
    };

    this.hideSelectMenu = function() {
      this.$selectMenuContainer.removeClass(SELECT_MENU_ACTIVE_CLASS);
      this.isMenuShown = false;
    };

    this.calculateMenuPosition = function() {
      var selectMenuCSS = {};

      var documentBodyRect = document.body.getBoundingClientRect(),
        targetElementRect = this.$targetElement[0].getBoundingClientRect();

      var targetWidth = this.$targetElement.prop('offsetWidth'),
        selectMenuHeight = this.$selectMenuContainer.prop('offsetHeight'),
        windowHeight = $window.innerHeight;

      selectMenuCSS.width = targetWidth;
      selectMenuCSS.left = targetElementRect.left + Math.abs(documentBodyRect.left);
      selectMenuCSS.top = targetElementRect.top + Math.abs(documentBodyRect.top);

      if (targetElementRect.top + selectMenuHeight + SELECT_MENU_BODY_PADDING > windowHeight) {
        selectMenuCSS.top -= targetElementRect.top + selectMenuHeight + SELECT_MENU_BODY_PADDING - windowHeight;
      }

      // '-2px' and '+4px' is to make select menu a little bigger than select box and covers it
      this.$selectMenuContainer.css({
        top: selectMenuCSS.top - 2 + 'px',
        left: selectMenuCSS.left - 2 + 'px',
        width: selectMenuCSS.width + 4 + 'px'
      });
    };
  }
})();
