// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, window, app*/

angular.module('vpServiceModule')

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpMessagerSvc
 * @description this service create messager service and interact with other iframe/windows.
 */

.factory('vpMessagerSvc', [
    'vpErrorHandlerSvc',
    '$injector',
    function (vpErrorHandlerSvc, injector) {
        "use strict";

        return {
            /**
             * @ngdoc method
             * @name vpServiceModule.vpMessagerSvc#createWindowMessager
             * @methodOf vpServiceModule.vpMessagerSvc
             * @returns {object} object that includes methods to exchange message between framework and target iframe.
             * @description
             * example:
             *
             * create framework messager
             *    app.topMessager = vpMessagerSvc.createWindowMessager($window, { sharedData: object});
             *    app.topMessager.onMessage("authenticate", function(value){});
             *
             *
             *
             * create peer messager for inner iframe
             *    var canvasMessager = app.topMessager.createPeerMessager($iframewindow, { sharedData: object});
             *    canvasMessager.postMessage('authenticate', 1);
             *
             */
            createWindowMessager: function (winElem, sharedData) {
                winElem = winElem || window;

                function _createMessager(winElem, sharedData, messageHandlers){
                    if (!winElem) {
                        return false;
                    }

                    return (function(winElem, sharedData, messageHandlers){
                        sharedData = sharedData || {};
                        messageHandlers = angular.extend({
                            setShared: function(key, value){
                                if (key && value) {
                                    sharedData[key] = value;
                                }
                            }
                        }, messageHandlers);

                        function fireMessage(cmd, data) {
                            if(!cmd) {
                                return false;
                            }

                            var handler = messageHandlers[cmd];
                            var _params = angular.isArray(data) ? data : [data];

                            if (!handler) { return false; }
                            if (angular.isFunction(handler)) {
                                handler.apply(messageHandlers, _params);
                            }

                            if (angular.isArray(handler)) {
                                angular.forEach(handler, function (_eachHandler) {
                                    _eachHandler.apply(messageHandlers, _params);
                                });
                            }
                        }

                        winElem.addEventListener("message", function (evt) {
                            var message = JSON.parse(evt.data);
                            if (message && message.cmd) {
                                fireMessage(message.cmd, message.data);
                            }
                        } , false);

                        var _messager = {
                            win: winElem,
                            _getShared: function (key) {
                                return sharedData && (key ? sharedData[key] : sharedData);
                            },

                            setShared: function (key, value) {
                                if(value){
                                    if (key) {
                                        sharedData[key] = value;
                                    } else {
                                        angular.extend(sharedData, value);
                                    }
                                }
                            },

                            onMessage: function (cmd, callback) {
                                if (!cmd || !callback || !angular.isFunction(callback)) {
                                    return false;
                                }

                                var _handler = messageHandlers[cmd];
                                if (!_handler) {
                                    messageHandlers[cmd] = callback;
                                } else {
                                    if (angular.isArray(_handler)) {
                                        _handler.push(callback);
                                    } else {
                                        messageHandlers[cmd] = [messageHandlers[cmd], callback];
                                    }
                                }
                            },


                            createPeerMessager: function (targetIframe, sharedData, _messageHandlers) {
                                if (targetIframe) {
                                    var targetMessager =  _createMessager(targetIframe, sharedData, _messageHandlers);
                                    this.peer = targetMessager;
                                    this.peer.win = targetIframe;
                                    targetMessager.peer = this;

                                    return targetMessager;
                                }
                            },

                            shared: function (key) {
                                var value = this._getShared(key);
                                if (value === undefined && this.peer) {
                                    value = this.peer._getShared(key);
                                }

                                return value;
                            },

                            fireMessage: fireMessage,

                            postMessage: function  (cmd, data) {
                                if (!cmd || !this.peer || !this.peer.win || !this.peer.win.postMessage) {
                                    return false;
                                }

                                var message = {cmd: cmd};
                                if (typeof data !== 'undefined') {
                                    message.data = data;
                                }

                                message = JSON.stringify(message);
                                this.peer.win.postMessage(message, '*');
                                return this;
                            }
                        };

                        messageHandlers.messager = _messager;
                        return _messager;

                    })(winElem, sharedData, messageHandlers);
                }

                return _createMessager(winElem, sharedData, this.getWindowMessageHandlers());
            },

            /**
             * @ngdoc method
             * @name vpServiceModule.vpMessagerSvc#getWindowMessageHandlers
             * @methodOf vpServiceModule.vpMessagerSvc
             * @returns {object} object that includes all pre-defined handlers for window messager.
             */
            getWindowMessageHandlers: function  () {
                var rootScope = injector.get('$rootScope');
                return {
                    authorization: function (authorization){
                        var arrIcons = injector.get('Const.App.resource.displayAccessRight');
                        var icon = authorization in arrIcons ? arrIcons[authorization] : '';

                        this.setShared('authorization', authorization);
                        this.setShared('authorizationIcon', icon);
                        rootScope.$emit('app:updateTitleIcon', icon);
                    },

                    toggleLoadingStatus: function (status) {
                        rootScope.$emit('app:toggleLoadingStatus', status);
                    },

                    updateMessageRibbon: function (data) {
                        rootScope.$emit('app:updateMessageRibbon', data.message, data.type);
                    },

                    updateDisplayTitle: function(data) {
                        injector.get('vpRouterSvc').updateDisplayTitle(data);
                    },

                    offline: function () {
                        app.isOffline = true;
                        injector.get('vpWorkerSvc').stopSet();
                    }
                };
            },

            /**
             * @ngdoc method
             * @name vpServiceModule.vpMessagerSvc#createWorkerMessager
             * @methodOf vpServiceModule.vpMessagerSvc
             * @returns {object} worker messager.
             * @description
             * create messager that manage all of the damon workers (webworkers)
             */
            createWorkerMessager: function () {
                var _workerPool = {};
                var _daemons = {};

                var _workerMessager = {
                    _sharedData: {},
                    registerWorker: function (key, baseClass, workerImpl) {
                        var _worker = angular.extend({}, baseClass, workerImpl);
                        _workerPool[key] = _worker;
                        _worker.messager = this;
                    },

                    registerWorkers: function (workers) {
                        var that = this;
                        if (workers) {
                            angular.forEach(workers, function (options, workerName) {
                                that.registerWorker(workerName, options.base, options);
                            });
                        }
                    },

                    stopDaemons: function () {
                        angular.forEach(_daemons, function (worker) {
                            worker.stop();
                        });
                    },

                    runInOrder: function () {
                        var workerKeys = [].slice.call(arguments);
                        var exitAbn = false;
                        for (var i=0, n=workerKeys.length; i<n; ++i) {
                            if (!this.call(workerKeys[i])) {
                                exitAbn = true;
                                break;
                            }
                        }

                        if (exitAbn) {
                            vpErrorHandlerSvc.propagate('workerMessager exit abnormally');
                            return false;
                        }
                    },

                    call: function (workerKey) {
                        var deferred = injector.get('$q').defer();

                        if (workerKey && workerKey in _workerPool) {
                            var worker = _workerPool[workerKey];

                            if (worker.workerBase) { //if baseclass contain workerbase property, it is a daemon.
                                _daemons[workerKey] = worker;
                            }

                            return worker.init(this);
                        } else {
                            deferred.reject(false);
                            return deferred.promise;
                        }
                    },

                    calls: function(/*array*/ workerKeys) {
                        var promises = [];
                        var that = this;

                        if (workerKeys) {
                            if (angular.isArray(workerKeys)) {
                                angular.forEach(workerKeys, function(key){
                                    promises.push(that.call(key));
                                });
                            } else {
                                promises.push(that.call(workerKeys));
                            }
                        }

                        return promises;
                    },

                    setShared: function (workerFileName, data) {
                        this._sharedData[workerFileName] = data;
                    },

                    shared: function (key) {
                        return this._sharedData[key];
                    }
                };

                return _workerMessager;
            },



            /**
             * @ngdoc method
             * @name vpServiceModule.vpMessagerSvc#connect
             * @methodOf vpServiceModule.vpMessagerSvc
             * @param {object} windowMessager the window messager.
             * @param {object} workerMessager the  worker messager.
             * @returns none
             * @description
             * connect the provided windowMessager and workerMessager
             * which will enable auto-push of updated data from webworker to canvas iframe.
             * you need to set the pushUp to `true` in the registered webworker module.
             */
            connect: function (windowMessager, workerMessager) {
                if (!windowMessager || !workerMessager) {
                    return false;
                }

                windowMessager.worker = workerMessager;
                workerMessager.boss = windowMessager;

                var _oldworkerMessagerSetShared = workerMessager.setShared;
                workerMessager.setShared = function (key, value, pushUp) {
                    _oldworkerMessagerSetShared.apply(workerMessager, arguments);
                    windowMessager.setShared(key, value);

                    if (pushUp) {
                        this.notifyPeerMessager(key,value);
                    }
                };

                workerMessager.notifyPeerMessager = function (key, value) {
                    windowMessager.postMessage('worker.sync', {key: key, value: value});
                };

                windowMessager.onMessage('worker.sync', function(data){
                    workerMessager.postMessage('worker.sync', data);
                });
            },
        };
    }
]);