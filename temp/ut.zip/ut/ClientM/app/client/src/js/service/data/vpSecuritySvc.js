// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, ViewPoint*/

angular.module('vpDataSvcModule')

/**
 * @ngdoc service
 * @module vpDataSvcModule
 * @name vpDataSvcModule.vpSecuritySvc
 * @description this service will provide security related methods.
 */

.factory('vpSecuritySvc', [function () {
    'use strict';

    return {
        encryptStringForLogin: function(strencrypt){
            return ViewPoint.Util.ViewPointHelper.EncryptIt(strencrypt, 1);
        },
        encryptSessionID: function(sessionID){
            return ViewPoint.Util.ViewPointHelper.EncryptIt(sessionID, 0);
        }
    };
}]);