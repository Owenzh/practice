// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

'use strict';
(function () {
    'use strict';
    angular.module('appModule')
        .config(['$stateProvider',
            function ($stateProvider) {
                $stateProvider.state('alarmDetails', {
                    url: '/alarmDetails/{id}',
                    parent: 'app',
                    views: {
                        "content": {
                            templateUrl: 'js/ui/alarm/vpAlarmDetailCtrl.tpl.html',
                            controller: 'vpAlarmDetailsCtrl',
                        }
                    }
                });

            }])
        .controller('vpAlarmDetailsCtrl', ['$scope', '$rootScope', '$timeout', 'raToastSvc', 'vpAlarmUpdateManagerSvc', '$stateParams', 'raOverlaySvc', 'vpAlarmOperationSvc', 'vpErrorHandlerSvc',
            function ($scope, $rootScope, $timeout, raToastSvc, vpAlarmUpdateManagerSvc, $stateParams, raOverlaySvc, vpAlarmOperationSvc, vpErrorHandlerSvc) {
                var fTAeErrorID = {
                    RNA_AE_S_ALREADYACKED: 0x00040200,
                    RNA_AE_E_INVALIDTIME: 0xC0040205,
                    RNA_AE_E_BUSY: 0xC0040206,
                    RNA_AE_E_NOINFO: 0xC0040207,
                    RNA_AE_S_ALARMALREADYSHELVED: 0x0004B010,
                    RNA_AE_S_CONDITIONALREADYSHELVED: 0x0004B011,
                    RNA_AE_S_EXCEEDDEFAULTMAXSHELVEVALUE: 0x0004B012,
                    RNA_AE_S_ALARMALREADYUNSHELVED: 0x0004B013,
                    RNA_AE_S_ALMALREADYSHELVEDANDEXCEEDMAXVALUE: 0x0004B014,
                    RNA_AE_S_CONDALREADYSHELVEDANDEXCEEDMAXVALUE: 0x0004B015,
                    RNA_AE_S_CONDITIONALREADYUNSHELVED: 0x0004B016,
                    RNA_AE_E_SHELVENOTSUPPORTED: 0xC004B015,
                    E_INVALIDARG: 0x80070057,
                    S_OK: 0,
                    IDS_SECURITY_ERROR: 0xC0040006
                };

                function updateAlarmDetails(alarm) {
                    $scope.Area = alarm.Area;
                    $scope.State = alarm.State;
                    $scope.DisplayedState = getDisplayedState(alarm);
                    $scope.IsSuppressed = alarm.IsSuppressed;
                    $scope.EventType = alarm.EventType;
                    $scope.AckRequired = alarm.AckRequired;
                    $scope.IsActive = alarm.IsActive;
                    $scope.IsAcked = alarm.IsAcked;
                    $scope.IsInScope = alarm.IsInScope;
                    $scope.LastUpdateTime = alarm.LastUpdateTime != null ? alarm.LastUpdateTime.toString() : "";
                    $scope.ActiveTimeValue = alarm.ActiveTimeValue;
                    $scope.ActiveTime = alarm.ActiveTime != null ? alarm.ActiveTime.toString() : "";
                    $scope.Cookie = alarm.Cookie;
                    $scope.CookieHigh = alarm.CookieHigh;
                    $scope.CookieLow = alarm.CookieLow;
                    $scope.Source = alarm.Source;
                    $scope.Message = alarm.Message;
                    $scope.Severity = alarm.Severity;
                    $scope.Priority = alarm.Priority;
                    $scope.ConditionName = alarm.ConditionName;
                    $scope.CurrentValue = "" + alarm.CurrentValue;
                    $scope.ExceededLimit = alarm.ExceededLimit;
                    $scope.AlarmClass = alarm.AlarmClass;
                    $scope.AlarmName = alarm.AlarmName;
                    $scope.ServerName = alarm.ServerName;
                    var areaName = alarm.AreaName;
                    if (!!areaName) {
                    $scope.AreaName = "/" + alarm.AreaName;
                    }
                    else {
                        $scope.AreaName = alarm.AreaName;
                    }
                    $scope.IsShelved = alarm.IsShelved;
                    $scope.Tag1Value = alarm.Tag1Value;
                    $scope.Tag2Value = alarm.Tag2Value;
                    $scope.Tag3Value = alarm.Tag3Value;
                    $scope.Tag4Value = alarm.Tag4Value;
                    $scope.HmiCommand = alarm.HmiCommand;
                    $scope.AlarmCount = alarm.AlarmCount;
                    $scope.AckComment = alarm.AckComment;
                    $scope.SuppressComment = alarm.SuppressComment;
                    $scope.AckTime = alarm.IsAcked && alarm.AckTime != null ? alarm.AckTime.toString() : "";
                    $scope.ShelveTime = alarm.IsShelved && alarm.ShelveTime != null ? alarm.ShelveTime.toString() : "";
                    $scope.InActiveTime = !alarm.IsActive && alarm.InActiveTime != null ? alarm.InActiveTime.toString() : "";
                    $scope.ShelveUser = alarm.ShelveUser;
                    $scope.AlarmGroup = alarm.AlarmGroup;
                    switch(alarm.ConditionName){
                        case "HIHI":
                        case "HI":
                        case "LO":
                        case "LOLO":
                            $scope.EventCategory = "Level";
                            break;
                        case "TRIP":
                            $scope.EventCategory = "Discrete";
                            break;
                        case "DEV_HI":
                        case "DEV_LO":
                            $scope.EventCategory = "Deviation";
                            break;
                        case "STATUS":
                            $scope.EventCategory = "System";
                            break;
                    }
                    $scope.IsDisabled = alarm.IsDisabled;
                }

                function getDisplayedState(alarm) {
                    var state = alarm.State;
                    var parsedState = '';
                    if ((state & 1) !== 0) {
                        parsedState += 'Normal';
                    }
                    if ((state & 2) !== 0) {
                        parsedState += 'In Alarm';
                    }

                    if ((state & 4) !== 0) {
                        parsedState += ', Acked';
                    } else {
                        parsedState += ', UnAcked';
                    }
                    if(alarm.IsDisabled){
                        parsedState += ', Disabled'
                    }
                    if(alarm.IsSuppressed){
                        parsedState += ', Suppressed'
                    }
                    if(alarm.IsShelved){
                        parsedState += ', Shelved'
                    }
                    if ((state & 8) !== 0) {
                        parsedState += 'Faulted';
                    }
                    return parsedState;
                }
                function updateAlarmEvents(events) {
                    if (events && angular.isArray(events)) {
                        for (var i = 0; i < events.length; i++) {
                            var alarm = events[i].data;
                            if ($scope.Id == alarm.Id) {
                                updateAlarmDetails(alarm);
                            }
                        }
                    }
                }

                var OPERATION_STATUS_TOASTER_ID = 'vpAlarmOperationStatusToaster';
                var OPERATION_STATUS_TOASTE_ID = 'vpAlarmOperationStatusToaste';

                function popupAlarmOperationMessage(type, message, timeout) {
                    raToastSvc.clear(OPERATION_STATUS_TOASTER_ID, OPERATION_STATUS_TOASTE_ID);
                    $timeout(function () {
                        raToastSvc.pop(message, {
                            type: type,
                            toasterId: OPERATION_STATUS_TOASTER_ID,
                            toastId: OPERATION_STATUS_TOASTER_ID,
                            timeout: timeout
                        });
                    }, 0);
                }
                $scope.clickAcknowledgeAction = function(){
                    if (!$scope.IsAcked) {
                        $timeout(function () {
                            raOverlaySvc.openWithOptions({
                                controller: "vpAlarmAcknowledgeOverlayCtrl",
                                templateUrl: 'js/ui/alarm/vpAlarmAcknowledgeOverlayCtrl.tpl.html',
                                windowClass: "ra-message-overlay vp-alarm-acknowledge-overlay",
                                keyboard: false,
                                backdrop: 'static'
                            }, {
                                AlarmName: $scope.AlarmName,

                            }).result.then(function (option) {

                                var ackDesc = new Array();

                                var tempDesc = {
                                    areaName: $scope.Area + $scope.AreaName,
                                    strSource: $scope.Source,
                                    strConditionName: $scope.ConditionName,
                                    lActiveTime: $scope.ActiveTimeValue,
                                    lCookie: $scope.Cookie
                                };

                                ackDesc.splice(0, 0, tempDesc);

                                var ackAlarmParam = {
                                    szComment: option.AckComment ? option.AckComment : "",
                                    ackDesc: ackDesc
                                };

                                popupAlarmOperationMessage('info', 'Sending Ack command to server.', 2000);
                                vpAlarmOperationSvc.ackAlarm(ackAlarmParam).then(
                                    function (value) {
                                        var tempJsonData = eval(value.AckAlarmsResult);

                                        for (var index = 0; index < tempJsonData.length; index++) {
                                            if (tempJsonData[index].result == 0) {
                                                var itemArray = tempJsonData[index].strSource.split(":");
                                                var itemArrayLength = itemArray.length;
                                                var alarmServerName = tempJsonData[index].areaName;
                                                var alarmName = itemArray[itemArrayLength - 1];
                                                if (itemArrayLength > 2) {
                                                    alarmServerName = alarmServerName + ":" + itemArray[itemArrayLength - 2];
                                                }
                                                var strMessage = "Acknowledged alarm [" + alarmName + "] in alarm server [" + alarmServerName + "]";
                                                popupAlarmOperationMessage('success', strMessage, 2000);
                                            }
                                            else if (tempJsonData[index].result == fTAeErrorID.IDS_SECURITY_ERROR) {
                                                var strMessage = "Failed to Acknowledge alarm " + tempJsonData[index].strSource + ". " + tempJsonData[index].userName + " does not have Acknowledge permission.";
                                                popupAlarmOperationMessage('warning', strMessage, 5000);
                                            }
                                            else {
                                                processResponse(tempJsonData[index].strSource, tempJsonData[index].strConditionName, tempJsonData[index].result, 5000);
                                            }
                                        }
                                    },
                                    function (reason) {
                                        vpErrorHandlerSvc.propagate(vpErrorHandlerSvc.getHTTPError(reason));
                                    }
                                );
                            }, function (reason) {
                                  //No operation when user click cancel in the ack dlg.
                            });
                        }, 0);
                    }
                }
                function processResponse(sourceName, conditionName, errorResult, timeout) {
                    var strMessage = "";
                    var csSourceConditionName = sourceName;
                    switch (errorResult) {
                        case fTAeErrorID.S_OK:
                        {
                            break;
                        }
                        case fTAeErrorID.RNA_AE_S_ALREADYACKED:
                        {
                            strMessage = "Failed to acknowledge alarm" + csSourceConditionName + ". The alarm is already acked";
                            break;
                        }
                        case fTAeErrorID.RNA_AE_E_INVALIDTIME:
                        {
                            strMessage = "Failed to acknowledge alarm" + csSourceConditionName + ". The time does not match last active time";
                            break;
                        }
                        case fTAeErrorID.E_INVALIDARG:
                        {
                            strMessage = "Failed to acknowledge alarm" + csSourceConditionName + ". Bad Argument Passed to Server";
                            break;
                        }
                        case fTAeErrorID.RNA_AE_E_SHELVENOTSUPPORTED:
                        {
                            strMessage = "Failed to shelve alarm" + csSourceConditionName + ". Shelve command is not supported for this alarm.";
                            break;
                        }
                        case fTAeErrorID.RNA_AE_S_ALARMALREADYSHELVED:
                        {
                            strMessage = "Shelve succeeds with warning: The alarm" + csSourceConditionName + " is already shelved.The shelve duration has been successfully updated.";
                            break;
                        }
                        case fTAeErrorID.RNA_AE_S_CONDITIONALREADYSHELVED:
                        {
                            strMessage = "Shelve succeeds with warning: The alarm" + csSourceConditionName + " has previously shelved conditions.The shelve duration has been successfully updated for all shelved conditions.";
                            break;
                        }
                        case fTAeErrorID.RNA_AE_S_EXCEEDDEFAULTMAXSHELVEVALUE:
                        {
                            strMessage = "Shelve succeeds with warning: Unshelve time of alarm" + csSourceConditionName + " exceeds default max value, and it is actually set to default.";
                            break;
                        }
                        case fTAeErrorID.RNA_AE_S_ALMALREADYSHELVEDANDEXCEEDMAXVALUE:
                        {
                            strMessage = "Shelve succeeds with warning: Reshelve duration of alarm" + csSourceConditionName + " exceeds default max value, the default value applied.";
                            break;
                        }
                        case fTAeErrorID.RNA_AE_S_CONDALREADYSHELVEDANDEXCEEDMAXVALUE:
                        {
                            strMessage = "Reshelve duration of the currently shelved levels for alarm" + csSourceConditionName + " exceeds default max value, the default value applied";
                            break;
                        }
                        default:
                        {
                            strMessage = "Request response item" + csSourceConditionName + " no default error string is defined.\n";
                            break;
                        }
                    }
                    popupAlarmOperationMessage('error', strMessage, timeout);
                }
				
		$scope.clickShelveAction = function(){
			$timeout(function () {
				raOverlaySvc.openWithOptions({
					controller: "vpAlarmShelveOverlayCtrl",
					templateUrl: 'js/ui/alarm/vpAlarmShelveOverlayCtrl.tpl.html',
					windowClass: "ra-message-overlay vp-alarm-shelve-overlay",
					keyboard: false,
					backdrop: 'static'
				}, {
					AlarmName: $scope.AlarmName,

				}).result.then(function (option) {

					var shelveDesc = new Array();

					var tempDesc = {
						areaName: $scope.Area + $scope.AreaName,
						strSource: $scope.Source,
						strConditionName: $scope.ConditionName
					};

					shelveDesc.splice(0, 0, tempDesc);
							
					var shelveAlarmParam = {
						bNewState: 1,
						dwTargetDuration:option.Duration ? option.Duration : 1,
						szComment: option.ShelveComment ? option.ShelveComment : "",
						shelveDesc: shelveDesc
					};

					popupAlarmOperationMessage('info', 'Sending Shelve command to server.', 2000);
					vpAlarmOperationSvc.shelveAlarm(shelveAlarmParam).then(
						function (value) {
							var tempJsonData = eval(value.ShelveAlarmsResult);

							for (var index = 0; index < tempJsonData.length; index++) {
								if (tempJsonData[index].result == 0) {
									var itemArray = tempJsonData[index].strSource.split(":");
									var itemArrayLength = itemArray.length;
									var alarmServerName = tempJsonData[index].areaName;
									var alarmName = itemArray[itemArrayLength - 1];
									if (itemArrayLength > 2) {
										alarmServerName = alarmServerName + ":" + itemArray[itemArrayLength - 2];
									}
									var strMessage = "Shelved alarm [" + alarmName + "]([" + tempJsonData[index].strConditionName + "]) in alarm server [" + alarmServerName + "]";
									popupAlarmOperationMessage('success', strMessage, 2000);
								}
								else if (tempJsonData[index].result == fTAeErrorID.IDS_SECURITY_ERROR) {
									var strMessage = "Failed to Shelve alarm " + tempJsonData[index].strSource + ". " + tempJsonData[index].userName + " does not have Shelve permission.";
									popupAlarmOperationMessage('warning', strMessage, 5000);
								}
								else {
									processResponse(tempJsonData[index].strSource, tempJsonData[index].strConditionName, tempJsonData[index].result, 5000);
								}
							}
						},
						function (reason) {
							vpErrorHandlerSvc.propagate(vpErrorHandlerSvc.getHTTPError(reason));
						}
					);
				}, function (reason) {
					  //No operation when user click cancel in the shelve dlg.
				});
			}, 0);
                }
                var id = decodeURIComponent($stateParams.id);

                $scope.Id = id;

                var alarm = vpAlarmUpdateManagerSvc.getAlarm(id);
                if (alarm) {
                    updateAlarmDetails(alarm);
                }

                // when receive any alarm events update, calculate filtered alarms again
                vpAlarmUpdateManagerSvc.registerAlarmUpdatedHandler(updateAlarmEvents);
                vpAlarmUpdateManagerSvc.registerAlarmUpdatedErrorHandler(setAlarmServiceDisconnected);

                $scope.$on('$destroy', function () {
                    vpAlarmUpdateManagerSvc.unregisterAlarmUpdatedHandler(updateAlarmEvents);
                    vpAlarmUpdateManagerSvc.unregisterAlarmUpdatedErrorHandler(setAlarmServiceDisconnected);
                });





                function setAlarmServiceDisconnected() {
                    $rootScope.$emit('app:displayErrorPage','serverdown');
                }

            }
        ]);


})();