// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app, window*/

(function () {
    'use strict';
    angular.module('appModule')

    .config(['$stateProvider',
        function ($stateProvider) {
            $stateProvider.state('app', {
                abstract: true,
                url: '',
                controller: 'vpAppCtrl as app',
                templateUrl: 'js/ui/app/vpAppCtrl.tpl.html'
            });
        }
    ])

    /**
     * @ngdoc controller
     * @module appModule
     * @name appModule.vpAppCtrl
     * @description this controller take hold of the whole UI framework,
     *  which enable visitor to access header and sidebar.
     */

    .controller('vpAppCtrl', [
        '$injector',
        '$scope',
        app.createClass({
            constructor: function($injector, scope){
                var $q = $injector.get('$q');
                var userName = app.env.get('User');
                var vpDataStoreSvc = $injector.get('vpDataStoreSvc');

                this.groupId = 'vpAppId';
                this.injector = $injector;
                this.scope = scope;
                this.user = {
                    name: userName
                };

                this.initMenuList();
                this.initUIConfig();
                this.bindEvents();
                this.loaded = false;
                this.msgCache = vpDataStoreSvc.getCacheStore('messageRibbon', true).getStore();
                this.msgoptions = {
                    hideDelay: 2,
                    type: 3,  /* success */
                    cache: this.msgCache
                };

                $q.when($injector.get('vpAppSvc').startupApp(app)).then(
                    this.onLoaded.bind(this),
                    this.onErrorLoaded.bind(this)
                );

                this.updateAlarmCount(true);
            },

            onLoaded: function () {
                this.loaded = true;
                app.state.set('loaded');
                this.scope.$emit('app:loaded');
            },

            onErrorLoaded: function (err) {
                this.onLoaded();
                app.errorLoad = true;
                console.log('error', err);
                this.scope.$emit('app:toggleLoadingStatus', false);
            },

            initMenuList: function () {
                var that = this;
                var vpWebHandlerDataSvc = that.injector.get('vpWebHandlerDataSvc');
                var SidebarMenuItems = this.injector.get('Const.SidebarMenuItems');
                var isSecurityLocked = !!this.user.name;

                // when user name is returned from serverside, we think the security is on.
                var vpDlgSvc = this.injector.get('vpDlgSvc');

                var menuActions = that.menuActions = {
                    showAbout: function () {
                        vpDlgSvc.showAbout({
                            userName: this.user.name
                        });
                    },

                    logoff: function () {
                        vpDlgSvc.logoff({
                            title: app.translateSvc.instant("VP_APP.MENU.LOGOFF_TITLE"),
                            confirmationDesc: ""
                        }).then(function () {
                            vpWebHandlerDataSvc.returnClientLicense(false);

                            // `vpSubmitParentDir` directive subscribe to this event.
                            that.scope.$emit('app:logoff');
                        });
                    }
                };

                this.navigationItems = [];

                angular.forEach(SidebarMenuItems.navigationItems, function(item) {
                    if (!item) return false;

                    if (item.auth && !isSecurityLocked) return false;

                    var navigationItem = {
                        badgeStyle: item.badgeStyle,
                        iconClasses: item.icon,
                        name: item.title,
                        state: item.state
                    };

                    if (item.default && !that.defaultItem) {
                        that.initDefaultItem(item);
                    }

                    // if (item.state)
                    navigationItem.onItemClick = function(_item) {
                        _item = _item || item;
                        return that.header.menuAction(_item);
                    };

                    that.navigationItems.push(navigationItem);
                });

                // process `generalItems` of `raSidebarDefaultContent`
                this.generalItems = [];

                angular.forEach(SidebarMenuItems.generalItems, function(item) {
                    if (!item) return false;

                    if (item.auth && !isSecurityLocked) return false;

                    var generalItem = {
                        href: item.href,
                        iconClasses: item.icon,
                        name: app.translateSvc.instant(item.title),
                        popup: item.popup
                    };

                    if (item.href) {
                        generalItem.onItemClick = function (_item) {
                            _item = _item || item;
                            var target = _item.popup ? '_blank' : '_self';
                            window.open(_item.href, target);
                        };

                    } else if (item.action && typeof(item.action) === 'string') {
                        var action = menuActions[item.action];

                        if (typeof action === 'function') {
                            generalItem.onItemClick = angular.bind(that, action);
                        }
                    }

                    that.generalItems.push(generalItem);
                });
            },

            getTabletNavbarHeader: function() {
                if (this.header) {
                    return this.header.headers[0];

                } else {
                    return this.injector.get('vpAppCompSvc').getHeader(this).headers[0];
                }
            },

            getPhoneNavbarHeader: function() {
                if (this.header) {
                    return this.header.headers[1];

                } else {
                    return this.injector.get('vpAppCompSvc').getHeader(this).headers[1];
                }
            },

            setHeader: function (header) {
                this.header = header;
            },

            getSidebar: function() {
                if (this.sidebar) {
                    return this.sidebar;

                } else {
                    return this.injector.get('vpAppCompSvc').getSideBar(this);
                }
            },

            initUIConfig: function () {
                this.navbarConfig = {
                    app: this
                };

                this.sidebar = this.injector.get('vpAppCompSvc').getSideBar(this);
            },

            initDefaultItem: function (item) {
                this.defaultItem = item;
            },

            showError: function (type, data) {
                this.hasError = true;
                this.errorData = angular.extend({type: type},data);
            },

            hideError: function () {
                this.hasError = false;
                this.errorData = null;
            },

            bindEvents: function () {
                var that = this;
                var rootscope = this.injector.get('$rootScope');
                var $window = this.injector.get('$window');
                var timeout = this.injector.get('$timeout');
                var storeHelper = this.injector.get('vpDataStoreSvc').getOfflineStoreHelper();

                if (rootscope) {
                    rootscope.$on('app:displayErrorPage', function (event, messageType, data) {
                        timeout(function(){
                            that.showError(messageType, data);
                        });
                    });
                }

                var unloaded = false;
                angular.element($window).on('unload beforeunload', function () {
                    if (!unloaded) {
                        storeHelper.clientID.save(app.env.get('clientID'));
                        unloaded = true;
                    }
                });
            },

            initDisplayCount: function() {
                var vpDisplaySvc = this.injector.get('vpDisplaySvc'),
                    vpAppCompSvc = this.injector.get('vpAppCompSvc'),
                    that = this;
                
                vpDisplaySvc.getDisplayList().then(function(displayList) {
                    var displayCount = displayList.getDisplayCount();

                    that.getSidebar().setDisplayCount(displayCount);
                });
            },

            updateAlarmCount: function(isInit) {
                var vpAlarmUpdateManagerSvc = this.injector.get('vpAlarmUpdateManagerSvc'),
                    alarmCount = vpAlarmUpdateManagerSvc.getActiveAlarmCount();

                this.getPhoneNavbarHeader().setAlarmCountOnBadge(alarmCount);
                this.getSidebar().setAlarmCount(alarmCount);

                if (isInit) {
                    vpAlarmUpdateManagerSvc.registerAlarmUpdatedHandler(function(events) {
                        this.updateAlarmCount();
                    }.bind(this));
                }
            }
        })
    ]);
})();