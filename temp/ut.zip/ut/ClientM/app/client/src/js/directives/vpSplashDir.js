// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('vpDirectiveModule')

/**
 * @ngdoc directive
 * @name vpDirectiveModule.directive:vpSplash
 * @module vpDirectiveModule
 * @restrict A
 *
 * @description
 * The directive is responsible to remove the splash screen
 * while the application finish loading.
 *
 * @example
 * <example module="mobile-toolkit-ra">
 *  <file name="index.html">
 *      <div id="splashscreen" vp-splash>
 *      </div>
 *  </file>
 * </example>
 */

.directive('vpSplash', [
  '$rootScope',
  '$timeout',
  '$animate',
  function($rootScope, $timeout, $animate) {
    'use strict';

    return {
      restrict: 'A',
      link: function (scope, element) {
        var offme = $rootScope.$on('app:loaded', function(){
          $timeout(function(){
            $animate.removeClass(element, "fadeIn").then(function(){
                element.remove();
            });
          });
        });

        element.on('$destroy', function() {
           offme();
           offme = null;
        });
      }
    };
}]);