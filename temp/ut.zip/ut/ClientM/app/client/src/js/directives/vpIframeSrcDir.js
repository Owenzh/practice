// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('vpDirectiveModule')
  .directive('vpIframeSrc', [function() {
    'use strict';
      return {
        restrict: 'A',
        link: function(scope, element, attrs) {
          attrs.$observe('vpIframeSrc', function(value) {
            if (value) {
              element[0].contentWindow.location.replace(value);
            }
          })
        }
      };
  }]);
