// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/
/*jshint sub:true*/
angular.module('vpServiceModule')

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpLicenseUpdateManagerSvc
 * @description this service will provide information license update manager
 */

.factory('vpLicenseUpdateManagerSvc', [
    '$injector',
    function($injector) {
        "use strict";
        var vpAdminPingDataSvc = $injector.get('vpAdminPingDataSvc');
        var vpErrorHandlerSvc = $injector.get('vpErrorHandlerSvc');
        var vpAppConstSvc = $injector.get('vpAppConstSvc');
        var rootScope = $injector.get('$rootScope');
        var vpAdminPingConsts = vpAdminPingDataSvc.getServiceConsts();
        var appConstants = vpAppConstSvc.appConstants;
        var licenseDaemon = vpAdminPingDataSvc.licenseDaemon;
        var vpAlarmUpdateManagerSvc =  $injector.get('vpAlarmUpdateManagerSvc');

        var Employer = {
            employeeWorker: function(worker) {
                this.worker = worker;
                this.client = worker.messager;
            }
        };

        var ServerStatusChecker = {
            check: function(manager, statusReturned) {
                var serverStatus = {};
                var clientStatus = {};
                var err = '';

                if (angular.isArray(statusReturned)) {
                    angular.forEach(statusReturned, function(item) {
                        serverStatus[item.key] = item.value;
                    });
                } else {
                    serverStatus[statusReturned.key] = statusReturned.value;
                }

                if (this.isSessionExpired(serverStatus)) {
                    manager.stop();
                    vpAlarmUpdateManagerSvc.stop();
                    err = "license updater call failed - session expired.";
                    clientStatus[appConstants['SESSION_EXPIRED_STATUS_KEY']] = true;
                    rootScope.$emit('app:displayErrorPage', 'sessionExpired');
                    return [false, err, clientStatus];
                }

                if (this.needClientReload(serverStatus)) {
                    manager.stop();
                    vpAlarmUpdateManagerSvc.stop();
                    err = "license updater call failed - currentDisplay needed reload.";
                    clientStatus[appConstants['RELOAD_CURRENT_DISPLAY_STATUS_KEY']] = true;
                    return [false, err, clientStatus];
                }

                var nClientPollingRate = this.getClientPollingRate(serverStatus);
                clientStatus[appConstants['CLIENT_POLLING_RATE_KEY']] = nClientPollingRate;

                var licenseStatus = this.getLicenseAllocatedInformation(serverStatus);
                clientStatus[appConstants['LICENSE_ALLOCATED_STATUS_KEY']] = licenseStatus;

                var bIsGraceMode = this.getGraceInformation(serverStatus);
                clientStatus[appConstants['LICENSE_GRACE_MODE_STATUS_KEY']] = bIsGraceMode;
                app.env.set('isGraceMode', bIsGraceMode);

                if (!licenseStatus.bLicenseAllocatedEntryFound) {
                    err = "license updater call failed - License Allocated not returned.";
                    return [false, err, clientStatus];
                }

                if (!licenseStatus.bLicenseAllocatedValueValid) {
                    err = "license updater call failed - License Allocated returned but not valid.";
                    return [false, err, clientStatus];
                }

                if (licenseStatus.bLicenseAllocated) {
                    return [true, false, clientStatus];
                }

                if (manager.worker) {
                    clientStatus['TryGetClientLicense'] = true;
                    manager.worker.getMessager().call('getLicense');
                }

                return [false, 'license is not available, try to refetch', clientStatus];
            },

            needClientReload: function(serverStatus) {
                var key = appConstants['RELOAD_CURRENT_DISPLAY_STATUS_KEY'];
                var targetValue = appConstants['CURRENT_STATUS_PROPERTY_VALUE_TRUE'];
                return serverStatus && serverStatus[key] === targetValue;
            },

            getGraceInformation: function(serverStatus) {
                var key = appConstants['LICENSE_GRACE_MODE_STATUS_KEY'];
                var targetValue = appConstants['CURRENT_STATUS_PROPERTY_VALUE_TRUE'];
                return serverStatus && serverStatus[key] === targetValue;
            },

            getLicenseAllocatedInformation: function(serverStatus) {
                var bLicenseAllocatedEntryFound = false;
                var bLicenseAllocatedValueValid = false;
                var bLicenseAllocated = false;

                var key = appConstants['LICENSE_ALLOCATED_STATUS_KEY'];
                var status = serverStatus && serverStatus[key];
                var targetValueTrue = appConstants['CURRENT_STATUS_PROPERTY_VALUE_TRUE'];
                var targetValueFalse = appConstants['CURRENT_STATUS_PROPERTY_VALUE_FALSE'];

                if (status) {
                    bLicenseAllocatedEntryFound = true;

                    if (status === targetValueTrue) {
                        bLicenseAllocatedValueValid = true;
                        bLicenseAllocated = true;
                    } else if (status === targetValueFalse) {
                        bLicenseAllocatedValueValid = true;
                    }
                }

                return  {
                    bLicenseAllocatedEntryFound: bLicenseAllocatedEntryFound,
                    bLicenseAllocatedValueValid: bLicenseAllocatedValueValid,
                    bLicenseAllocated: bLicenseAllocated
                };
            },

            getClientPollingRate: function(serverStatus) {
                var key = appConstants['CLIENT_POLLING_RATE_KEY'];
                return Number(serverStatus[key]) || appConstants['CLIENT_POLLING_RATE_DEFAULT_VALUE'];
            },

            isSessionExpired: function(serverStatus) {
                var key = appConstants['SESSION_EXPIRED_STATUS_KEY'];
                var targetValue = appConstants['CURRENT_STATUS_PROPERTY_VALUE_TRUE'];
                return serverStatus && serverStatus[key] === targetValue;
            }
        };

        return angular.extend({}, Employer, {
            employeeWorker: function(worker) {
                Employer.employeeWorker.apply(this, arguments);
                licenseDaemon.setWebWorker(worker);
            },

            start: function() {
                licenseDaemon.call('start');
            },

            stop: function() {
                licenseDaemon.terminate();
            },

            checkServerData: function(data) {
                if (!data) {
                    return [false, 'data not available'];
                }

                var status = data.serverStatus;
                var err = '';

                if (status !== vpAdminPingConsts.statusCodes[0 /* Success */ ]) {
                    err = 'license updater call failed - return code: ' + status + '.);';
                    return [false, err];
                }

                var clientStatusResponse = data.resp;

                if (!clientStatusResponse) {
                    err = "license updater call failed - returned a 'null' ClientStatusResponse.";
                    return [false, err];
                }

                var statusReturned = clientStatusResponse.S.KeyValuePairOfstringstring;
                if (!statusReturned) {
                    err = "license updater call failed - returned a 'null' ClientStatusResponse.Status.";
                    return [false, err];
                }

                return ServerStatusChecker.check(this, statusReturned);
            },

            onsuccess: function(data) {
                var parsed = this.checkServerData(data); //0 - state(true/false), 1-errorMessage, 2- clientStatus
                if (parsed[0]) {
                    this.worker.onsuccess(parsed[2]);
                } else {
                    this.onerror(parsed[1], parsed[2]);
                }
            },

            onerror: function(err, clientStatus) {
                vpErrorHandlerSvc.propagate(err);
                this.worker.onerror(clientStatus);
            },

            resetSessionTimeout: function() {
                vpAdminPingDataSvc.resetSessionTimeout();
            }
        });
    }
]);