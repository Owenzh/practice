// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('vpDirectiveModule')

/**
 * @ngdoc directive
 * @name vpDirectiveModule.directive:vpLoading
 * @module vpDirectiveModule
 * @restrict A
 *
 * @description
 * The directive is responsible to remove the splash screen
 * while the application finish loading.
 *
 * @example
 * <example module="mobile-toolkit-ra">
 *  <file name="index.html">
 *      <div vp-loading>
 *      </div>
 *  </file>
 * </example>
 */

.directive('vpLoading', [
  '$rootScope',
  '$templateCache',
  '$modal',
  '$timeout',
  function($rootScope, $templateCache, $modal, $timeout) {
    'use strict';
    var modalInstance = null;
    var template = $templateCache.get('js/directives/vpLoadingDir.tpl.html');
    function toggleLoadingStatus (element, status) {
       if (status) {
          if (!modalInstance) {
            element.addClass('loading');
            modalInstance = $modal.open({
                template: template,
                animation: true,
                backdrop: 'static',
                size:'sm',
                windowClass: 'loadingDlg',
                keyboard: false
            });
          }
       } else {
          element.removeClass('loading');
          if (modalInstance) {
              modalInstance.close();
              modalInstance = null;
          }
       }
    }


    return {
      restrict: 'A',
      link: function (scope, element) {
          element.on('$destroy', function() {
             toggleLoadingStatus(element, false);
             offme();
             offme = null;
          });

          if($rootScope.showLoading) {
             $rootScope.showLoading = null;
             toggleLoadingStatus(element, true);
          }

          var offme = $rootScope.$on('app:toggleLoadingStatus', function(event, /*boolean*/ status){
              $timeout(function(){
                toggleLoadingStatus(element, status);
              });
          });
      }
    };
}]);