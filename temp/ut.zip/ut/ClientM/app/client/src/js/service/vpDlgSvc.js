// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('vpServiceModule')

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpDlgSvc
 * @description this service will provide methods to manipulate display.
 */

.factory('vpDlgSvc', [
    'raMessageSvc',
    'raOverlaySvc',
    function (raMessageSvc, raOverlaySvc) {
        "use strict";

        return {
            showAbout: function (config) {
                raOverlaySvc.openWithOptions({
                    controller: "vpAboutCtrl",
                    templateUrl: 'js/ui/overlay/vpAboutCtrl.tpl.html',
                    windowClass: "ra-overlay-about ra-message-overlay",
                    keyboard: false,
                    backdrop: 'static'
                }, config);
            },

            logoff: function (config) {
                return raOverlaySvc.openWithOptions({
                    controller: "vpConfirmCtrl",
                    templateUrl: 'raMessage/raMessageOverlay.tpl.html',
                    windowClass: "ra-message-overlay centerMFTDlg",
                    keyboard: false,
                    backdrop: 'static'
                }, config).result;
            }
        };
    }
]);