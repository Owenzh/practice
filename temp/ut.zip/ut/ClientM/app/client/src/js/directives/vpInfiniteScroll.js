/*global angular*/

angular.module('vpDirectiveModule')
  .directive('vpInfiniteScroll', [
    '$timeout',
    '$window',
    vpInfiniteScrollDirective
  ]);


function vpInfiniteScrollDirective($timeout, $window) {
  return {
    restrict: 'E',
    scope: {
      onInfinite: '&',
      allItems: '=',
      shownItems: '='
    },
    link: function($scope, $element, $attrs) {
      var $parent = $element.parent(),
        parentOverflowYStyle = $window.getComputedStyle($parent[0]).overflowY;

      // should inside a scrollable container
      if (parentOverflowYStyle !== 'auto' && parentOverflowYStyle !== 'scroll') {
        throw 'Infinite scroll must be used inside a scrollable container.';
      }

      $parent.on('scroll', checkBounds);

      $scope.$on('$destroy', function() {
        $parent.off('scroll', checkBounds);
      });

      function checkBounds() {
        var distanceFactor = $scope.shownItems.length / $scope.allItems.length;

        if ($parent[0].scrollTop >= ($parent[0].scrollHeight - $parent[0].clientHeight) * distanceFactor) {
          $timeout(function() {
            $scope.onInfinite();
          }, 0);
        }
      }
    }
  };
}
