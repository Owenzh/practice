// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

angular.module('vpFilterModule')

.filter('vpAlarmPriority', function() {
  var alarmPriorityMap = {
    0: 'None',
    1: 'Low',
    2: 'Medium',
    3: 'High',
    4: 'Urgent'
  };
  return function(priority) {
    return alarmPriorityMap[priority];
  }
});
