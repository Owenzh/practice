// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

angular.module('vpDirectiveModule')

/**
 * @ngdoc directive
 * @name vpDirectiveModule.directive:vpNavbarResponsive
 * @module vpDirectiveModule
 * @restrict A
 *
 * @description
 * The directive create a navbar which will switch between raNavbar and raNavbarLarge
 * according to the device resolution.
 * content section.
 * @example
 * <example module="mobile-toolkit-ra">
 *  <file name="index.html">
        <div vp-navbar-responsive vp-navbar-config="::app.navbarConfig"></div>
 *  </file>
 * </example>
 */

.directive('vpNavbarResponsive', [
  'vpAppCompSvc',
  '$templateCache',
  '$sce',
  function(vpAppCompSvc, $templateCache) {
    'use strict';


    var vpNavbarResponsiveCtrl = app.createClass({
      constructor: function() {
        this.app = this.config.app;
        this._header = vpAppCompSvc.getHeader(this.app);
      },

      getConfig: function (id) {
        return this._header.getConfig(id);
      }
    });

    return {
      restrict: 'A',
      scope: {
        config: '=vpNavbarConfig'
      },
      replace: true,
      template: $templateCache.get('js/directives/vpNavbarResponsiveDir.tpl.html'),
      controller: vpNavbarResponsiveCtrl,
      controllerAs: 'nbRespCtrl',
      bindToController: true,
      link: function(scope, element, attrs, nbRespCtrl) {
        app.scope.$on('app:updateTitle', function(event, title, link) {
          nbRespCtrl._header.updateTitle(title, link);
        });

        //icon: [iconUrl, iconMsg]
        app.scope.$on('app:updateTitleIcon', function(event, icon) {
          nbRespCtrl._header.updateTitleIcon(icon);
        });
      }
    };
  }
]);