/*global angular*/
(function() {
  'use strict';

  /**
   * @ngdoc directive
   * @module vpDirectiveModule
   * @name vpDirectiveModule.directive:vpAlarmBackToTop
   *
   * @description
   * This directive is currently used in alarm view at `js/ui/alarm/vpAlarmCtrl.tpl.html`.
   * You must pass an id of a scrollable container like this:
   * ```html
   * <vp-alarm-back-to-top="vpAlarmList"></a>
   * ```
   *
   * When click back to top and have new alarms, event `vp.backtotop.reset`
   * will be emit on `$rootScope`.
   *
   * # Behavior
   *
   * * When at the top, back to top button should be disabled.
   * * When scrolled, back to top button should be enabled.
   * * When scrolled and new alarms come in, show a red bullet on the button.
   * * When click back to top:
   *   * Disable button and remove red bullet
   *   * If new alarms come in during scrolling, clear quick filter and popup filter, and
   *     set sort option to "Newest".
   *   * If no new alarms during scrolling, just return to top without resetting.
   *
   * @param {String} vpAlarmBackToTop The HTML id property of a scrollable container.
   * @element ANY
   */
  angular.module('vpDirectiveModule')
    .directive('vpAlarmBackToTop', vpAlarmBackToTopDirective);

  vpAlarmBackToTopDirective.$inject = ['$rootScope', 'vpAlarmUpdateManagerSvc'];

  function vpAlarmBackToTopDirective($rootScope, vpAlarmUpdateManagerSvc) {
    return {
      link: function($scope, $element, $attrs) {
        var BACKTOTOP_INACTIVE_CLASS = 'vp-alarm-backtotop-inactive';

        // A flag to indicate if emit `vp.backtotop.reset` event or not,
        // sort and filter components will subscribe this event to reset the options
        var hasNewAlarms = false;

        var scrollableContainerId = $attrs.vpAlarmBackToTop,
          $scrollableContainer = $('#' + scrollableContainerId),
          $updateIndicator = angular.element('<i class="vp-alarm-update-indicator vp-hide"></i>');

        if (scrollableContainerId === '') {
          throw new Error('Directive "vp-alarm-back-to-top" requires a scrollable container id.');
        }

        $element.append($updateIndicator);
        $element.addClass(BACKTOTOP_INACTIVE_CLASS);

        $element.on('click', backToTop);
        $scrollableContainer.on('scroll', onScroll);
        vpAlarmUpdateManagerSvc.registerAlarmUpdatedHandler(updateIndicatorStatus);

        $scope.$on('$destroy', function() {
          $element.off('click', backToTop);
          $scrollableContainer.off('click', onScroll);
          vpAlarmUpdateManagerSvc.unregisterAlarmUpdatedHandler(updateIndicatorStatus);
        });

        function calculateScrollY() {
          return $scrollableContainer[0].scrollTop;
        }

        function updateIndicatorStatus(events) {
          if (calculateScrollY() !== 0) {
            $element.removeClass(BACKTOTOP_INACTIVE_CLASS);
            $updateIndicator.removeClass('vp-hide');
            hasNewAlarms = true;

          } else {
            $element.addClass(BACKTOTOP_INACTIVE_CLASS);
            $updateIndicator.addClass('vp-hide');
            hasNewAlarms = false;
          }
        }

        function backToTop() {
          if (calculateScrollY() !== 0) {
            $scrollableContainer.animate({
              scrollTop: 0
            }, "fast");

            $updateIndicator.addClass('vp-hide');

            if (hasNewAlarms) {
              $rootScope.$emit('vp.backtotop.reset', hasNewAlarms);
              hasNewAlarms = false;
            }
          }
        }

        function onScroll() {
          if (calculateScrollY() !== 0) {
            $element.removeClass(BACKTOTOP_INACTIVE_CLASS);

          } else {
            $element.addClass(BACKTOTOP_INACTIVE_CLASS);
            $updateIndicator.addClass('vp-hide');
            hasNewAlarms = false;
          }
        }
      }
    };
  }
})();
