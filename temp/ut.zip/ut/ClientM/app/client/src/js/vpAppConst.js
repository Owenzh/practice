// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('appModule')

.constant('Const.App', {
  productName: 'FactoryTalk ViewPoint',
  productVersion: '8.10.23',
  productVersionFile: '/ftvp/buildNumber.txt',
  companyName: 'Rockwell Automation Inc.'
})

.constant('Const.App.Framework', {
  version: '1.0',
  clientidKey: 'FTVP_Instance_Info.xml'
})

.constant('Const.App.resource', {
  siteLogo: 'img/FTViewPoint-logo.png',
  siteSubtitle: 'A Visualization Application'
})

.constant('Const.App.resource.displayAccessRight', [
  ['ra-icon-read-only', "Current display(s) are authorized for read-only"],   //readonly
  ['ra-icon-read-write', "Current display(s) are authorized for read-write"], //readwrite
  ['ra-icon-read-only-write', "Warning, there are a mixture of read-only and read-write displays"]
  //readonlywrite (there are multiple displays on current page with mixed authorizations)
])

.constant('Const.About.media', [{
  name: 'facebook',
  iconClass: 'media-facebook',
  link: 'http://www.facebook.com/ROKAutomation'
}, {
  name: 'twitter',
  iconClass: 'media-twitter',
  link: 'http://twitter.com/ROKAutomation'
}, {
  name: 'googleplus',
  iconClass: 'media-googleplus',
  link: 'https://plus.google.com/+RockwellautomationInc/posts'
}, {
  name: 'linkedin',
  iconClass: 'media-linkedin',
  link: 'https://www.linkedin.com/company/rockwell-automation'
}, {
  name: 'youtube',
  iconClass: 'media-youtube',
  link: 'http://www.youtube.com/rokautomation'
}])

// https://mft.pol.ra.rockwell.com/docs/#/api/mobile-toolkit-ra.directive:raSidebarDefaultContent
.constant('Const.SidebarMenuItems', {
  navigationItems: [{
    name: 'alarms',
    title: 'VP_APP.MENU.ALARMS',
    tabletNavbarTitle: 'VP_APP.MENU.ALARMS',
    headerTitle: 'VP_APP.MENU.ALARMS',
    state: 'alarms',
    icon: 'ra-icon-alarm',
    badgeStyle: 'vp-badge'
  }, {
    name: 'home',

    // default title
    title: 'VP_APP.MENU.DISPLAYS',

    // display in tablet breadcrumb list
    tabletNavbarTitle: 'VP_APP.MENU.DISPLAYS',

    // display in phone navbar title
    headerTitle: 'VP_APP.MENU.DISPLAYS',
    state: 'home',
    icon: 'ra-icon-display',
    badgeStyle: 'vp-badge',

    // In the menu list, there will be only one 'default' item, which will be used as the state
    // of landing page.
    default: true
  }],

  generalItems: [{
    name: 'about',
    title: 'VP_APP.MENU.ABOUT',
    action: 'showAbout',
    icon: 'ra-icon-information',
    iconClasses: 'ra-icon-information'
  }, {
    name: 'help',
    title: 'VP_APP.MENU.HELP',
    href: '/FTVP/help/FactoryTalk ViewPoint/!SSL!/WebHelp_SE/FactoryTalk_ViewPoint/index.htm',
    popup: true,
    icon: 'ra-icon-help',
    iconClasses: 'ra-icon-help'
  }]
})

.constant('Const.Login.Directories', [{
  value: 'Local',
  label: 'Local'
}, {
  value: 'Network',
  label: 'Network'
}])


/**
 * @ngdoc constant
 * @module appModule
 * @name appModule.constant:VP_ALARM_SORT_OPTIONS
 */
.constant('VP_ALARM_SORT_OPTIONS', [{
  index: 0,
  label: 'Newest',
  orderBy: '-LastUpdateTime'
}, {
  index: 1,
  label: 'Oldest',
  orderBy: 'LastUpdateTime'
}, {
  index: 2,
  label: 'In Alarm, Unacknowledged',
  orderBy: ['-IsActive', 'IsAcked']
}, {
  index: 3,
  label: 'In Alarm, Acknowledged',
  orderBy: ['-IsActive', '-IsAcked']
}, {
  index: 4,
  label: 'Normal, Unacknowledged',
  orderBy: ['IsActive', 'IsAcked']
}, {
  index: 5,
  label: 'Priority: Urgent to Low',
  labelForSort: 'Urgent to Low',
  orderBy: '-Priority'
}, {
  index: 6,
  label: 'Priority: Low to Urgent',
  labelForSort: 'Low to Urgent',
  orderBy: 'Priority'
}])


/**
 * @ngdoc value
 * @module appModule
 * @name appModule.value:alarmItemFilterConfig
 */
.value('alarmItemFilterConfig', {
  hideErrorTooltip: false,
  hideTypeaheadList: false,
  searchTextPlaceholder: 'QUICK FILTER',
  typeaheadListMaxSize: 5,
  queryString: '',
  predicates: {
    state: {
      id: 'state',
      keys: ['state'],
      callback: function(alarmEvent) {
        return alarmEvent.ParsedState;
      }
    },
    priority: {
      id: 'priority',
      keys: ['priority'],
      callback: function(alarmEvent) {
        return alarmEvent.ParsedPriority;
      }
    },
    message: {
      id: 'message',
      keys: ['message'],
      callback: function(alarmEvent) {
        return alarmEvent.Message;
      }
    },
    lastUpdateTime: {
      id: 'lastUpdateTime',
      keys: ['last'],
      callback: function(alarmEvent) {
        return alarmEvent.ParsedLastUpdateTime;
      }
    },
    group: {
      id: 'group',
      keys: ['group'],
      callback: function(alarmEvent) {
        return alarmEvent.AlarmGroup;
      }
    }
  }
});
