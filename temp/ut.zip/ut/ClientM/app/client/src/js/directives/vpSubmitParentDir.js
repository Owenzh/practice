// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, parent*/

angular.module('vpDirectiveModule')

/**
 * @ngdoc directive
 * @name vpDirectiveModule.directive:vpSubmitParent
 * @module vpDirectiveModule
 * @restrict A
 *
 * @description
 * The directive is responsible to submit parent form
 *
 * @example
 * <example module="mobile-toolkit-ra">
 *  <file name="index.html">
 *      <form  vp-submit-parent>
 *      </form>
 *  </file>
 * </example>
 */

.directive('vpSubmitParent', [
    '$parse',
    '$timeout',
    'vpSecuritySvc',
    function($parse, $timeout,vpSecuritySvc) {
        "use strict";
        var directiveName = 'vpSubmitParent';

        return {
            restrict: 'A',
            compile: function(tElem, tAttr) {
                var fn = $parse(tAttr[directiveName]);
                return function(scope, element, attributes) {
                    var action = attributes.vpSpAction;
                    var frm = parent.document.forms[0];

                    element.on('$destroy', function() {
                        if(offme) {
                            offme();
                            offme = null;
                        }
                    });

                    if (frm) {
                        //if no logoff , then 'login'. right now we have only the two action to handle.
                        action = action && action.toLowerCase();
                        if (action === 'logoff') {
                            var offme = scope.$on('app:logoff', function () {
                                frm.elements._postbackaction.value = 'logout';
                                frm.submit();
                            });

                        } else {
                            if (frm.elements.etxu) {
                                element.on('submit', function(event) {
                                    var loginData = scope.login && scope.login.user;
                                    if (loginData) {
                                        fn(scope, {
                                            $event: event
                                        });

                                        $timeout(function(){
                                            frm.elements.etxu.value =
                                            vpSecuritySvc.encryptStringForLogin(loginData.name);

                                            frm.elements.etxp.value =
                                                vpSecuritySvc.encryptStringForLogin(loginData.password);

                                            frm.elements.etrm.value = String(loginData.rememberme);
                                            frm.elements.etdr.value = loginData.directory.value;
                                            frm.elements.ismobile.value = 'yes';
                                            frm.submit();
                                        }, 700);
                                    }

                                    return false;
                                });
                            }
                        }
                    }
                };
            }
        };
    }
]);