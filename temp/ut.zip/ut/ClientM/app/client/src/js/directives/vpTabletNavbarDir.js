// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

angular.module('vpDirectiveModule')

/**
 * @ngdoc directive
 * @name vpDirectiveModule.directive:vpTabletNavbar
 * @module vpDirectiveModule
 * @restrict A
 *
 * @description
 * The directive create a navbar for large device such as tablet and desktop.
 * content section.
 * @example
 * <example module="mobile-toolkit-ra">
 *  <file name="index.html">
        <header vp-tablet-navbar config="::nbRespCtrl.getConfig(0)"></header>
 *  </file>
 * </example>
 */

.directive('vpTabletNavbar', [
  'vpAppCompSvc',
  '$templateCache',
  function(vpAppCompSvc, $templateCache) {
    'use strict';

    var vpTabletNavbarCtrl = app.createClass({
      constructor: function() {
        this.app = this.config.app;
        this.navbarConfig = this.getNavbarConfig();
        this.hbcConfig = this.getBreadCrumbConfig();
      },

      getNavbarConfig: function() {
        var groupId = this.config.groupId;
        var that = this;

        return {
          groupId: groupId,
          username: this.app.user.name,
          brandingLogoUrl: '',
          isNavigationItemsVisible: true,
          navigationItems: [this.app.navigationItems],
          generalItems: this.app.generalItems,
          homeIcon: {
            iconClasses: 'ra-icon-home'
          },
          onLogoutClick: function onLogoutClick() {
            var vpDlgSvc = that.app.injector.get('vpDlgSvc');
            var vpWebHandlerDataSvc = that.app.injector.get('vpWebHandlerDataSvc');
            vpDlgSvc.logoff({
              title: app.translateSvc.instant("VP_APP.MENU.LOGOFF_TITLE"),
              confirmationDesc: ""
            }).then(function() {
              vpWebHandlerDataSvc.returnClientLicense(false);
              that.app.scope.$emit('app:logoff');
            });
          }
        };
      },

      getBreadCrumbConfig: function() {
        var groupId = this.config.groupId;

        return {
          groupId: groupId,
          breadcrumbItems: this.config.breadcrumbItems
        };
      }
    });

    return {
      restrict: 'A',
      scope: true,
      replace: true,
      template: $templateCache.get('js/directives/vpTabletNavbarDir.tpl.html'),
      controller: vpTabletNavbarCtrl,
      controllerAs: 'ctrl',
      bindToController: {
        config: '='
      }
    };
  }
]);