// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.
/*global angular, app*/
'use strict';
angular.module('appModule')
    .controller('vpAlarmShelveOverlayCtrl', [
        '$scope',
        'config',
	"$timeout", 
	"raToastSvc", 
        function ($scope,config,$timeout,raToastSvc) {
            var COMMENT_MAX_LENGTH = 512;
            $scope.AlarmName = config.AlarmName;
            $scope.CommentMaxLength = COMMENT_MAX_LENGTH;
            $scope.CommentDefault= "";
	    $scope.DurationValue= '1';
			
	    var OPERATION_STATUS_TOASTER_ID = "vpAlarmOperationStatusToaster";
	    var OPERATION_STATUS_TOASTE_ID = "vpAlarmOperationStatusToaste";
	    function popupAlarmOperationMessage(type, message, timeout) {
		raToastSvc.clear(OPERATION_STATUS_TOASTER_ID, OPERATION_STATUS_TOASTE_ID);
		$timeout(function() {
			raToastSvc.pop(message, {
				type: type,
				toasterId: OPERATION_STATUS_TOASTER_ID,
				toastId: OPERATION_STATUS_TOASTER_ID,
				timeout: timeout
			});
		}, 0);
	    }
	
            $scope.shelve = function() {
                var comments = document.getElementById("commentsTxt").value;
		var duration = $scope.DurationValue;
		if( duration!=undefined && duration >=1 && duration <= 2147483647 ){
			$scope.$close({
			ShelveComment: comments,
			Duration: duration
			});
		}
		else{
			$scope.DurationValue = "1" ;
			popupAlarmOperationMessage("error", "Missing or invalid Shelve Duration value.The value must be between 1 and 2147483647.", 2e3);
		}
            };
	    $scope.DurationValueChange = function () {		
		 var dwTargetDuration = $scope.DurationValue;
		 if( dwTargetDuration==undefined || dwTargetDuration==null ){
			 $scope.DurationValue = "1";				 
		 }
		 else{
			 var tempTargetDuration = '';
			 var length = dwTargetDuration.length;
			 for( var index = 0; index< length; index++){
				 if( dwTargetDuration[index] >= '0' && dwTargetDuration[index] <= '9'){
					 tempTargetDuration+=dwTargetDuration[index];
				 }
				 else{									 
					 break;
				 }
			 }
			 $scope.DurationValue = tempTargetDuration == null ? '1' : tempTargetDuration;
		 } 
	    }
            $scope.close = function() {
                $scope.$dismiss('cancel');
            };
        }
    ]);
