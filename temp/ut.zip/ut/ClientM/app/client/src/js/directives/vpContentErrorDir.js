// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

angular.module('vpDirectiveModule')

/**
 * @ngdoc directive
 * @name vpDirectiveModule.directive:vpContentError
 * @module vpDirectiveModule
 * @restrict A
 *
 * @description
 * The directive is responsible to initialize error panel which will be used to display error information in
 * content section.
 * @example
 * <example module="mobile-toolkit-ra">
 *  <file name="index.html">
        <div vp-content-error></div>
 *  </file>
 * </example>
 */

.directive('vpContentError', [
  'vpAppConstSvc',
  '$sce',
  function (vpAppConstSvc, $sce) {
    'use strict';
    var template = '<div class="errorPanel" ng-class="class">' +
                      '<div class="header">' +
                        '<span class="error-icon" ng-class="data.icon"></span>' +
                        '<p class="error-title">{{data.title}}</p>' +
                      '</div>' +
                      '<div class="content"><pre ng-bind-html="data.content"></pre></div>' +
                    '</div>';

    var ErrorTypes = {
        _default: {
          icon: 'glyphicon glyphicon-remove-sign'
        },

        applicationNotFound: {
          icon:    'glyphicon glyphicon-remove-sign',
          title:   'ApplicationNotRunningHeader',
          content: 'ApplicationNotRunning'
        },

        licenseAllInUse: {
          icon:    'glyphicon glyphicon-remove-sign',
          title:   'LicenseAllInUseHeading',
          content: 'LicenseAllInUse'
        },

        licenseNotAvailable: {
          icon:    'glyphicon glyphicon-remove-sign',
          title:   'UnableToGetLicenseHeading',
          content: 'UnableToGetLicense'
        },

        forbidden: {
          icon: 'glyphicon glyphicon-minus-sign',
          title: 'DisplayForbiddenHeader',
          content: 'DisplayForbidden'
        },

        sessionExpired: {
          icon: 'glyphicon glyphicon-remove-sign',
          title: 'SessionHasExpiredHeading',
          content: 'SessionHasExpired'
        },
		
		cookiesDisable: {
            icon: "glyphicon glyphicon-remove-sign",
            title: "CookiesAreDisabledHeading",
            content: "CookiesAreDisabled"
        },
		
        offline: {
            icon: "glyphicon",
            title: "offlineHeader",
            content: "offlineTxt"
        },

        serverdown: {
            icon: "glyphicon",
            title: "serverdownHeader",
            content: "serverdownTxt"
        }
    };


    function updateScopeByErrorType(data) {
      var constKey = '';
      var errorData = (data.type && data.type in ErrorTypes) ? ErrorTypes[data.type] : ErrorTypes._default;
      data.icon = errorData.icon || ErrorTypes._default.icon;

      var errorPageConsts = vpAppConstSvc.errorPage;
      if (!data.title) {
        data.title = errorData.title;
        if (errorData.title in errorPageConsts.Ids) {
            constKey = errorPageConsts.Ids[errorData.title];
            data.title = app.translateSvc.instant('VP_ERROR_MESSAGES.' + constKey);
        }
      }

      if (!data.content) {
        data.content = errorData.content;
        if (errorData.content in errorPageConsts.Ids) {
            constKey = errorPageConsts.Ids[errorData.content];
            data.content = app.translateSvc.instant('VP_ERROR_MESSAGES.' + constKey, data);
        }
      }

      data.content = $sce.trustAsHtml(data.content);
    }

    return {
      restrict: 'A',
      scope: {
        class: "@class",
        data: "=vpErrorData"
      },
      replace: true,
      template: template,
      link: function(scope) {
        scope.$watch('data', function(newData){
          if(newData) {
            updateScopeByErrorType(newData);
          }
        });
      }
    };
  }
]);