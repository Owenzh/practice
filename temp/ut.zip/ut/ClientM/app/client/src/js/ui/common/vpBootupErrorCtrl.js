// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/
(function () {
    'use strict';
    angular.module('appModule')
    .config(['$stateProvider',
        function ($stateProvider) {
            $stateProvider.state('bootUpError', {
                url: '/bootUpError',
                templateUrl: 'js/ui/common/vpBootupErrorCtrl.tpl.html',
                controller: 'vpBootupErrorCtrl as buerr'
            });
        }
    ])

    /**
     * @ngdoc controller
     * @module appModule
     * @name appModule.vpBootupErrorCtrl
     * @description controller for "bootUpError" state.
     */

    .controller('vpBootupErrorCtrl', [
        '$injector',
        '$scope',
        app.createClass({
            constructor: function (injector,scope) {
                this.scope = scope;
                this.injector = injector;
                this.init();
            },

            init: function () {
                var appRes = this.injector.get('Const.App.resource');
                var that = this;
                this.logo = appRes.siteLogo;
                if (this._checkStartupError()) {
                    this.initLayout();

                    app.translateSvc().then(function() {
                        that.subtitle = app.translateSvc.instant('VP_RESOURCES.SITE_SUBTITLE');
                        that.injector.get('raTabletNavbarSvc').setSubTitle(that.config.groupId, that.subtitle);
                        that._updateErrorData();
                        that.scope.$emit('app:loaded');
                    });
                }
            },

            _updateErrorData: function () {
                var errorPageConsts = this.injector.get('vpAppConstSvc').errorPage;
                var errData = this._errorData;
                var key = '';

                if (errData.title in errorPageConsts.Ids) {
                    key = errorPageConsts.Ids[errData.title];
                    errData.title = app.translateSvc.instant('VP_ERROR_MESSAGES.' + key);
                }

                errData.content = errData.msg;
                errData.msg = null;
                if (errData.content in errorPageConsts.Ids) {
                    key = errorPageConsts.Ids[errData.content];
                    errData.content = app.translateSvc.instant('VP_ERROR_MESSAGES.' + key);
                }

                this.errorData = errData;
                this._errorData = null;
            },

            _checkStartupError: function () {
                this._errorData = {};
                var title = app.env.get('bootErrTitle');

                if(!title){
                    this.injector.get('vpRouterSvc').transitionTo('home', null, {location:'replace'});
                    return false;
                }

                title = decodeURIComponent(title);
                this._errorData.title = title;

                var msg = decodeURIComponent(app.env.get('bootErrMsg'));
                this._errorData.msg = msg;

                return true;
            },

            initLayout: function () {
                this.config = {
                    groupId: 'vpbootuperror_groupId',
                    logoPath: 'img/FTViewPoint-logo.png',
                    linkAddress: '#',
                    subtitle: this.subtitle
                };
            }
        })
    ]);
})();