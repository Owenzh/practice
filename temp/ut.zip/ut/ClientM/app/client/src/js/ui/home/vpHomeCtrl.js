// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/
(function () {
    'use strict';
    angular.module('appModule')

    .config([
        '$stateProvider',
        function ($stateProvider) {
            $stateProvider
            .state('home', {
                url: '/home',
                parent: 'app',
                views: {
                    "content": {
                        templateUrl: 'js/ui/home/vpHomeCtrl.tpl.html',
                        controller: 'vpHomeCtrl as home',
                        resolve: {
                            displayList: ['vpDisplaySvc', function (vpDisplaySvc) {
                                return vpDisplaySvc.getDisplayList();
                            }]
                        }
                    }
                }
            })

            .state('displays', {
                url: '/displays/{areaIds:any}',
                parent: 'app',
                views: {
                    "content": {
                        templateUrl: 'js/ui/home/vpHomeCtrl.tpl.html',
                        controller: 'vpHomeCtrl as home',
                        resolve: {
                            displayList: ['vpDisplaySvc', function (vpDisplaySvc) {
                                return vpDisplaySvc.getDisplayList();
                            }]
                        }
                    }
                }
            });
        }
    ])

    /**
     * @ngdoc controller
     * @module appModule
     * @name appModule.vpHomeCtrl
     * @description this controller will control the "home" state.
     */

    .controller('vpHomeCtrl', [
        '$scope',
        '$injector',
        'displayList',
        app.createClass({
            constructor: function($scope, $injector, displayList) {
                this.init($scope, $injector, displayList);
            },

            init: function ($scope, $injector, displayList) {
                this.injector = $injector;
                this.errNoDisplayFound = app.translateSvc.instant('VP_HOME.ERR_NO_DISPLAY_FOUND');
                this.initList(displayList);
                $scope.app.getTabletNavbarHeader().setNavbarActiveItem('VP_APP.MENU.DISPLAYS');
            },

            initList: function (displayList) {
                var that = this;
                var stateParams = that.injector.get('$stateParams');

                this.listConfig = {
                    onAction: function (item) {
                        var vpRouterSvc = that.injector.get('vpRouterSvc');
                        var stateParams = that.injector.get('$stateParams');
                        var areaIds = stateParams.areaIds || '';

                        if (displayList.isDisplay(item)) {
                            vpRouterSvc.transitionToDisplay(item.Name, areaIds);
                        } else {
                            areaIds = stateParams.areaIds ? stateParams.areaIds + '/' : '';
                            areaIds = areaIds  + item.Name;
                            vpRouterSvc.transitionToDisplay(null, areaIds, item.Name);
                        }
                    }
                };

                that.injector.get('$rootScope').$on('app:loaded', function(){
                    that.listItems = displayList.getChildItems(stateParams.areaIds);
                });

                if (app.state.isLoaded()) {
                   that.listItems = displayList.getChildItems(stateParams.areaIds);
                }
            }
        })
    ]);
})();