// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

'use strict';

angular.module('appModule')

.controller('vpAlarmFilterOverlayCtrl', [
  '$scope',
  '$rootScope',
  'raOverlaySvc',
  'config',
  function($scope, $rootScope, raOverlaySvc, config) {
    $scope.selectedValues = {
      IsAcked:  config.IsAcked,
      IsActive: config.IsActive,
      Priority: config.Priority
    };

    $scope.ackStateOptions = [{
      label: 'ACK Status',
      value: ''
    }, {
      label: 'Acked',
      value: true
    }, {
      label: 'Unacked',
      value: false
    }];

    $scope.activeStateOptions = [{
      label: 'State',
      value: ''
    }, {
      label: 'Active',
      value: true
    }, {
      label: 'Inactive',
      value: false
    }];

    $scope.priorityOptions = [{
      label: 'Priority',
      value: ''
    }, {
      label: 'Urgent',
      value: 4
    }, {
      label: 'High',
      value: 3
    }, {
      label: 'Medium',
      value: 2
    }, {
      label: 'Low',
      value: 1
    }];

    $scope.resetFilters = function() {
      $scope.selectedValues.IsAcked =  '';
      $scope.selectedValues.IsActive = '';
      $scope.selectedValues.Priority = '';
    };

    $scope.apply = function() {
      $rootScope.$emit('vp.select.close');
      $scope.$close({
        ack: $scope.selectedValues.IsAcked,
        state: $scope.selectedValues.IsActive,
        priority: $scope.selectedValues.Priority
      });
    };

    $scope.close = function() {
      $rootScope.$emit('vp.select.close');
      $scope.$dismiss('cancel');
    };
  }
]);
