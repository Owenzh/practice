// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

angular.module('vpServiceModule')

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpAppCompSvc
 * @description this service will UI components for vpAppCtrl
 */

.factory('vpAppCompSvc', [
    function() {
        "use strict";

        /**
         * @ngdoc object
         * @name NavigationBase
         * @constructor
         *
         * @description Base class for Header and Sidebar.
         */
        var NavigationBase = app.createClass({
            init: function(app) {
                this.app = app;
                this.app.$filter = app.injector.get('$filter');
            },

            setAlarmCount: function(count) {
                var badgeText = this.app.$filter('vpCountNumberFilter')(count);

                // index: 0 is alarm navigation item, @see Const.SidebarMenuItems
                this.app.navigationItems[0].badgeText = badgeText;
            },

            setAlarmCountOnBadge: function(count) {
                var navbarHamBadgeText = this.app.$filter('vpCountNumberFilter')(count, true);

                this.raNavigationSvc.setConfig({
                    navbarHamBadgeText: navbarHamBadgeText
                }, this.app.groupId);
            },

            setDisplayCount: function(count) {
                var badgeText = this.app.$filter('vpCountNumberFilter')(count);

                // index: 1 is display navigation item, @see Const.SidebarMenuItems
                this.app.navigationItems[1].badgeText = badgeText;
            },

            setNavbarActiveItem: function(itemName) {
                this.raNavigationSvc.setActiveItem(itemName, this.app.groupId);
            }
        })

        /**
         * @ngdoc object
         * @name Header
         * @constructor
         *
         * @description
         * This is the contructor function of Header section of the framework.
         * It will be viable through `AppCtrl.header`.
         */
        var Header = NavigationBase.extend({
            constructor: function(app) {
                this.super('init', app);
                this.init(app);
                this.raNavigationSvc = app.injector.get('raNavigationSvc');
            },

            init: function(_app) {
                this.app = _app;

                // init breadcrumb items and title
                var breadcrumbConfig = this.updateTitle();

                this.breadcrumbItems = breadcrumbConfig.breadcrumbItems;
                this.config = {
                    groupId: this.app.groupId,
                    title: breadcrumbConfig.title
                };
            },

            /**
             * @ngdoc method
             * @name Header#updateTitle
             * @methodOf Header
             * @returns {Object} Value of `breadcrumbConfig`.
             *
             * @description
             * Calculate the current path's `breadcrumbItems` and `title`. Then use
             * `raNavigationSvc` to update.
             */
            updateTitle: function(data) {
                var $state = this.app.injector.get('$state'),
                    $stateParams = this.app.injector.get('$stateParams'),
                    raNavigationSvc = this.app.injector.get('raNavigationSvc'),
                    breadcrumbItems = [],
                    title = '',
                    breadcrumbConfig = {},
                    that = this;

                switch ($state.current.name) {

                case 'alarms':
                    title = 'VP_APP.MENU.ALARMS';
                    break;
                        case 'alarmDetails':
                            var baseUrl = '#/alarms';
                            var firstBreadcrumbItem = {
                                name: 'VP_APP.MENU.ALARMS',
                                url: baseUrl
                            };

                            breadcrumbItems.push(firstBreadcrumbItem);
                            title = 'VP_APP.MENU.ALARM_DETAILS';
                            break;

                case 'home':
                    title = 'VP_APP.MENU.DISPLAYS';
                    break;

                case 'display':
                case 'displays':

                    // Generate `breadcrumbItems` list and `title`.
                    // url: '/display/{areaIds:dispath}/{displayName}/{params}'
                    // url: '/displays/{areaIds:any}'
                    //
                    // ## Example
                    //
                    // ### Case 1
                    //
                    // Given `$stateParams`:
                    //
                    // {
                    //     areaIds: "Area1/Area2/Area3/Area4",
                    //     displayName: "numeric"
                    // }
                    //
                    // Convent to:
                    //
                    // ```js
                    //   breadcrumbItems = [{
                    //     "name": "VP_APP.MENU.DISPLAYS",
                    //     "url": "#/displays"
                    //   }, {
                    //     "name": "Area1",
                    //     "url": "#/displays/Area1"
                    //   }, {
                    //     "name": "Area2",
                    //     "url": "#/displays/Area1/Area2"
                    //   }, {
                    //     "name": "Area3",
                    //     "url": "#/displays/Area1/Area2/Area3"
                    //   }, {
                    //     "name": "Area4",
                    //     "url": "#/displays/Area1/Area2/Area3/Area4"
                    //   }];
                    //   title = "numeric";
                    // ```
                    //
                    // ### Case 2
                    //
                    // Given `$stateParams`:
                    //
                    // {
                    //     areaIds: "Area1/Area2/Area3"
                    // }
                    //
                    // Convent to:
                    //
                    // ```js
                    //   breadcrumbItems = [{
                    //     "name": "VP_APP.MENU.DISPLAYS",
                    //     "url": "#/displays"
                    //   }, {
                    //     "name": "Area1",
                    //     "url": "#/displays/Area1"
                    //   }, {
                    //     "name": "Area2",
                    //     "url": "#/displays/Area1/Area2"
                    //   }];
                    //   title = "Area3";
                    // ```
                    var baseUrl = '#/displays',
                        firstBreadcrumbItem = {
                            name: 'VP_APP.MENU.DISPLAYS',
                            url: baseUrl
                        },
                        displayName = $stateParams.displayName,
                        displayArea = $stateParams.areaIds === '' ?
                                        [] : $stateParams.areaIds.split('/');

                    breadcrumbItems.push(firstBreadcrumbItem);

                    displayArea.reduce(function(prev, current) {
                        breadcrumbItems.push({
                            name: current,
                            url: this.encodeUrl(prev + '/' + current)
                        });

                        return prev + '/' + current;
                    }.bind(this), baseUrl);

                    if (displayName) {
                        title = displayName;

                    // if no `displayName`, then the last area name is used as `title`
                    } else {
                        breadcrumbItems.pop();
                        title = displayArea[displayArea.length -1];
                    }
                    break;

                case 'display-redirect':
                    // url: '/display/?raml&{area:dispath}&param&macro&{cmd:dispath}&{prev:dispath}&
                    //       scaletoscreen&retainaspectratio&{preparam:dispath}'
                    var baseUrl = '#/displays',
                        firstBreadcrumbItem = {
                            name: 'VP_APP.MENU.DISPLAYS',
                            url: baseUrl
                        },
                        displayArea,
                        displayName = '',
                        fullDisplayName = '';

                    if (data) {
                        angular.extend($stateParams, data);
                    }

                    /**
                     * Display <display_name> [/B] [/E] [/U] [/O] [/Z] [/ZA] [/Pfile] [/T<tag>, <tag>, ] [/Hnnn] [/Wnnn] [/Min] [/Max] [position] |
                     * <display_name> is a relative or absolute reference to a graphic display. If the file name has a space in it, enclose the name in double quotes.
                     */

                    // Case 1:
                    // Navigate to display `simple` in new area `"/Area 1/Area 2/Area 3/Area_4/Area_5"`.
                    // url: ?area=/Area1/Area2/Area3/Area4&cmd="/Area 1/Area 2/Area 3/Area_4/Area_5::simple"   /B /E /U /O /Z /T{/::system\Date} /Q1 /H200 /W200 /Min
                    //
                    // Case 2:
                    // Navigate to display `numeric2` in the same area `/Area1/Area2/Area3/Area4`.
                    // url: ?area=/Area1/Area2/Area3/Area4&cmd=numeric2  /B /E /U /O /Z /T{/::system\Date}

                    // Get <display_name>.
                    // Reference to: VPCommmand.ts => SetDisplay()
                    if ($stateParams.cmd.indexOf('"') === 0) {
                        // e.g.: "/Area 1/Area 2/Area 3::simple"   /B /E /U /O /Z /T{/::system\D
                        // => /Area 1/Area 2/Area 3::simple
                        fullDisplayName = $stateParams.cmd.substring(1, $stateParams.cmd.indexOf('"', 1));

                    } else {
                        // e.g.: /Area1/Area2/Area3::simple   /B /E /U /O /Z /T{/::systemD
                        // => /Area1/Area2/Area3::simple
                        var tokens = $stateParams.cmd.split(' /');

                        fullDisplayName = tokens.length === 0 ? '' : tokens[0].trim();
                    }


                    var isWithinSameArea = fullDisplayName.indexOf('::') === -1,
                        strArea = '';

                    if (isWithinSameArea) {
                        // strip the starting '/'
                        strArea = $stateParams.area.substr(1);
                        displayArea = strArea === '' ? [] : strArea.split('/');
                        displayName = fullDisplayName;

                    } else {
                        strArea = fullDisplayName.split('::')[0].substr(1);
                        displayArea = strArea === '' ? [] : strArea.split('/');
                        displayName = fullDisplayName.split('::')[1];
                    }

                    title = displayName;

                    breadcrumbItems.push(firstBreadcrumbItem);

                    displayArea.reduce(function(prev, current) {
                        breadcrumbItems.push({
                            name: current,
                            url: this.encodeUrl(prev + '/' + current)
                        });

                        return prev + '/' + current;
                    }.bind(this), baseUrl);

                    break;

                default:
                    return;
                }

                breadcrumbConfig.breadcrumbItems = breadcrumbItems;
                breadcrumbConfig.title = title;

                raNavigationSvc.setConfig(breadcrumbConfig, this.app.groupId);

                return breadcrumbConfig;
            },

            // iconUrlcon: [iconurl, iconMesg]
            updateTitleIcon: function(iconUrlcon) {
                var titleIcon = '',
                    titleIconMsg = '';

                if (angular.isString(iconUrlcon)) {
                    titleIcon = iconUrlcon;

                } else if (angular.isArray(iconUrlcon)) {
                    titleIcon = iconUrlcon[0];
                    titleIconMsg = iconUrlcon[1];
                }

                this.raNavigationSvc.setConfig({
                    titleIcon: titleIcon,
                    titleIconMsg: titleIconMsg
                }, this.config.groupId);
            },
            updateTitleByMenuItem: angular.noop,
            menuAction: angular.noop,
            encodeUrl: function(url) {
                // Fix history back issue: if area name contains space, window.history.back() not
                // working. Because, 2 items push to window history.
                //
                // Example:
                //   Navigate to '#/displays/Area 1/Area 2'
                //   '#/displays/Area 1/Area 2' and '#/displays/Area%201/Area%202' are added to
                //    history. So window.history.back() not working.
                url = url || '';

                return url.replace(/ /g, '%20');
            }
        });

        var HeaderDelegate = app.createClass({
            constructor: function(headers, app) {
                var vpDataStoreSvc = app.injector.get('vpDataStoreSvc');
                this.headers = headers;
                this.app = app;
                this.uiCache = vpDataStoreSvc.getCacheStore('appCtrl.Cache').getStore();
                this._bindHandlers();
                this._delegateMethods();
            },

            getConfig: function(id) {
                var header = this.headers[id];
                return header && header.config;
            },

            _bindHandlers: function() {
                var that = this;
                var vpLayoutSvc = that.app.injector.get('vpLayoutSvc');

                vpLayoutSvc.onOrientationChanged(function(isLandscape, isPhone) {
                    that.currentHeader(isPhone && !isLandscape, true);
                });

                that.currentHeader(vpLayoutSvc.matchListLayout());
            },

            currentHeader: function(useList, bReset) {
                if (useList !== this.useList) {
                    var _header = this.header = this.headers[Number(useList)];
                    this.useList = useList;

                    if (bReset) {
                        _header.updateTitle();
                        _header.updateTitleIcon(this.uiCache.icon);
                    }
                }
            },

            updateTitleIcon: function(iconUrlcon) {
                this.uiCache.icon = iconUrlcon;
                this.header.updateTitleIcon(iconUrlcon);
            },

            _delegateMethods: function() {
                var that = this;

                if (that.header) {
                    angular.forEach([
                        'menuAction',
                        'updateTitle'
                    ], function(methodName) {
                        that[methodName] = function() {
                            that.header[methodName].apply(that.header, arguments);
                        };
                    });
                }
            }
        });

        var PhoneNavbarHeader = Header.extend({
            init: function(app) {
                this.breadcrumbItems = [];
                this.super('init', app);
                this.config.isNavbarBackButtonVisible = true;
                this.config.breadcrumbItems = this.breadcrumbItems;
            },

            menuAction: function(item) {
                var that = this;
                var state = that.app.injector.get('$state');
                that.updateTitleByMenuItem(item);
                state.go(item.state);
            },

            updateTitleByMenuItem: function(item) {
                // TODO: clean up the messy keys
                var title = item.headerTitle || item.title || item.name;

                this.updateTitle(title, '');
            }
        });

        var TabletNavbarHeader = Header.extend({
            init: function(app) {
                this.breadcrumbItems = [];
                this.super('init', app);

                var appRes = app.injector.get('Const.App.resource');
                angular.extend(this.config, {
                    app: app,
                    logoPath: appRes.siteLogo,
                    breadcrumbItems: this.breadcrumbItems
                });
            },

            menuAction: function(item) {
                var that = this;
                var vpRouterSvc = that.app.injector.get('vpRouterSvc');

                if (item.default) {
                    this.updateTitle(false);

                } else {
                    that.updateTitleByMenuItem(item);
                }

                vpRouterSvc.transitionTo(item.state);
            },

            updateTitleByMenuItem: function(item) {
                var vpRouterSvc = this.app.injector.get('vpRouterSvc');
                var title = item.name;
                var link = vpRouterSvc.getStateLink(item.state);

                this.updateTitle(title, link);
            }
        });

        /**
         * @ngdoc object
         * @name Sidebar
         * @constructor
         * @description this is the contructor function of Sidebar section of the framework.
         */
        var Sidebar = NavigationBase.extend({
            constructor: function(app) {
                this.super('init', app);
                this.init(app);
            },

            init: function(app) {
                var raNavigationSvc = app.injector.get('raNavigationSvc'),
                    generalItems = app.generalItems;

                this.app = app;
                this.config = {
                    groupId: app.groupId
                };

                var navigationConfig = {
                    groupId: app.groupId,
                    username: app.user.name,
                    // brandingLogoUrl: 'img/rockwell-automation-signature.png',
                    navigationItems: [app.navigationItems],
                    isNavigationItemsVisible: true,
                    onLogoutClick: function() {
                        app.menuActions.logoff();
                    }
                };

                if (navigationConfig.username) {
                    navigationConfig.generalItems = generalItems.filter(function(item) {
                        return !item.isHidden;
                    });

                } else {
                    navigationConfig.generalItems = generalItems;
                }

                raNavigationSvc.register(navigationConfig);
            }
        });


        return {
            setApp: function(app) {
                this.app = app;
            },
            getHeader: function(app) {
                app = app || this.app;

                var header = new HeaderDelegate([
                    new TabletNavbarHeader(app), /*screensize is larger than 'xs' or landscape mode */
                    new PhoneNavbarHeader(app) /* portrait and screensize is 'xs' */
                ], app);

                app.setHeader(header);
                return header;
            },

            getSideBar: function(app) {
                app = app || this.app;
                return new Sidebar(app);
            }
        };
    }
]);