// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/
/*jshint sub:true*/
angular.module('vpServiceModule')

    /**
     * @ngdoc service
     * @module vpServiceModule
     * @name vpServiceModule.vpAlarmOperationSvc
     *
     * @description
     * To operate the alarm. for example , acknowledge alarm, etc.
     */
    .factory('vpAlarmOperationSvc', ['vpAlarmDataSvc',
        function (vpAlarmDataSvc) {
            'use strict';
            var alarmJsonAcknowledgeSvc = vpAlarmDataSvc.alarmJsonAcknowledgeSvc;
	    var alarmJsonShelveSvc = vpAlarmDataSvc.alarmJsonShelveSvc;
            return {
                ackAlarm: function (args) {
                    return alarmJsonAcknowledgeSvc.call(args);
                },
		shelveAlarm: function (args) {
                    return alarmJsonShelveSvc.call(args);
                }
            };
        }
    ]);
