// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('vpDataSvcModule')

/**
 * @ngdoc service
 * @module vpDataSvcModule
 * @name vpDataSvcModule.vpAdminDataSvc
 * @description this service will communicate with admin soap server to manipulate ftvp administration related data.
 */

.provider('vpAdminDataSvc', function () {
    'use strict';

    this.$get = [
        '$http',
        '$q',
        'vpErrorHandlerSvc',
        'vpSoapSvc',
        function ($http, $q, vpErrorHandlerSvc, vpSoapSvc) {
            var AdminDataSvcUtils = {
                /**
                * update list structure from tweety
                * the structure of area item:[{},[],[]];
                * an: areaName
                * ar: root area
                * arl: area list
                * dl: display list
                * dl -> dn: display name
                *
                * the following properties will be populated during the process.
                * fullName: fullPath of area Name, f.g. ar1/ar2/ar3/ar4
                * childList: cache parsed sorted sub list (area list and display list)
                */
                parseDisplayDataAsTree: function (data) {
                    var areaName ='';
                    var resultData = {};
                    var displayCount = 0;

                    // TODO: if returns from server, then remove this function
                    // calculate display count number
                    function calcDisplayCount(areaList) {
                        var count = 0;

                        angular.forEach(areaList, function(area) {
                            count += area.dl.length;

                            if (area.arl.length) {
                                count += calcDisplayCount(area.arl);
                            }
                        });

                        return count;
                    }

                    if (data.apn) {
                        resultData.applicationName = data.apn;
                    }

                    // suppose server response display count with key `c`
                    if (data.c) {
                        resultData.count = data.c;

                    } else {
                        displayCount = data.ar.dl.length + calcDisplayCount(data.ar.arl);
                        resultData.count = displayCount;
                    }

                    var stack, substack;
                    var item;

                    if (data.ar) {
                        data = data.ar;
                        stack = [{areaName: areaName, list: [data]}];

                        while (stack.length) {
                            substack = stack.shift();
                            areaName = substack.areaName || '';
                            substack = substack.list;

                            if (!substack || !substack.length) {
                                continue;
                            }

                            substack.areaNameToIds = {};

                            for (var i=0, n=substack.length; i<n; ++i) {
                                item = substack[i];
                                item.fullName = item.an ? areaName + '/' + item.an : areaName;
                                substack.areaNameToIds[item.an] = i;

                                if (item.arl) {
                                    stack.push({areaName: item.fullName, list: item.arl});
                                }
                            }
                        }

                        resultData.parsedTree = data;
                    }

                    return resultData;
                }
            };

            var AdminSoapSvc = vpSoapSvc.SoapServiceBase.extend({
                soapEndPoint: '/FTVP/VPAdminServer/Service.asmx'
            });

            var AdminServices = {};

            AdminServices.getRunningViewApplication = AdminSoapSvc.extend({
                name: 'GetRunningViewApplication',
                resultTagName: 'GetRunningViewApplicationResponse',

                getBodyContent: function () {
                    return "<GetRunningViewApplication xmlns=\"http://tempuri.org/\">" +
                           "<clientIdentifier><ExtensionData /> " +
                           "<UniqueClientIdentifier></UniqueClientIdentifier>" +
                           "<UserHost></UserHost><UserName></UserName>" +
                           "</clientIdentifier> " +
                           "</GetRunningViewApplication>";
                },
                transformResponse: function (data, headers) {
                    if (angular.isString(data)) {
                        if(data.indexOf('</GetRunningViewApplicationResult>')>0) {
                            var arr = data.split('</GetRunningViewApplicationResult>');
                            var addOn = '</GetRunningViewApplicationResult><ServerDate>'+headers('Date')+'</ServerDate>';
                            data = arr[0] + addOn + arr[1];
                        }
                        var contentType = headers('Content-Type');
                        if (contentType && /(text|application)\/xml\b/i.test(contentType)) {
                            data = $.parseXML(data); // will throw
                        }
                    }

                    return data;
                }
            });

            AdminServices.getDisplayList = AdminSoapSvc.extend({
                name: 'GetMobileDisplaysJSON',

                getBody: function () {
                    return  '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">' +
                            '<s:Body>' +
                            '<GetMobileDisplaysJSON xmlns:i="http://www.w3.org/2001/XMLSchema-instance" ' +
                            'xmlns="http://tempuri.org/"></GetMobileDisplaysJSON>' +
                            '</s:Body>' +
                            '</s:Envelope>';
                },

                onsuccess: function (rootXML) {
                    var data = this.super('onsuccess', AdminSoapSvc)(rootXML);
                    var success = data.GetMobileDisplaysJSONResult.toLowerCase() === 'success';

                    if (success) {
                        var list = JSON.parse(data.strDisplaysJSON);

                        return  AdminDataSvcUtils.parseDisplayDataAsTree(list);

                    } else {
                        var errorMsg = data.strErrorMessage;

                        return { error: errorMsg };
                    }
                }
            });

            return {
                getRunningViewApplication: function () {
                    return AdminServices.getRunningViewApplication.call();
                },

                getDisplayList: function () {
                    var result = $q.defer();

                    AdminServices.getDisplayList.call().then(function(data) {
                        if (!data) {
                            result.reject(false);
                            vpErrorHandlerSvc.propagate('fail to get display list');

                        } else {
                            result.resolve(data);
                        }
                    });

                    return result.promise;
                }
            };
        }
    ];
});