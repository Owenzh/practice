// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

'use strict';

angular.module('appModule')

.config([
  '$stateProvider',
  function($stateProvider) {
    $stateProvider
      .state('alarms', {
        url: '/alarms',
        parent: 'app',
        views: {
          "content": {
            templateUrl: 'js/ui/alarm/vpAlarmCtrl.tpl.html',
            controller: 'vpAlarmCtrl',
          }
        }
      });
  }
])

.controller('vpAlarmCtrl', [
  '$scope',
  '$rootScope',
  '$filter',
  '$timeout',
  'raOverlaySvc',
  'raToastSvc',
  'raItemFilterSvc',
  'vpAlarmUpdateManagerSvc',
  'vpRouterSvc',
  'vpAlarmStorageSvc',
  'VP_ALARM_SORT_OPTIONS',
  'alarmItemFilterConfig',
  function($scope, $rootScope, $filter, $timeout, raOverlaySvc, raToastSvc, raItemFilterSvc, vpAlarmUpdateManagerSvc, vpRouterSvc, vpAlarmStorageSvc, VP_ALARM_SORT_OPTIONS, alarmItemFilterConfig) {
    // set active tab
    $scope.app.getTabletNavbarHeader().setNavbarActiveItem('VP_APP.MENU.ALARMS');


    /***************************************************************************
     * ALARM VIEW
     **************************************************************************/
    var MAX_PRESENT_ALARM_EVENTS_COUNT = 2000;

    // All alarm events saved on client side, max count is 4096.
    $scope.allAlarmEvents = vpAlarmUpdateManagerSvc.getAlarms();

    // An intermediate variable saves currently shown alarm events.
    // Because we have filters in `updateFilteredAlarmEvents()` and `limitTo` filter in `ngRepeat`
    // directive on html, so its value will be a part of `$scope.allAlarmEvents`.
    $scope.alarmEventsResult = [];

    // the alarm events count shown in view after initializing
    $scope.initPresentAlarmEventsCount = 30;

    // when perform infinite scroll, load 10 more alarm events each time
    $scope.presentAlarmEventsIncreasementCount = 10;

    $scope.presentAlarmEventsCountLimit = $scope.initPresentAlarmEventsCount;

    $scope.showDetails = function(alarmEvent) {
        vpRouterSvc.transitionToAlarmDetail(alarmEvent.Id);
    };

    $scope.loadAlarms = function() {
      var maxPresentAlarmsCount = getMaxPresentAlarmsCount();

      if ($scope.presentAlarmEventsCountLimit < maxPresentAlarmsCount) {
        $scope.presentAlarmEventsCountLimit += $scope.presentAlarmEventsIncreasementCount;
      }
    };

    function getMaxPresentAlarmsCount() {
      return $scope.filteredAlarmEvents.length > MAX_PRESENT_ALARM_EVENTS_COUNT ?
        MAX_PRESENT_ALARM_EVENTS_COUNT : $scope.filteredAlarmEvents.length;
    }


    /***************************************************************************
     * ALARM SORT
     **************************************************************************/
    $scope.sortOptions = VP_ALARM_SORT_OPTIONS;

    // restore saved sort option
    var savedSortOptionIndex = vpAlarmStorageSvc.getSortOptionIndex();
    $scope.currentSortOption = VP_ALARM_SORT_OPTIONS[savedSortOptionIndex];

    $scope.setSortOption = function(option) {
      $scope.currentSortOption = option;
      $rootScope.$emit('vp.popover.close');
    };


    /***************************************************************************
     * ALARM FILTER
     **************************************************************************/
    $scope.isFilterApplied = false;

    var savedPopupFilterExpression = vpAlarmStorageSvc.getPopupFilterExpression();
    var savedQuickFilterExpression = vpAlarmStorageSvc.getQuickFilterExpression();

    // doc: {@link https://docs.angularjs.org/api/ng/filter/filter}
    $scope.popupFilterExpression = angular.extend({
      IsAcked:  '',
      IsActive: '',
      Priority: ''
    }, savedPopupFilterExpression);

    // MFT component: `raItemFilter`
    // doc: {@link https://mft.pol.ra.rockwell.com/docs/#/api/mobile-toolkit-ra.directive:raItemFilter}
    $scope.itemFilterConfig = angular.extend(alarmItemFilterConfig, {
      queryString: savedQuickFilterExpression
    });

    // Result of all alarm events filtered by popup filter and quick filter.
    // It's used for presentation in alarm view, and then
    // it will be limited to 2000 items when presenting in the view
    $scope.filteredAlarmEvents = $scope.allAlarmEvents;

    // when receive any alarm events update, calculate filtered alarms again
    vpAlarmUpdateManagerSvc.registerAlarmUpdatedHandler(updateFilteredAlarmEvents);

    var unwatchPopupFilterExpression = $scope.$watchCollection('popupFilterExpression', updateFilteredAlarmEvents);
    var unwatchQuickFilterExpression = $scope.$watch('itemFilterConfig.queryString', updateFilteredAlarmEvents);

    $scope.showFilterOverlay = function() {
      $timeout(function() {
        raOverlaySvc.openWithOptions({
          controller: "vpAlarmFilterOverlayCtrl",
          templateUrl: 'js/ui/alarm/vpAlarmFilterOverlayCtrl.tpl.html',
          windowClass: "ra-message-overlay vp-alarm-filter-overlay",
          keyboard: false,
          backdrop: 'static'

        }, {
          IsAcked: $scope.popupFilterExpression.IsAcked,
          IsActive: $scope.popupFilterExpression.IsActive,
          Priority: $scope.popupFilterExpression.Priority

        }).result.then(function(option) {
          $scope.popupFilterExpression.IsAcked  = option.ack;
          $scope.popupFilterExpression.IsActive = option.state;
          $scope.popupFilterExpression.Priority = option.priority;

        }, function(reason) {
          // filter overlay canceled
        });
      }, 0);
    };

    // reset filters and sort and show a toast message
    // @see vpDirectiveModule.directive:vpAlarmBackToTop
    $rootScope.$on('vp.backtotop.reset', function() {
      $scope.itemFilterConfig.queryString = '';
      $scope.popupFilterExpression.IsAcked = '';
      $scope.popupFilterExpression.IsActive = '';
      $scope.popupFilterExpression.Priority = '';
      $scope.setSortOption($scope.sortOptions[0]);

      $timeout(function() {
        raToastSvc.pop("The setting of filter and sort is reset", {
          toasterId: CONNECTION_STATUS_TOASTER_ID,
          toastId: CONNECTION_STATUS_TOASTE_ID,
          timeout: 3000
        });
      }, 0);
    });

    $scope.$on('$destroy', function() {
      unwatchPopupFilterExpression();
      unwatchQuickFilterExpression();
      vpAlarmUpdateManagerSvc.unregisterAlarmUpdatedHandler(updateFilteredAlarmEvents);
      vpAlarmUpdateManagerSvc.unregisterAlarmUpdatedErrorHandler(setAlarmServiceDisconnected);

      // store current sort settings
      var currentSortOption = $scope.sortOptions.indexOf($scope.currentSortOption) || 0;
      vpAlarmStorageSvc.setSortOptionIndex(currentSortOption);

      // store current filter settings
      vpAlarmStorageSvc.setPopupFilterExpression($scope.popupFilterExpression);
      vpAlarmStorageSvc.setQuickFilterExpression($scope.itemFilterConfig.queryString);
    });

    var isShowSuppressedAndAcked = false;

    // invoke when:
    // 1. any alarm events added or updated
    // 2. popup filter or quick filter changed
    function updateFilteredAlarmEvents() {
      var filteredAlarmEvents = [];

      filteredAlarmEvents = $filter('filter')($scope.allAlarmEvents, $scope.popupFilterExpression);

      filteredAlarmEvents = $filter('filter')(filteredAlarmEvents, function(value) {
        return raItemFilterSvc.isMatch($scope.itemFilterConfig.queryString, value);
      });

      if (!isShowSuppressedAndAcked) {
        filteredAlarmEvents = $filter('filter')(filteredAlarmEvents, function(alarmEvent) {
          return (!(alarmEvent.IsAcked && alarmEvent.IsSuppressed)) && (!(alarmEvent.IsAcked && alarmEvent.IsShelved));
        });
      }

      $scope.filteredAlarmEvents = filteredAlarmEvents;
      $scope.isFilterApplied = $scope.popupFilterExpression.IsAcked  !== '' ||
                               $scope.popupFilterExpression.IsActive !== '' ||
                               $scope.popupFilterExpression.Priority !== '' ||
                               $scope.itemFilterConfig.queryString   !== '';

      $rootScope.$emit('vp.alarm.popupFilterChanged', $scope.isFilterApplied);
    }


    /***************************************************************************
     * NETWORK OFFLINE HANDLING
     **************************************************************************/

    vpAlarmUpdateManagerSvc.registerAlarmUpdatedErrorHandler(setAlarmServiceDisconnected);





    function setAlarmServiceDisconnected() {
      $rootScope.$emit('app:displayErrorPage','serverdown');
    }

  }
]);
