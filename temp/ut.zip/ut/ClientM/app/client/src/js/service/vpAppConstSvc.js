// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular */
/*jshint sub:true, -W101*/

angular.module('vpDataSvcModule')

/**
 * @ngdoc service
 * @module vpDataSvcModule
 * @name vpDataSvcModule.vpAppConstSvc
 * @description this service  includes all of the predefined constants for services.
 */

.factory('vpAppConstSvc', function () {
    'use strict';

    //=================== app constants ===========================================
    var appConstants  = {},
        errorContents = {},
        errorContentsIds = {};

    appConstants["CLIENT_POLLING_RATE_KEY"] = "ClientPollingRate";
    appConstants["CLIENT_POLLING_RATE_DEFAULT_VALUE"] = 250;
    appConstants["CLIENT_POLLING_RATE_MAX_VALUE"] = 120000;
    appConstants["CLIENT_POLLING_RATE_DELAY_KEY"] = "ClientPollingRateDelay";
    appConstants["CLIENT_POLLING_RATE_DELAY_DEFAULT_VALUE"] = 30;
    appConstants["CLIENT_POLLING_RATE_DELAY_MAX_VALUE"] = 500;
    appConstants["CLIENT_POLLING_RATE_DELAY_MIN_VALUE"] = 0;
    appConstants["LICENSE_ALLOCATED_STATUS_KEY"] = "License Allocated";
    appConstants["SESSION_EXPIRED_STATUS_KEY"] = "Session Expired";
    appConstants["RELOAD_CURRENT_DISPLAY_STATUS_KEY"] = "Reload Current Display";
    appConstants["LICENSE_GRACE_MODE_STATUS_KEY"] = "Grace Mode";
    appConstants["WEB_REQUEST_COMMAND_TIMEOUT"] = "WebRequestCommandTimeout";
    appConstants["WEB_REQUEST_INITIAL_TIMEOUT"] = 10;
    appConstants["WEB_REQUEST_MAX_TIMEOUT"] = 20;
    appConstants["WEB_REQUEST_DEFAULT_TIMEOUT"] = 5;
    appConstants["WEB_REQUEST_MIN_TIMEOUT"] = 3;
    appConstants["CURRENT_STATUS_PROPERTY_VALUE_TRUE"] = "true";
    appConstants["CURRENT_STATUS_PROPERTY_VALUE_FALSE"] = "false";
    appConstants["TITLE_BAR_DISPLAY_NAME_IN_DISPLAY_STRING_ID"] = "__DISPLAY__";
    appConstants["TITLE_BAR_PROPERTY_NAME_IN_DISPLAY_STRING_ID"] = "__TITLE__";
    appConstants["MAXIMUM_URL_LENGTH"] = 2048;
    appConstants["MAXIMUM_HTTP_BUFFER_SIZE"] = 2147483647;
    appConstants['GRACE_MESSAGE'] = 'A temporary ViewPoint license is in use.';

    errorContents = [
        "The application is currently not running.Start the application and try connecting again.",
        "Application is currently not running",
        "The command '{0}' cannot be executed in READ - ONLY mode or StartUp Macro.",
        "Cookies are currently disabled in this browser.FactoryTalk ViewPoint requires cookie support.Please enable cookies using Internet Options and try again",
        "Cookies are disabled",
        "Exception during processing of display[{0}::{1}]:{2 }",
        "You are not authorized to view display [{0}::{1}]",
        "There are no licenses currently available for the Web browser to use.Contact your System Administrator or try connecting again later.",
        "Unable to connect to the Web application",
        "There are problems with getting live data.Live Data will be disabled for this display. \n To fix the problem try to republish your application. \n\n  Notes: LiveData server returned error code 0x{0:x8}.",
        "Unable to open the requested display.The web address exceeds the maximum length of {0 } characters.",
        "The session between this browser and the FactoryTalk ViewPoint Server has expired. Try to refresh the browser.\nIf you are still unable to connect, contact your System Administrator or try connecting again later.",
        "Session has expired",
        "Failed to communicate with the Web site.This is possibly due to too many people accessing the Web site at this time.Please try again later.",
        "The browser is either logged off or the FactoryTalk ViewPoint Server is unavailable or unable to provide a ViewPoint client license.Try to restore the connection or refresh the browser.\nIf you are still unable to connect, contact your System Administrator or try connecting again later.",
        "Unable to connect to the Web application",
        "Failed to load the display, possibly due to a loss of connection with the FactoryTalk ViewPoint Server.Try to restore the connection or try to refresh the browser. \nIf you are still unable to load this display, contact your System Administrator or try connecting again later.",
        "Undefined",
        "FactoryTalk ViewPoint",
        "FactoryTalk ViewPoint(Beta)",
        "The write operation for the Data Item associated with the display ‘{0}’, object ‘{1}’ and property ‘{2}’ completed with a status code of ‘{3}’.",
        "The write operation for the Data Item associated with the display ‘{0}’, object ‘{1}’ and property ‘{2}’ completed with a status code of ‘{3}’. Reason: '{4}'",
        "Unable to determine the status of the Data Item write operation initiated by the display ‘{0}’, object ‘{1}’ and property ‘{2}’.",
        "Please adopt latest Chrome or IE11+ on Desktop Windows, Chrome 40+ on Android 4.4+, Safari on IOS 8.0+, IE11+ on Microsoft Surface or windows phone with Windows8.1.",
        "Your browser is invalid",
        "Can't display the page because your device isn't connected to the Internet.",
        "Unable to connect to the Internet",
        "The FactoryTalk ViewPoint Server is unavailable.Try to restore the connection and refresh the browser.\nIf you are still unable to connect, contact your System Administrator or try connecting again later.",
        "Unable to connect to the Web application"
    ];

    errorContentsIds[errorContentsIds["ApplicationNotRunning"] = 0] = "ApplicationNotRunning";
    errorContentsIds[errorContentsIds["ApplicationNotRunningHeader"] = 1] = "ApplicationNotRunningHeader";
    errorContentsIds[errorContentsIds["CommandNotExecuted"] = 2] = "CommandNotExecuted";
    errorContentsIds[errorContentsIds["CookiesAreDisabled"] = 3] = "CookiesAreDisabled";
    errorContentsIds[errorContentsIds["CookiesAreDisabledHeading"] = 4] = "CookiesAreDisabledHeading";
    errorContentsIds[errorContentsIds["DisplayExceptionMsg"] = 5] = "DisplayExceptionMsg";
    errorContentsIds[errorContentsIds["DisplayForbidden"] = 6] = "DisplayForbidden";
    errorContentsIds[errorContentsIds["LicenseAllInUse"] = 7] = "LicenseAllInUse";
    errorContentsIds[errorContentsIds["LicenseAllInUseHeading"] = 8] = "LicenseAllInUseHeading";
    errorContentsIds[errorContentsIds["LiveDateErrMsg"] = 9] = "LiveDateErrMsg";
    errorContentsIds[errorContentsIds["MaxUrlErrorMsg"] = 10] = "MaxUrlErrorMsg";
    errorContentsIds[errorContentsIds["SessionHasExpired"] = 11] = "SessionHasExpired";
    errorContentsIds[errorContentsIds["SessionHasExpiredHeading"] = 12] = "SessionHasExpiredHeading";
    errorContentsIds[errorContentsIds["TooManyConnectionsToServer"] = 13] = "TooManyConnectionsToServer";
    errorContentsIds[errorContentsIds["UnableToGetLicense"] = 14] = "UnableToGetLicense";
    errorContentsIds[errorContentsIds["UnableToGetLicenseHeading"] = 15] = "UnableToGetLicenseHeading";
    errorContentsIds[errorContentsIds["UnableToLoadDisplay"] = 16] = "UnableToLoadDisplay";
    errorContentsIds[errorContentsIds["Undefined"] = 17] = "Undefined";
    errorContentsIds[errorContentsIds["ViewPointTxt"] = 18] = "ViewPointTxt";
    errorContentsIds[errorContentsIds["ViewPointTxtBETA"] = 19] = "ViewPointTxtBETA";
    errorContentsIds[errorContentsIds["WriteOperationCompletionStatus"] = 20] = "WriteOperationCompletionStatus";
    errorContentsIds[errorContentsIds["WriteOperationCompletionStatusEx"] = 21] = "WriteOperationCompletionStatusEx";
    errorContentsIds[errorContentsIds["WriteOperationCompletionStatusUndetermined"] = 22] = "WriteOperationCompletionStatusUndetermined";
    errorContentsIds[errorContentsIds["InvalidDeviceBrowser"] = 23] = "InvalidDeviceBrowser";
    errorContentsIds[errorContentsIds["InvalidDeviceBrowserHeader"] = 24] = "InvalidDeviceBrowserHeader";
    errorContentsIds[errorContentsIds["offlineTxt"] = 25] = "offlineTxt";
    errorContentsIds[errorContentsIds["offlineHeader"] = 26] = "offlineHeader";
    errorContentsIds[errorContentsIds["serverdownTxt"] = 27] = "serverdownTxt";
    errorContentsIds[errorContentsIds["serverdownHeader"] = 28] = "serverdownHeader";
    errorContentsIds[errorContentsIds["DisplayForbiddenHeader"] = 29] = "DisplayForbiddenHeader";


    return {
        appConstants: appConstants,
        errorPage: {
            contents: errorContents,
            Ids: errorContentsIds
        }
    };

});