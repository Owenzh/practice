// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app, $*/

angular.module('vpDataSvcModule')

/**
 * @ngdoc service
 * @module vpDataSvcModule
 * @name vpDataSvcModule.vpSoapSvc
 * @description this service will communicate with admin soap server to manipulate ftvp administration related data.
 */

.factory('vpSoapSvc', [
    '$http',
    '$q',
    'vpSecuritySvc',
    'vpAppUtilSvc',
    function ($http, $q, vpSecuritySvc, vpAppUtilSvc) {
        'use strict';

        var SoapServiceBase = {
            caches: {},
            method: 'POST', // or 'GET'
            resultTagName: '',  //the tagName for result container.
            name: '', //service name
                soapActionUrl:'http://tempuri.org/',
            dataType: 'xml',
            extend: function (obj) {
                var subService = angular.extend({}, this, obj);
                subService.parent = this;
                return subService;
            },

            super: function (methodName, baseClass) {
                baseClass = baseClass || this.parent;

                if (!baseClass && this !== SoapServiceBase) {
                    baseClass = SoapServiceBase;
                }

                var method = baseClass && baseClass[methodName];
                var res = false;

                if (method && angular.isFunction(method)) {
                    res = method.bind(this);
                }

                return res;
            },

            GetEncryptedHeader: function () {
                if (this.caches.header) {
                    return this.caches.header;
                }

                var sessionID = app.env.get('SessionID');
                var encryptedsessionID = vpSecuritySvc.encryptSessionID(sessionID);
                this.caches.header =  "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                                 "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
                                 "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" " +
                                 "xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
                                 "<soap:Header><VPHeader xmlns=\"http://www.silverlight.net\">" +
                                  encryptedsessionID +
                                 "</VPHeader></soap:Header>" +
                                 "<soap:Body>";

                return this.caches.header;
            },
            getBodyStart: function () {
                return this.GetEncryptedHeader();
            },

            getBodyContent: function () {
                return "";
            },

            getBodyEnd: function (header) {
                return header ? "</soap:Body></soap:Envelope>" : "";
            },

                getBody: function (args) {
                var body = '';

                if (this.method === 'POST') {
                    var header = this.getBodyStart();
                        body = header + this.getBodyContent(args) + this.getBodyEnd(header);
                }

                return body;
            },

            getRequestHeader: function () {
                return {
                    'Content-Type': 'text/xml;charset=UTF-8',
                    'Accept': "application/xml, text/xml"
                };
            },

            transformResponse: function (data, headers) {
                if (angular.isString(data)) {
                    var contentType = headers('Content-Type');
                    if (contentType && /(text|application)\/xml\b/i.test(contentType)) {
                        data = $.parseXML(data); // will throw
                    }
                }

                return data;
            },

            onsuccess: function (data) {
                data = $(data.documentElement);
                var _data = data.find(this.resultTagName || this.name + "Response")[0];
                if (_data) {
                    _data = vpAppUtilSvc.xmlToJson(_data);
                }

                return _data;
            },

            onerror: function (data) {
                var error = {};
                data = data && $(data.documentElement);

                if (!data) {
                    error.Message = "fail to fetch data";
                } else {
                    try  {
                        error.Message = data.find('soap:Fault > faultstring').text();
                    } catch (e) {
                        error.Message = "Unable to connect to the web service";
                    }
                }

                return {
                    error: error
                };
            },

                call: function (args) {
                if (!this.soapEndPoint || !this.name) {
                    return false;
                }

                    var soapAction = this.soapActionUrl + this.name;
                var result = $q.defer();
                var that = this;

                var reqHeaders = angular.extend(this.getRequestHeader(), {
                    'SOAPAction': soapAction
                });

                $http({
                    url: this.soapEndPoint,
                    method: this.method,
                        data: this.getBody(args),
                    headers: reqHeaders,
                    transformResponse: $http.defaults.transformResponse.concat(this.transformResponse)
                })
                .success(function(data) {
                    if (that.onsuccess) {
                        data = that.onsuccess.apply(that, arguments);
                    }

                    if (data === false) {
                        data = {
                            error: {
                                Message: "fail to fetch data"
                            }
                        };
                    }

                    if (data.error) {
                        result.reject(data);
                    } else {
                        result.resolve(data);
                    }
                })

                .error(function(data) {
                    if (that.onerror) {
                        data = that.onerror.apply(that, arguments);
                    }

                    result.reject(data);
                });

                return result.promise;
            }
        };

            var WebWorkerSoapSvcHandlers = function(){};

            WebWorkerSoapSvcHandlers.prototype.bind = function (ctx) {
                this.context = ctx;
            };
            WebWorkerSoapSvcHandlers.prototype.handleMessage =  function (e) {
                var data = e.data;
                var that = this.context;
                var cmd = data.cmd;

                var method = that['on' + cmd];
                if (method && angular.isFunction(method)) {
                    data = method.call(that, data.data);
                }
            }


            WebWorkerSoapSvcHandlers.prototype.handleError = function (e) {
                var that = this.context;
                that.worker.handleError.call(that.worker, e.data);
            }

        var WebworkerSoapServiceBase = SoapServiceBase.extend({
            setWebWorker: function (worker) {
                var workerInst = worker.getInstance();
                this.worker = worker;
                this.dfd = $q.defer();
                    var webWorkerSoapSvcHandlers = new WebWorkerSoapSvcHandlers();

                    webWorkerSoapSvcHandlers.bind(this);
                    worker.setConfigData(this.getConfig());

                    workerInst.addEventListener('message',
                        webWorkerSoapSvcHandlers.handleMessage.bind(webWorkerSoapSvcHandlers));
                    workerInst.addEventListener('error',
                        webWorkerSoapSvcHandlers.handleError.bind(webWorkerSoapSvcHandlers));
                },

            getConfig: function () {
                    var soapAction = this.soapActionUrl + this.name;
                var reqHeaders = angular.extend(this.getRequestHeader(), {
                    'SOAPAction': soapAction
                });

                return {
                    url: this.soapEndPoint,
                    name: this.name,
                    method: this.method,
                    data: this.getBody(),
                    headers: reqHeaders,
                    dataType: this.dataType
                };
            },

            checkServerStatus: function () {
                return true;
            },

            onsuccess: function (data) {
                var body = data.body;

                if (!body) {
                    this.onerror(new Error('error while fetching data.'), data);
                    body = false;

                } else {
                    if (this.dataType === 'xml') {
                        body = $.parseXML(body);
                    }

                    body = this.super('onsuccess', SoapServiceBase)(body);
                }

                body.serverStatus = this.checkServerStatus(body);
                return body;
            },

            onerror: function (err , data) {
                return {
                    error: err,
                    data: data
                };
            },

                call: function (cmd, data) {
                if (!this.soapEndPoint || !this.name || !this.worker || !cmd) {
                    return false;
                }

                    this.worker.invoke(cmd, data);
            },

            terminate: function () {
                this.worker.terminate();
            }
        });

        return {
            SoapServiceBase: SoapServiceBase,
            WebworkerSoapServiceBase: WebworkerSoapServiceBase
        };
}]);