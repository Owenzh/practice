// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

/**
 * @ngdoc overview
 * @module appModule
 * @description
 * The Module is the application module.
 */
var app = angular.module('appModule', [
    'ui.router',
    'ngTouch',
    'ngAnimate',
    'vpServiceModule',
    'vpDirectiveModule',
    'vpFilterModule',
    'mobile-toolkit-ra',

    // required by `raToast` directive
    'toaster',

    // required by `raItemFilter` directive
    'ngSanitize'
])

.config([
    '$compileProvider',
    function($compileProvider) {
        "use strict";
        $compileProvider.debugInfoEnabled(false);
    }
])

.run([
    '$rootScope',
    '$injector',
    '$translate',
    'vpLayoutSvc',
    'vpAppSvc',
    function($rootScope, $injector, $translate, vpLayoutSvc, vpAppSvc) {
        "use strict";
        $rootScope.isPhone = vpLayoutSvc.isPhone();
        app.scope = $rootScope;
        app.injector = $injector;
        app.translateSvc = $translate;
        vpAppSvc.bootupFramework(app, {
            noSniffing: true  //disable device sniffing.
        });
    }
]);


angular.module('vpDirectiveModule', []);
angular.module('vpFilterModule', []);
angular.module('vpDataSvcModule', ['mobile-toolkit-ra']);
angular.module('vpServiceModule', [
    'ui.router',
    'vpDataSvcModule'
])

.config([
    '$httpProvider',
    '$translateProvider',
    function($httpProvider, $translateProvider) {
        "use strict";
        $httpProvider.useApplyAsync(true);
        $httpProvider.defaults.timeout = 5000;
        $translateProvider.useStaticFilesLoader({
            "files" : [{
                prefix: 'locale/mft/locale-',
                suffix: '.json'
            },
            {
                prefix: 'locale/ftvp/locale-',
                suffix: '.json'
            }]
        })
        .fallbackLanguage('en');
        // .registerAvailableLanguageKeys(['en','ja','zh'], {
        //   'en_*': 'en',
        //   'ja_*': 'ja',
        //   'zh_*': 'zh'
        // })
        // .determinePreferredLanguage();
    }
])

.run([
    '$rootScope',
    'vpRouterSvc',
    'vpLayoutSvc',
    'vpErrorHandlerSvc',
    function($rootScope, vpRouterSvc, vpLayoutSvc, vpErrorHandlerSvc) {
        "use strict";
        $rootScope.gServicesUrlPfx = "api/";
        $rootScope.gBaseUrl = "";

        vpErrorHandlerSvc.start();
        vpLayoutSvc.startMonitoring();
        vpRouterSvc.startMonitoring();
    }
]);

//================= global functions which  will be used across the application ==========
// avoid defining global functions.
//create a utility function to define a new class
app.createClass = function createClass(base, props){
    "use strict";
    var hasContext = this !== window && angular.isFunction(this);

    if (!base) {
        return hasContext ? this : angular.noop;
    } else if (!angular.isFunction(base)) {
        props = base;
        base = hasContext ? this : angular.noop;
    }

    var Class;
    if (props && props.hasOwnProperty('constructor')) {
        var childConstructor = props.constructor;
        Class = function () {
            return childConstructor.apply(this, arguments);
        };

        delete props.constructor;

    }else {
        Class = function () {
            return base.apply(this, arguments);
        };
    }

    if (props && props._static) {
        angular.extend(Class, props._static);
        props._static = null;
    }

    Class.prototype = angular.extend(Object.create(base.prototype), {
        super: function (methName) {
            var meth = base.prototype[methName];
            var args = [].slice.call(arguments, 1);
            return angular.isFunction(meth) && meth.apply(this, args);
        }
    }, props);

    Class.extend = createClass;
    return Class;
};

// The dictionary is common class for map structure
app.Dictionary = (function () {
				function Dictionary() {            
					switch (arguments.length) {
						case 0:
							this.constructorNoParameter();
							break;
						//So far , we just support no parameter for constructor,  in the future ,  we will support more constructors if necessary.
						default:
							throw "Invalid overload call for: constructor";
					}
				}
				Dictionary.prototype.constructorNoParameter = function () {
					this.count = 0;
					this.keys = [];
					this.values = [];
					this.lastIndexSearched = -1;
					this.lastKeySearched = null;
				};

				Dictionary.prototype.add = function () {
					if(arguments.length !==2 ){
					   throw "Invalid count of parameters";
					}
					 this.count++;
					 this.keys.push(arguments[0]);
					 this.values.push(arguments[1]);
				};
				/* Clear function implementation */
				Dictionary.prototype.clear = function () {
					this.keys.length = 0;
					this.keys.length = 0;
					this.count = 0;
					this.lastIndexSearched = -1;
					this.lastKeySearched = null;
				};
				/* ContainsKey function implementation */
				Dictionary.prototype.containsKey = function (key) {
					if (key == undefined) {
						return false;
					}
					var result = false;
					if (this.lastKeySearched != key) {
						this.lastIndexSearched = this.keys.indexOf(key);
						result = (this.lastIndexSearched >= 0);
						if (result) {
							this.lastKeySearched = key;
						}
						else {
							this.lastKeySearched = null;
						}
					}
					else {
						result = true;
					}
					return result;
				};


				Dictionary.prototype.remove = function (key) {               
					var  index = this.keys.indexOf(key);
					if (index >= 0) {
						this.count--;
						this.keys.splice(index, 1);
						this.values.splice(index, 1);
						if(this.lastIndexSearched == index) {
					            this.lastIndexSearched = -1;
					            this.lastKeySearched = null;
						}
						return true;
					}
					return false;
				};

				Dictionary.prototype.getItem = function (key) {
					if (this.lastKeySearched == key) {
						return this.values[this.lastIndexSearched];
					}
					else {
						this.lastIndexSearched = this.keys.indexOf(key);
						if (this.lastIndexSearched >= 0) {
							this.lastKeySearched = key;
						}
						else {
							this.lastKeySearched = null;
						}
					}
					
					if(this.lastIndexSearched >= 0 ) {						
					return this.values[this.lastIndexSearched];
					}
					else {
						return null;
					}
					
				};

				Dictionary.prototype.setItem = function (key, value) {
					if (this.lastKeySearched != key) {
						this.lastIndexSearched = this.keys.indexOf(key);
					}
					if (this.lastIndexSearched >= 0) {
						this.lastKeySearched = key;
						this.values[this.lastIndexSearched] = value;
					}
					else {
						this.lastIndexSearched = -1;
						this.lastKeySearched = null;

						this.add(key, value);
					}
				};
				return Dictionary;
			})();