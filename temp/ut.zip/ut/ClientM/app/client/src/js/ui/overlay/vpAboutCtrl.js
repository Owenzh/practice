// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/
/*jshint sub:true*/

angular.module('appModule')

/**
 * @ngdoc controller
 * @module appModule
 * @name appModule.vpAboutCtrl
 * @description this controller control the "about" overlay.
 */

.controller('vpAboutCtrl', [
    '$scope',
    'config',
    '$injector',
    function ($scope, config, $injector) {
        "use strict";
        var constApp = $injector.get('Const.App');
        var appConstants = $injector.get('vpAppConstSvc').appConstants;

        $scope.userName = config.userName;
        $scope.title = app.translateSvc.instant("VP_ABOUT.ABOUT_TITLE",{title: constApp.productName});
        $scope.versionLabel = app.translateSvc.instant("VP_ABOUT.VERSION_TITLE");
        $scope.mediatitle = app.translateSvc.instant("VP_ABOUT.MEDIAL_TITLE");
        $scope.usertitle = app.translateSvc.instant("VP_ABOUT.USER_TITLE");
        $scope.btnCloseTitle = app.translateSvc.instant("VP_RESOURCES.BTN_CLOSE");
        $scope.productName = constApp.productName;
        $scope.productVersion = app.env.get('appVersion');
        $scope.messageType = "information";
        $scope.companyName = constApp.companyName;
        $scope.graceMessage = app.env.get('isGraceMode') && appConstants['GRACE_MESSAGE'];
        $scope.media = $injector.get('Const.About.media');

        $scope.close = function () {
            $scope.$close(true);
        };
    }
]);