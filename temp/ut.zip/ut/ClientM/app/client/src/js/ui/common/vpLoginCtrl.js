// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/
(function () {
    'use strict';
    angular.module('appModule')
    .config(['$stateProvider',
        function ($stateProvider) {
            $stateProvider.state('login', {
                url: '/signin',
                templateUrl: 'js/ui/common/vpLoginCtrl.tpl.html',
                controller: 'vpLoginCtrl as login'
            });
        }
    ])

    /**
     * @ngdoc controller
     * @module appModule
     * @name appModule.vpLoginCtrl
     * @description controller for "login" state.
     */

    .controller('vpLoginCtrl', [
        '$injector',
        '$scope',
        app.createClass({
            constructor: function (injector,scope) {
                this.scope = scope;
                this.injector = injector;
                this.init();
            },

            init: function () {
                this.loginIng = false;
                this.user = {
                    name: '',
                    password: '',
                    directory: '',
                    rememberme: false
                };

                var appRes = this.injector.get('Const.App.resource');
                var that = this;
                this.logo = appRes.siteLogo;
                this._checkCookiesDisabled();
                this._checkStartupError();
                this._initialDirectory();
                this.initLayout();

                app.translateSvc().then(function() {
                    that.subtitle = app.translateSvc.instant('VP_RESOURCES.SITE_SUBTITLE');
                    that.formtitle = app.translateSvc.instant('VP_LOGIN.FORM_TITLE');
                    that.usernameLabel = app.translateSvc.instant('VP_LOGIN.USER_NAME_LABEL');
                    that.passwordLabel = app.translateSvc.instant('VP_LOGIN.PASSWORD_LABEL');
                    that.directoryLabel = app.translateSvc.instant('VP_LOGIN.DIRECTORY_LABEL');
                    that.rmbmeLabel = app.translateSvc.instant('VP_LOGIN.REMEMBERME_LABEL');
                    that.btnSubmitLabel = app.translateSvc.instant('VP_LOGIN.BTN_SUBMIT_LABEL');

                    that.injector.get('raTabletNavbarSvc').setSubTitle(that.config.groupId, that.subtitle);
                    that.scope.$emit('app:loaded');
                });
            },

            _checkStartupError: function () {
                var topWinLocationSvc = this.injector.get('vpAppUtilSvc').topWinLocationSvc;
                this.error = decodeURIComponent(app.env.get('msg')||'');
                if (this.error) {
                    topWinLocationSvc.removeTopLocationErrorMsg();
                }
            },
			_checkCookiesDisabled: function () {
                var appUtilSvc = this.injector.get('vpAppUtilSvc');
                this.hasError = false;
                if (!appUtilSvc.isCookiesEnable()) {
                    this.hasError = true;
                    this.errorData = {
                        type: 'cookiesDisable',
                        title: 'Cookies are disabled',
                        content: 'Cookies are currently disabled in this browser. FactoryTalk ViewPoint requires cookie support.Please enable cookies using Internet Options and try again.'
                    };
                    return;
                }
            },

            initLayout: function () {
                this.config = {
                    groupId: 'login_groupId',
                    logoPath: 'img/FTViewPoint-logo.png',
                    linkAddress: '#',
                    subtitle: this.subtitle
                };
            },

            /**
             * @ngdoc method
             * @name appModule.vpLoginCtrl#_initialDirectory
             * @methodOf appModule.vpLoginCtrl
             * @param  none
             * @returns none
             * @description this method will initialize directory list and set the default value.
             */
            _initialDirectory: function () {
                this.directoryList =  this.injector.get('Const.Login.Directories');
                var initialScope = app.env.get('scope');

                for ( var i=this.directoryList.length-1; i>=0; --i ) {
                    if (this.directoryList[i].value === initialScope ){
                        this.user.directory = this.directoryList[i];
                        break;
                    }
                }
            },

            onSubmitParent: function () {
                var that = this;
                that.loginIng = true;
                this.scope.$digest();
            }
        })
    ]);
})();