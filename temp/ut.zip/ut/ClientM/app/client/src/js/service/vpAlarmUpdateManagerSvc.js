// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/
/*jshint sub:true*/
angular.module('vpServiceModule')

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpLicenseUpdateManagerSvc
 * @description this service will provide information license update manager
 */

.factory('vpAlarmUpdateManagerSvc', [
  '$injector',
  '$filter',
  'vpAlarmDataSvc',
  'vpErrorHandlerSvc',
  function($injector, $filter, vpAlarmDataSvc, vpErrorHandlerSvc) {
    "use strict";

    var getUpdatesJsonAsync = vpAlarmDataSvc.getUpdatesJsonAsync;

    var Employer = {
      employeeWorker: function(worker) {
        this.worker = worker;
        this.client = worker.messager;
      }
    };

    // To store the alarm data.
    var alarmDataMap = new app.Dictionary();

    // To store the event handlers to handle the alarm event updated.
    var alarmUpdatedHandlers = [];

    // To store the event handler to handle error received alarm event updated.
    var alarmUpdatedErrorHandlers = [];

    var alarmDataMaxValue = 4096;
    var initialized = false;
    var alarmEventFlags = {
      inactive: 1,
      active: 2,
      acked: 4,
                faulted: 8,
                disabled: 16
    };

    var lastUpdateTimeFormat = "d MMM, y '-' h:mm a";   // "M/d/yy '-' h:mm a";

    function getJsonData(data) {
                var jsonData = eval(data.GetUpdatesJsonResult);
      return jsonData;
    }

    function handleReceviedAlarmEvents(jsonDatas) {
      var events = [];

      if (!initialized) {
        initialized = true;
      }

      for (var i = 0; i < jsonDatas.length; i++) {
        handleOneReceivedAlarmEvent(jsonDatas[i], events);
      }

      notifyEvents(events);
    }

    function handleOneReceivedAlarmEvent(alarmData, events) {
      var key = generateAlarmEventId(alarmData);

      if (alarmDataMap.containsKey(key)) {
        updateAlarmData(key, alarmData, events);

      } else {
        addNewAlarmData(key, alarmData, events);
      }

      limitAlarmCount(events);
    }

    function limitAlarmCount(events) {
      while (alarmDataMap.count > alarmDataMaxValue) {
        var key = alarmDataMap.keys[0];
        var value = alarmDataMap.values[0];
        alarmDataMap.remove(key);
        addUpdatedEvents(events, 'D', value);
      }
    }

    function generateAlarmEventId(alarmEvent) {
      return alarmEvent.Source + "-" + alarmEvent.ConditionName;
    }

    function updateAlarmData(key, updateAlarmData, events) {
      var sourceAlarmData = alarmDataMap.getItem(key);

      // update alarm message
      if (updateAlarmData.Message) {
        sourceAlarmData.Message = decodeURIComponent(updateAlarmData.Message.replace(/\+/g,'%20'));

      } else {
        sourceAlarmData.Message = "";
      }

      var isAcked = isAckedAlarm(updateAlarmData)
        // update Acked/Unacked
      if (isAcked) {
        sourceAlarmData.IsAcked = true;

      } else {
        sourceAlarmData.IsAcked = false;
      }

      var isActive = isActiveAlarm(updateAlarmData);

      // update Active/Inactive
      sourceAlarmData.IsActive = isActive;

      var isInScope = isInScopeAlarm(updateAlarmData)

      // update Faulted
      if (isInScope) {
        sourceAlarmData.IsInScope = true;

      } else {
        sourceAlarmData.IsInScope = false;
      }

      sourceAlarmData.Area = updateAlarmData.Area;
      sourceAlarmData.State = updateAlarmData.State;
      sourceAlarmData.ParsedState = $filter('vpAlarmState')(updateAlarmData.State);
      sourceAlarmData.IsSuppressed = updateAlarmData.IsSuppressed;
      sourceAlarmData.AckRequired = updateAlarmData.AckRequired;
      sourceAlarmData.EventCategory = updateAlarmData.EventCategory;
      sourceAlarmData.EventType = updateAlarmData.EventType;
      sourceAlarmData.ActiveTimeValue = updateAlarmData.ActiveTime;
      sourceAlarmData.ActiveTime = parseDate(updateAlarmData.ActiveTime);
      sourceAlarmData.LastUpdateTime = parseDate(updateAlarmData.Time);
      sourceAlarmData.ParsedLastUpdateTime = $filter('date')(parseDate(updateAlarmData.Time).getTime(), lastUpdateTimeFormat);
      sourceAlarmData.Cookie = updateAlarmData.Cookie;
      sourceAlarmData.CookieHigh = updateAlarmData.CookieHigh;
      sourceAlarmData.CookieLow = updateAlarmData.CookieLow;
      sourceAlarmData.Severity = updateAlarmData.Severity;
      sourceAlarmData.CurrentValue = updateAlarmData.CurrentValue;
      sourceAlarmData.Priority = updateAlarmData.Priority;
      sourceAlarmData.ParsedPriority = $filter('vpAlarmPriority')(updateAlarmData.Priority);
      sourceAlarmData.ExceededLimit = updateAlarmData.ExceededLimit;
      sourceAlarmData.AlarmClass = updateAlarmData.AlarmClass;
      sourceAlarmData.IsShelved = updateAlarmData.IsShelved;
      sourceAlarmData.Tag1Value = updateAlarmData.Tag1Value;
      sourceAlarmData.Tag2Value = updateAlarmData.Tag2Value;
      sourceAlarmData.Tag3Value = updateAlarmData.Tag3Value;
      sourceAlarmData.Tag4Value = updateAlarmData.Tag4Value;
      sourceAlarmData.HmiCommand = updateAlarmData.HmiCommand;
      sourceAlarmData.AlarmCount = updateAlarmData.AlarmCount;
      sourceAlarmData.AckComment = updateAlarmData.AckComment;
      sourceAlarmData.SuppressComment = updateAlarmData.SuppressComment;
      sourceAlarmData.AckTime = parseDate(updateAlarmData.AckTime);
      sourceAlarmData.ShelveTime = parseDate(updateAlarmData.ShelveTime);
      sourceAlarmData.InActiveTime = parseDate(updateAlarmData.InActiveTime);
      sourceAlarmData.AlarmCount = updateAlarmData.AlarmCount;
      sourceAlarmData.ShelveComment = updateAlarmData.ShelveComment;
      sourceAlarmData.ShelveUser = updateAlarmData.ShelveUser;
      sourceAlarmData.AlarmGroup = updateAlarmData.AlarmGroup;
                var isDisabled = isDisabledAlarm(updateAlarmData);
                if (isDisabled) {
                    sourceAlarmData.IsDisabled = true;
                } else {
                    sourceAlarmData.IsDisabled = false;
                }

      if (isInvalidAlarm(isAcked, isActive, isInScope)) {
        alarmDataMap.remove(key);
        addUpdatedEvents(events, 'D', sourceAlarmData);

      } else {
        addUpdatedEvents(events, 'U', sourceAlarmData);
      }
    }

    function isAckedAlarm(alarmData) {
      return (alarmData.State & alarmEventFlags.acked) != 0;
    }

    function isActiveAlarm(alarmData) {
      return (alarmData.State & alarmEventFlags.active) != 0;
    }

    function isInScopeAlarm(alarmData) {
      return ((alarmData.State & alarmEventFlags.faulted) == 0);
    }

    function isInvalidAlarm(isAcked, isActive, isInScope) {
      return (isAcked && !isActive) || !isInScope;
    }

            function isDisabledAlarm(alarmData) {
                return (alarmData.State & alarmEventFlags.disabled) != 0;
            }
    function parseDate(timeticks) {
      if (timeticks == 0) {
        return null;
      }
      // the number of .net ticks at the unix epoch
      var epochTicks = 621355968000000000;

      // there are 10000 .net ticks per millisecond
      var ticksPerMillisecond = 10000;

      // calculate the total number of .net ticks for your date
      var ticks = (timeticks - epochTicks) / ticksPerMillisecond;

      var date = new Date(ticks);

      return date;
    }

    function addNewAlarmData(key, alarmData, events) {
      var isActive = isActiveAlarm(alarmData);
      var isAcked = isAckedAlarm(alarmData);
      var isScope = isInScopeAlarm(alarmData);
                var isDisabled = isDisabledAlarm(alarmData);

      if (isInvalidAlarm(isAcked, isActive, isScope)) {
        return;
      }

      var area = alarmData.Area;
      var state = alarmData.State;
      var parsedState = $filter('vpAlarmState')(alarmData.State);
      var isSuppressed = alarmData.IsSuppressed;
      var ackRequired = alarmData.AckRequired;
      var eventCategory = alarmData.EventCategory;
      var eventType = alarmData.EventType;
      var lastUpdateTime = parseDate(alarmData.Time);
      var parsedLastUpdateTime = $filter('date')(parseDate(alarmData.Time).getTime(), lastUpdateTimeFormat);
      var activeTimeValue = alarmData.ActiveTime;
      var activeTime = parseDate(alarmData.ActiveTime);
      var cookie = alarmData.Cookie;
      var cookieHigh = alarmData.CookieHigh;
      var cookieLow = alarmData.CookieLow;
      var source = alarmData.Source;
      var message = decodeURIComponent((alarmData.Message ? alarmData.Message.replace(/\+/g,'%20') : ""));
      var severity = alarmData.Severity;
      var priority = alarmData.Priority;
      var parsedPriority = $filter('vpAlarmPriority')(priority);
      var conditionName = alarmData.ConditionName;
      var currentValue = alarmData.CurrentValue;
      var exceededLimit = alarmData.ExceededLimit;
      var alarmClass = alarmData.AlarmClass;
      var sourceParts = source.split(":");
      var alarmName = "";

      for (var partIdx = 2; partIdx < sourceParts.length; partIdx++) {
        if (partIdx != 2) {
          alarmName += ":";
        }
        alarmName += sourceParts[partIdx];
      }

      var serverName = "";
      if (sourceParts.length > 1) {
        serverName = sourceParts[1];
      }

      var areaName = "";
      if (sourceParts.length > 0) {
        areaName = sourceParts[0];
      }

      var isShelved = alarmData.IsShelved;
      var tag1Value = alarmData.Tag1Value;
      var tag2Value = alarmData.Tag2Value;
      var tag3Value = alarmData.Tag3Value;
      var tag4Value = alarmData.Tag4Value;
      var hmiCommand = alarmData.HmiCommand;
      var alarmCount = alarmData.AlarmCount;
      var ackComment = alarmData.AckComment;
      var suppressComment = alarmData.SuppressComment;
      var ackTime = parseDate(alarmData.AckTime);
      var shelveTime = parseDate(alarmData.ShelveTime);
      var inActiveTime = parseDate(alarmData.InActiveTime);
      var shelveComment = alarmData.ShelveComment;
      var shelveUser = alarmData.ShelveUser;
      var alarmGroup = alarmData.AlarmGroup;

      var newAlarmData = {
        Id: key,
        Area: area,
        State: state,
        ParsedState: parsedState,
        IsSuppressed: isSuppressed,
        EventCategory: eventCategory,
        EventType: eventType,
        AckRequired: ackRequired,
        IsActive: isActive,
        IsAcked: isAcked,
        IsInScope: isScope,
        LastUpdateTime: lastUpdateTime,
        ParsedLastUpdateTime: parsedLastUpdateTime,
        ActiveTimeValue: activeTimeValue,
        ActiveTime: activeTime,
        Cookie: cookie,
        CookieHigh: cookieHigh,
        CookieLow: cookieLow,
        Source: source,
        Message: message,
        Severity: severity,
        Priority: priority,
        ParsedPriority: parsedPriority,
        ConditionName: conditionName,
        CurrentValue: currentValue,
        ExceededLimit: exceededLimit,
        AlarmClass: alarmClass,
        AlarmName: alarmName,
        ServerName: serverName,
        AreaName: areaName,
        IsShelved: isShelved,
        Tag1Value: tag1Value,
        Tag2Value: tag2Value,
        Tag3Value: tag3Value,
        Tag4Value: tag4Value,
        HmiCommand: hmiCommand,
        AlarmCount: alarmCount,
        AckComment: ackComment,
        SuppressComment: suppressComment,
        AckTime: ackTime,
        ShelveTime: shelveTime,
        InActiveTime: inActiveTime,
        ShelveComment: shelveComment,
        ShelveUser: shelveUser,
                    AlarmGroup: alarmGroup,
                    IsDisabled: isDisabled
      };

      alarmDataMap.add(key, newAlarmData);

      addUpdatedEvents(events, 'A', newAlarmData);
    }


    function addUpdatedEvents(events, optType, data) {
      var event = {
        optType: optType,
        data: data
      };
      events.push(event);
    }


    function notifyEvents(events) {
      if (events.length == 0) {
        return;
      }

      for (var i = 0; i < alarmUpdatedHandlers.length; i++) {
        var handler = alarmUpdatedHandlers[i];

        try {
          handler(events);
                    } catch (e) {
      }
    }
            }

    function notifyErrorEvents(err, clientStatus) {
      for (var i = 0; i < alarmUpdatedErrorHandlers.length; i++) {
        var handler = alarmUpdatedErrorHandlers[i];
        try {
          handler(err, clientStatus);
                    } catch (e) {
                    }
      }
    }

    return angular.extend({}, Employer, {

      employeeWorker: function(worker) {
        Employer.employeeWorker.apply(this, arguments);
        getUpdatesJsonAsync.setWebWorker(worker);
      },

      start: function() {
        getUpdatesJsonAsync.call('start');
      },

      stop: function() {
        getUpdatesJsonAsync.terminate();
      },

      onsuccess: function(data) {
        this.worker.onsuccess(data);
        var jsonData = getJsonData(data);
        handleReceviedAlarmEvents(jsonData);
      },

      onerror: function(err, clientStatus) {
        vpErrorHandlerSvc.propagate(err);
        this.worker.onerror(clientStatus);
        notifyErrorEvents(err, clientStatus);
      },

      getAlarms: function() {
        return alarmDataMap.values;
      },

      getActiveAlarmCount: function() {
        var allAlarms = alarmDataMap.values;
        var activeAlarmCount = 0;

        for (var i = 0; i < allAlarms.length; i++) {
          var alarm = allAlarms[i];

          if ((alarm.IsActive && !alarm.IsAcked) || (!alarm.IsAcked && !alarm.IsSuppressed) || (!alarm.IsAcked && !alarm.IsShelved)) {
            activeAlarmCount += 1;
          }
        }

        return activeAlarmCount;
      },

      registerAlarmUpdatedHandler: function(fun) {
        alarmUpdatedHandlers.push(fun);
      },

      unregisterAlarmUpdatedHandler: function(fun) {
        for (var i = 0; i < alarmUpdatedHandlers.length; i++) {
          var handler = alarmUpdatedHandlers[i];
          if (fun === handler) {
            alarmUpdatedHandlers.splice(i, 1);
            return true;
          }
        }

        return false;
      },

      registerAlarmUpdatedErrorHandler: function(fun) {
        alarmUpdatedErrorHandlers.push(fun);
      },

      unregisterAlarmUpdatedErrorHandler: function(fun) {
        for (var i = 0; i < alarmUpdatedErrorHandlers.length; i++) {
          var handler = alarmUpdatedErrorHandlers[i];

          if (fun === handler) {
            alarmUpdatedErrorHandlers.splice(i, 1);
            return true;
          }
        }
      },

      clearAlarmUpdatedErrorHandlers: function() {
        alarmUpdatedErrorHandlers.length = 0;
      },

      clearAlarmUpdatedHandlers: function() {
        alarmUpdatedHandlers.length = 0;
      },

                getInitialized: function () {
                    return initialized;
                },
                getAlarm: function (id) {
                    if (alarmDataMap.containsKey(id)) {
                        return alarmDataMap.getItem(id);
                    } else {
                        return null;
                    }

                }

            });
        }
    ]);