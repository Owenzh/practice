// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

angular.module('appModule')

/**
 * @ngdoc controller
 * @module appModule
 * @name appModule.vpConfirmCtrl
 * @description this controller control the confimation overlay.
 */

.controller('vpConfirmCtrl', [
    '$scope',
    'config',
    function ($scope, config) {
        'use strict';

        $scope.content = config;
        $scope.title = config.title;
        $scope.messageType = "information";
        $scope.actionDefinitions = [
            {
                tooltipText : app.translateSvc.instant("VP_RESOURCES.BTN_YES"),
                iconClass: "ra-icon ra-icon-commit",
                actionName: "yes",
                doAction: function () {
                    $scope.$close('yes');
                }
            },
            {
                tooltipText : app.translateSvc.instant("VP_RESOURCES.BTN_NO"),
                iconClass: "ra-icon ra-icon-cancel",
                actionName: "no",
                doAction: function () {
                    $scope.$dismiss('no');
                }
            }
        ];
    }
]);