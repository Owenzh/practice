// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('vpDirectiveModule')

/**
 * @ngdoc directive
 * @name vpDirectiveModule.directive:vpMessageRibbon
 * @module vpDirectiveModule
 * @restrict A
 *
 * @description
 * The directive is responsible to display a message ribbon on the bottom of the web page
 * and fade away after several seconds.
 *
 * @example
 * <example module="mobile-toolkit-ra">
 *  <file name="index.html">
 *       <div ng-controller="vpMsgRibbonCtrl">
 *          <div vp-message-ribbon vp-message-options="msgoptions"> </div>
 *          <button ng-click="showMessageRibbon()">show message ribbon</button>
 *       </div>
 *  </file>
 *
 *  <file name="controller.js">
 *      angular.module('vpMsgRibbonModule', []);
 *      angular.module('vpMsgRibbonModule')
 *          .controller('vpMsgRibbonCtrl', ['$scope',
 *           function ($scope) {
 *               "use strict";
 *               $scope.cache = [];
 *               $scope.msgoptions = {
 *                   hideDelay: 2,
 *                   type: 3,  //success
 *                   cache: $scope.cache
 *               };
 *
 *               $scope.showMessageRibbon = function () {
 *                   var message = "test message ribbon";
 *                   var type = 3; //success by default.
 *                   $scope.$emit('app:updateMessageRibbon', message, type);
 *               }
 *         }]);
 *  </file>
 * </example>
 */

.directive('vpMessageRibbon', [
  '$rootScope',
  '$animate',
  '$timeout',
  function($rootScope, $animate, $timeout) {
    'use strict';
    var HIDE_DELAY = 5;   /*hide after 5 seconds*/
    var DEFAULT_TYPE = 3; /*success*/
    var queueWait = 0;    /* whether to wait for queue*/
    var hideDelay = 0;

    var MessageTypes = [
      0,
      'ra-icon-information message-info', //1 information
      'ra-icon-error message-danger',  //2 error
      'glyphicon glyphicon-ok-circle message-success',     //3 success
      'ra-icon-warning message-warning'   //4 warning
    ];

    return {
      restrict: 'A',
      scope: {
        options: "=vpMessageOptions"
      },
      replace: true,
      template: "<div class='vp-msgribbon'> <span ng-class='type'></span> {{message}} </div>",
      link: function(scope, element) {
        function onShowComplete() {
          $timeout(onShowCompleteDelay, hideDelay * 1000);
          queueWait--;

          if (queueWait > 1) {
            queueWait = 1;
          }
        }

        function onShowCompleteDelay() {
          if (queueWait > 0) {
            onShowComplete();
          } else {
            queueWait = 0;
            $animate.removeClass(element, 'show');
          }
        }

        function getMessageTypeClass(type) {
          if (!(type in MessageTypes)) {
            if (scope.options.type in MessageTypes) {
              type = scope.options.type;
            } else {
              type = DEFAULT_TYPE;
            }
          }

          return MessageTypes[type];
        }

        if (!scope.options.hideDelay) {
          scope.options.hideDelay = HIDE_DELAY;
        }

        hideDelay = scope.options.hideDelay;
        scope.options.type = scope.options.type || DEFAULT_TYPE;

        var cache = scope.options.cache || [];
        var offme = $rootScope.$on('app:updateMessageRibbon', function(event, message, type) {
          cache.unshift({
            message: message,
            type: type,
            when: Date.now()
          });
          scope.message = message;
          scope.type = getMessageTypeClass(type);
          queueWait++;

          if (!element.hasClass('show')) {
            $timeout(function(){
              $animate.addClass(element, 'show').then(onShowComplete);
            });
          }
        });

        element.on('$destroy', function() {
           offme();
           offme = null;
        });
      }
    };
  }
]);