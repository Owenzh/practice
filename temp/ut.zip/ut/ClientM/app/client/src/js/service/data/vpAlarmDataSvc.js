// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

angular.module('vpDataSvcModule')


    /**
     * @ngdoc service
     * @module vpDataSvcModule
     * @name vpDataSvcModule.vpAlarmDataSvc
     * @description this service will communicate with alarm data server to get
     * alarm data from server.
     */
    .provider('vpAlarmDataSvc', function () {
        'use strict';

        this.$get = [
            '$rootScope',
            'vpErrorHandlerSvc',
            'vpSoapSvc',
            function ($rootScope, vpErrorHandlerSvc, vpSoapSvc) {
                var AlarmSoapWorkerSvc = vpSoapSvc.WebworkerSoapServiceBase.extend({
                    soapEndPoint: '/FTVP/AlarmServer/Service.asmx',
                    soapActionUrl: 'http://rockwell.com/'
                });

                var AlarmSoapAcknowledgeSvc = vpSoapSvc.SoapServiceBase.extend({
                    name: 'AckAlarms',
                    soapEndPoint: '/FTVP/AlarmServer/Service.asmx',
                    soapActionUrl: 'http://rockwell.com/',
                    getBodyContent: function(args){

                        var paramXML = "<AckAlarms  xmlns=\"http://rockwell.com/\">";
                        paramXML += "<szComment>" + args.szComment + "</szComment>";
                        paramXML += "<ackDesc>";

                        args.ackDesc.forEach(function (item) {
                            paramXML += "<AckStruct>";
                            paramXML += "<areaName>" + item.areaName + "</areaName>";
                            paramXML += "<strSource>" + item.strSource + "</strSource>";
                            paramXML += "<strConditionName>" + item.strConditionName + "</strConditionName>";
                            paramXML += "<lActiveTime>" + item.lActiveTime + "</lActiveTime>";
                            paramXML += "<lCookie>" + item.lCookie + "</lCookie>";
                            paramXML += "</AckStruct>";
                        });

                        paramXML += "</ackDesc>";
                        paramXML += "</AckAlarms>";

                        return paramXML;
                    }
                });
	        var AlarmSoapShelveSvc = vpSoapSvc.SoapServiceBase.extend({
                    name: 'ShelveAlarms',
                    soapEndPoint: '/FTVP/AlarmServer/Service.asmx',
                    soapActionUrl: 'http://rockwell.com/',
                    getBodyContent: function(args){

                        var paramXML = "<ShelveAlarms  xmlns=\"http://rockwell.com/\">";
						paramXML += "<bNewState>" + args.bNewState + "</bNewState>";
                        paramXML += "<dwTargetDuration>" + args.dwTargetDuration + "</dwTargetDuration>";
                        paramXML += "<szComment>" + args.szComment + "</szComment>";
                        paramXML += "<shelveDesc>";

                        args.shelveDesc.forEach(function (item) {
                            paramXML += "<ShelveStruct>";
                            paramXML += "<areaName>" + item.areaName + "</areaName>";
                            paramXML += "<strSource>" + item.strSource + "</strSource>";
                            paramXML += "<strConditionName>" + item.strConditionName + "</strConditionName>";
                            paramXML += "</ShelveStruct>";
                        });

                        paramXML += "</shelveDesc>";
                        paramXML += "</ShelveAlarms>";
                        return paramXML;
                    }
                });

                var clientID = getClientID();

                function getClientID() {
                    return getSubStrForClientID(false) + getSubStrForClientID(true) + getSubStrForClientID(true) + getSubStrForClientID(false);
                }

                function getSubStrForClientID(withLine) {
                    var tempStr = (Math.random().toString(16) + "000000000").substr(2, 8);
                    return withLine ? "-" + tempStr.substr(0, 4) + "-" + tempStr.substr(4, 4) : tempStr;
                }

                var AlarmService = {};
                AlarmService.alarmJsonAcknowledgeSvc = AlarmSoapAcknowledgeSvc;
		AlarmService.alarmJsonShelveSvc = AlarmSoapShelveSvc;

                AlarmService.getUpdatesJsonAsync = AlarmSoapWorkerSvc.extend({

                    //Alarm Service name
                    name: 'GetUpdatesJson',

                    // Set to default alarm update rate
                    defaultConfig: {
                        currentUpdateAlarmRate: 1.75,//1.75 seconds
                        delayRun: 3 // delay 3 seconds to run the xhr request at frist time
                    },

                    // Add additional property for updating alarm rate.
                    getConfig: function () {
                        var config = AlarmSoapWorkerSvc.getConfig.apply(this, arguments);

                        config.currentRate = app.env.get('currentUpdateAlarmRate') ||
                            this.defaultConfig.currentUpdateAlarmRate;
                        config.delayRun = this.defaultConfig.delayRun;

                        if ($rootScope.pauseWorkerXhr) {
                            config.pauseWorkerXhr = $rootScope.pauseWorkerXhr;
                            $rootScope.pauseWorkerXhr = null;
                        }

                        return config;
                    },

                    //Get Body content  to requrest the alarm data.
                    getBodyContent: function () {

                        var paramXML = "<GetUpdatesJson  xmlns=\"http://rockwell.com/\">";
                        paramXML += "<clientId>" + clientID + "</clientId>";
                        paramXML += "<areaPath>" + "" + "</areaPath>";
                        paramXML += "</GetUpdatesJson>";

                        return paramXML;
                    },

                    onsuccess: function (data) {
                        data = AlarmSoapWorkerSvc.onsuccess.apply(this, arguments);
                        if (this.worker && this.worker.employer) {
                            this.worker.employer.onsuccess(data);
                        }

                    },

                    onerror: function (err, data) {
                        if (this.worker && this.worker.employer) {
                            this.worker.employer.onerror(err, data);
                        }
                    }
                });


                $rootScope.$on('app:toggleLoadingStatus', function (event, /*boolean*/ isLoading) {
                    AlarmService.getUpdatesJsonAsync.call('pause', isLoading);
                });


                return {
                    getUpdatesJsonAsync: AlarmService.getUpdatesJsonAsync,
                    alarmJsonAcknowledgeSvc:  AlarmService.alarmJsonAcknowledgeSvc,
		    alarmJsonShelveSvc:  AlarmService.alarmJsonShelveSvc
                };

            }
        ]
    });

