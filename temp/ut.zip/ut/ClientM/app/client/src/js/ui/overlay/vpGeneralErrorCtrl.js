// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('appModule')

/**
 * @ngdoc controller
 * @module appModule
 * @name appModule.vpGeneralErrorCtrl
 * @description this controller is used to display the  general error .
 */

.controller('vpGeneralErrorCtrl', [
    '$scope',
    'config',
    function ($scope, config) {
        'use strict';

        var buttons = (function () {
            if (config.buttons && config.buttons.length) {
                return config.buttons;
            }

            // if buttons are not defined, use default settings (close, home)
            return [{
                "label": "Close",
                "action": "close"
            }];
        })();

        $scope.clickAction = function () {
            $scope.$close();
        };

        $scope.content = {
            "title": config.title,
            "confirmationDesc": config.confirmationDesc,
            "details": config.details,
            "buttons": buttons
        };
    }
]);