// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.
/*global angular, app*/
'use strict';
angular.module('appModule')
    .controller('vpAlarmAcknowledgeOverlayCtrl', [
        '$scope',
        'config',
        function ($scope,config) {
            var COMMENT_MAX_LENGTH = 512;
            $scope.AlarmName = config.AlarmName;
            $scope.CommentMaxLength = COMMENT_MAX_LENGTH;
            $scope.CommentDefault= "";
            $scope.acknowledge = function() {
                var comments = document.getElementById("commentsTxt").value;
                $scope.$close({
                    AckComment: comments
                });
            };
            $scope.close = function() {
                $scope.$dismiss('cancel');
            };
        }
    ]);
