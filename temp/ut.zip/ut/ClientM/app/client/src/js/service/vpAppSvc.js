// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app, initParams, initMobileErrors*/
/*jshint sub:true*/
angular.module('vpServiceModule')

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpAppSvc
 * @description this service will provide information about application.
 */

.factory('vpAppSvc', [
    '$injector',
    '$window',
    function ($injector, $window) {
        "use strict";
        var appstarted = false;

        return {
            bootupFramework: function (app, presets) {
                app.util = $injector.get('vpAppUtilSvc');
                app.env = this.createEnv(presets);
                app.state = this.initStates();

                this.doPreChecking();
                appstarted = false;
            },

            doPreChecking: function () {
                var pass = !app.bootupError;

                if (pass) {
                    if (!app.env.get('noSniffing') && !app.util.detectDeviceBrowser()) {
                        app.env.sets({
                            bootErrTitle: 'InvalidDeviceBrowserHeader',
                            bootErrMsg: 'InvalidDeviceBrowser'
                        });

                        pass = false;
                    }
                }

                if (!pass) {
                    if (!/\#\/bootUpError\b/i.test(location.hash)) {
                        var vpRouterSvc = $injector.get('vpRouterSvc');
                        vpRouterSvc.transitionTo('bootUpError', null, {location:'replace'});
                    }
                }

                return pass;
            },

            startupApp: function (app) {
				if (!app.util.isCookiesEnable()) {
                    app.util.displayCookieDisabledErrorPage();
					return false;
                }
                if(appstarted) {
                    return true;
                }

                var vpMessagerSvc = $injector.get('vpMessagerSvc');
                var vpWorkerSvc = $injector.get('vpWorkerSvc');
                var clientID = this.getClientID();

                app.env.set('clientID', clientID);
                app.topMessager = vpMessagerSvc.createWindowMessager($window, {
                    "clientID": clientID,
                    'initParams': app.env.get('initParams')
                });

                var alarmUpdateMgrSvc = $injector.get('vpAlarmUpdateManagerSvc');
                app.topMessager.setShared('vpAlarmUpdateManagerSvc', alarmUpdateMgrSvc);

                var _workerMessager = vpMessagerSvc.createWorkerMessager();
                vpWorkerSvc.registerWorkers(_workerMessager);
                vpMessagerSvc.connect(app.topMessager, _workerMessager);
                appstarted = true;

                return vpWorkerSvc.runSet('startup');
            },
            initStates: function () {
                var States = {
                    init: 1,
                    loading: 2,
                    loaded: 3,
                    running: 4
                };

                var _state = States.init;
                return {
                    set: function (state) {
                        if (angular.isString(state) && state in States) {
                            _state = States[state];
                        }

                        return _state;
                    },

                    isLoaded: function () {
                        return _state === States.loaded;
                    },

                    now: function () {
                        return _state;
                    }
                };
            },

            createEnv: function (presets){
                var vpAppConstSvc = $injector.get('vpAppConstSvc');
                var appConstants = vpAppConstSvc.appConstants;
                var _env = angular.extend(this.parseInitialParameters(), presets);
                var _searches = app.searches = app.util.parseSearchFragments(top.location.search);

                if (_searches.lang) {
                    app.translateSvc.use(_searches.lang);
                }

                _env['lang'] = app.translateSvc.use();

                var scopeMapper = {
                    '$Global' : 'Network',
                    '$Local' : 'Local'
                };

                if ('scope' in _env) {
                    _env.scope = scopeMapper[_env.scope];
                }

                if (!('WebRequestCommandTimeout' in _env)) {
                    _env['WebRequestCommandTimeout'] = appConstants['WEB_REQUEST_DEFAULT_TIMEOUT'];
                } else {
                    if (_env['WebRequestCommandTimeout'] > appConstants['WEB_REQUEST_MAX_TIMEOUT']) {
                        _env['WebRequestCommandTimeout'] = appConstants['WEB_REQUEST_MAX_TIMEOUT'];
                    } else if (_env['WebRequestCommandTimeout'] < appConstants['WEB_REQUEST_MIN_TIMEOUT']) {
                        _env['WebRequestCommandTimeout'] = appConstants['WEB_REQUEST_MIN_TIMEOUT'];
                    }
                }

                return {
                    set: function (key, value) {
                        if (key) {
                            _env[key] = value;
                        }
                    },

                    sets: function(obj) {
                        angular.extend(_env, obj);
                    },

                    get: function (key) {
                        if (key) {
                            return key in _env ? _env[key] : null;
                        } else {
                            return _env;
                        }
                    }
                };
            },

            /**
             * @ngdoc method
             * @name vpServiceModule.vpAppSvc#getClientID
             * @methodOf vpServiceModule.vpAppSvc
             * @param  none
             * @returns {string} clientID
             * @description generate client-side application ID.
             * re-use it via localstorage.
             */
            getClientID: function () {
                var vpDataStoreSvc = $injector.get('vpDataStoreSvc');
                var storeHelper = vpDataStoreSvc.getOfflineStoreHelper();
                var clientID = storeHelper.clientID.load();

                if (!clientID) {
                    clientID = app.util.createClientID();
                }

                return clientID;
            },

            /**
             * @ngdoc method
             * @name vpServiceModule.vpAppSvc#parseInitialParameters
             * @methodOf vpServiceModule.vpAppSvc
             * @param  none
             * @returns {object} object that includes methods to manipulate initial parameters.
             * @description parse initial parameter list from url and save to parameter map.
             * the parameter format: a=1&b=2&c=3
             */
            parseInitialParameters: function () {
                var _initialParams = {},
                    _initParams = initParams ? encodeURI(initParams).replace(/\#/g, "%23") : '',
                    _initMobileErrors = initMobileErrors ? encodeURI(initMobileErrors).replace(/\#/g, "%23") : '';

                    _initialParams['initParams'] = _initParams;
                    _initialParams['initMobileErrors'] = _initMobileErrors;

                if (_initParams.length > 0) {
                    _initParams.split(',').forEach(function (item) {
                        var _it = item.split('=');
                        _initialParams[_it[0]] = decodeURIComponent(_it[1]);
                    });
                }

                if (_initMobileErrors.length > 0) {
                    app.bootupError= true;
                    _initMobileErrors.split(',').forEach(function (item) {
                        var _it = item.split('=');
                        _initialParams[_it[0]] = decodeURIComponent(_it[1]);
                    });
                }

                return _initialParams;
            },

            getProjectVersion: function () {
                var $http = $injector.get('$http');
                var appConst = $injector.get('Const.App');
                var productVersionFile = appConst.productVersionFile;
                return $http.get(productVersionFile);
            }
        };
    }
]);