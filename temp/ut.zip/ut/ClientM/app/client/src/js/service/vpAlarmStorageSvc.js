// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/
/*jshint sub:true*/
angular.module('vpServiceModule')

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpAlarmStorageSvc
 *
 * @description
 * Stores the current sort option and filters settings. So when user switch
 * between views, sort and filters settings could keep unchanged.
 *
 * We don't need to keep the settings when user restart the app, e.g., refresh
 * browser or open a new browser tab, etc.
 */
.factory('vpAlarmStorageSvc', [
  function() {
    'use strict';

    // saved current sort option index
    var sortOptionIndex = 0;

    // saved popup filter options
    // empty string means any value
    var popupFilterExpression = {
      IsAcked:  '',
      IsActive: '',
      Priority: ''
    };

    // saved quick filter option
    var quickFilterExpression = '';

    return {
      getSortOptionIndex: function() {
        return sortOptionIndex;
      },

      setSortOptionIndex: function(index) {
        sortOptionIndex = index;
      },

      getPopupFilterExpression: function() {
        return popupFilterExpression;
      },

      setPopupFilterExpression: function(expr) {
        angular.extend(popupFilterExpression, expr);
      },

      getQuickFilterExpression: function() {
        return quickFilterExpression;
      },

      setQuickFilterExpression: function(expr) {
        quickFilterExpression = expr;
      }
    };
  }
]);
