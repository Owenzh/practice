// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('vpDataSvcModule')

/**
 * @ngdoc service
 * @module vpDataSvcModule
 * @name vpDataSvcModule.vpDataStoreSvc
 * @description this service will provide security related methods.
 * example:
 *  vpDataStoreSvc.getOfflineStore.{get|set|delete}
 *  vpDataStoreSvc.getCacheStore.{get|set|delete}
 */

.factory('vpDataStoreSvc', ['$window', '$injector',
    function ($window, injector) {
        'use strict';

        var caches = {};
        var cacheStore = function (key, isArray) {
            if (!key) {
                return caches;
            }

            var cache = caches[key] = caches[key] || (isArray? [] : {});

            return {
                getStore: function(){
                    return cache;
                },

                clear: function(){
                    cache = caches[key] = isArray ? [] : {};
                }
            };
        };

        var offlineStore = function (sessionOnly) {
            var store;
            if (sessionOnly) {
                store = $window.sessionStorage;
            }

            if (!store) {
				try {
					store = $window.localStorage; 
				}catch(ex){}
            }

            if (!store) {
                return false;
            }

            return {
                serialize: function (value) {
                    return angular.isObject(value) ? JSON.stringify(value) : value;
                },

                deserialize: function (value) {
                    if (typeof value !== 'string') { return undefined; }
                    try { return JSON.parse(value); }
                    catch(e) { return value || undefined; }
                },

                remove: function (key) {
                    store.removeItem(key);
                    return this;
                },

                set: function (key, val, update) {
                    if (!angular.isObject(val)) {
                        update = false;
                    }

                    if (update) {
                        var item = this.get(key);
                        if (item) {
                            angular.extend(item, val);
                            this.set(key, item);
                        }
                    } else {
                        if (val === undefined) {
                            return this.remove(key);
                        }

                        store.setItem(key, this.serialize(val));
                    }

                    return this;
                },

                get: function (key, filterFunc) {
                    var val = this.deserialize(store.getItem(key));

                    if (filterFunc && angular.isFunction(filterFunc)) {
                        val = filterFunc(val);
                    }

                    return val;
                },

                getAll: function () {
                    var ret = {};
                    this.forEach(function (key, val) {
                        ret[key] = val;
                    });

                    return ret;
                },

                forEach: function (callback) {
                    for (var i=0; i<store.length; i++) {
                        var key = store.key(i);
                        callback(key, this.get(key));
                    }

                    return this;
                },

                clear: function () {
                    store.clear();
                    return this;
                }
            };
        };

        return {
            getOfflineStore: offlineStore,
            getOfflineStoreHelper: function () {
                var store = this.getOfflineStore();
                var frameworkConst = injector.get('Const.App.Framework');

                return {
                    clientID: {
                        save: function (newID) {
                            store.set(frameworkConst.clientidKey, {
                                Instances: {
                                    version: frameworkConst.version,
                                    Instance: [{
                                        id: newID,
                                        lastModified: new Date().toLocaleString()
                                    }]
                                }
                            });
                        },

                        /*
                        * retrieve clientID from localStorage.
                        * if exists, return it to client and clear the localstorage
                        * in the future, when client window is closed, the clientID will be written back
                        * to the localstorage.
                        */
                        load: function () {
                            var clientIDValue = store.get(frameworkConst.clientidKey, function(data){
                                data = data && data.Instances && data.Instances.Instance[0];
                                return data && data.id;
                            });

                            if (clientIDValue) {
                                this.save('');
                            }

                            return clientIDValue;
                        }
                    }
                };
            },

            getSessionStore: function () {
                return offlineStore(true);
            },

            getCacheStore: cacheStore
        };
}]);