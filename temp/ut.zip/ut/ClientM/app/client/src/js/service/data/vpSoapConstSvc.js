// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular */
/*jshint sub:true*/

angular.module('vpDataSvcModule')

/**
 * @ngdoc service
 * @module vpDataSvcModule
 * @name vpDataSvcModule.vpSoapConstSvc
 * @description this service  includes all of the predefined constants for vp service.
 */

.factory('vpSoapConstSvc', function () {
    'use strict';

    //=================== vpadminpingserver ===========================================
    var VPAdminPingServer = {};
    var statusCodes = {};
    statusCodes[statusCodes["Success"] = 0] = "Success";
    statusCodes[statusCodes["UnableToLoadApplication"] = 1] = "UnableToLoadApplication";
    statusCodes[statusCodes["UnknownScopeValue"] = 2] = "UnknownScopeValue";
    statusCodes[statusCodes["UnknownApplicationName"] = 3] = "UnknownApplicationName";
    statusCodes[statusCodes["ApplicationHasNotLoaded"] = 4] = "ApplicationHasNotLoaded";
    statusCodes[statusCodes["UnableToOpenApplication"] = 5] = "UnableToOpenApplication";
    statusCodes[statusCodes["DisplaysHaveNotLoaded"] = 6] = "DisplaysHaveNotLoaded";
    statusCodes[statusCodes["InitialDisplayNotProvided"] = 7] = "InitialDisplayNotProvided";
    statusCodes[statusCodes["PublishNotStart"] = 8] = "PublishNotStart";
    statusCodes[statusCodes["PublishInProgress"] = 9] = "PublishInProgress";
    statusCodes[statusCodes["PublishErrorProgressStop"] = 10] = "PublishErrorProgressStop";
    statusCodes[statusCodes["PublishErrorProgressContinue"] = 11] = "PublishErrorProgressContinue";
    statusCodes[statusCodes["PublishCompleted"] = 12] = "PublishCompleted";
    statusCodes[statusCodes["EventListNotAvailable"] = 13] = "EventListNotAvailable";
    statusCodes[statusCodes["WindowsServiceNotAvailable"] = 14] = "WindowsServiceNotAvailable";
    statusCodes[statusCodes["WebServiceNotAvailable"] = 15] = "WebServiceNotAvailable";
    statusCodes[statusCodes["SessionIsCurrentlyInUseByAnotherClient"] = 16] = "SessionIsCurrentlyInUseByAnotherClient";
    statusCodes[statusCodes["SessionIsNotInUse"] = 17] = "SessionIsNotInUse";
    statusCodes[statusCodes["SessionIsAlreadyActive"] = 18] = "SessionIsAlreadyActive";
    statusCodes[statusCodes["SessionHasBeenRenewed"] = 19] = "SessionHasBeenRenewed";
    statusCodes[statusCodes["BackgroundUpdateCouldNotBeCancelled"] = 20] = "BackgroundUpdateCouldNotBeCancelled";
    statusCodes[statusCodes["BackgroundUpdateCurrentlyInProgress"] = 21] = "BackgroundUpdateCurrentlyInProgress";
    statusCodes[statusCodes["LicenseSessionOrClientIDIsNullOrEmpty"] = 22] = "LicenseSessionOrClientIDIsNullOrEmpty";
    statusCodes[statusCodes["LicenseAllInUse"] = 23] = "LicenseAllInUse";
    statusCodes[statusCodes["LicenseAlreadyAssignedForThisSessionAndClientID"] = 24] =
        "LicenseAlreadyAssignedForThisSessionAndClientID";
    statusCodes[statusCodes["NoRunningViewApplication"] = 25] = "NoRunningViewApplication";
    statusCodes[statusCodes["ClientIPAddressNotAvailable"] = 26] = "ClientIPAddressNotAvailable";
    statusCodes[statusCodes["NoLicensesAllocatedForThisClientComputer"] = 27] =
        "NoLicensesAllocatedForThisClientComputer";
    statusCodes[statusCodes["WebServerProtectionFailed"] = 28] = "WebServerProtectionFailed";
    statusCodes[statusCodes["ApplicationNotRunning"] = 29] = "ApplicationNotRunning";
    statusCodes[statusCodes["LoginRequired"] = 30] = "LoginRequired";
    statusCodes[statusCodes["NotImplemented"] = 31] = "NotImplemented";
    statusCodes[statusCodes["NoManifestForApplication"] = 32] = "NoManifestForApplication";
    statusCodes[statusCodes["SecuredObjectNotFound"] = 33] = "SecuredObjectNotFound";
    statusCodes[statusCodes["NotAuthorized"] = 34] = "NotAuthorized";
    statusCodes[statusCodes["SessionHasExpired"] = 35] = "SessionHasExpired";
    statusCodes[statusCodes["SessionNotFound"] = 36] = "SessionNotFound";

    VPAdminPingServer.statusCodes = statusCodes;

    var LicensingStatusCode = {};
    LicensingStatusCode[LicensingStatusCode["Success"] = 0] = "Success";
    LicensingStatusCode[LicensingStatusCode["WindowsServiceNotAvailable"] = 14] = "WindowsServiceNotAvailable";
    LicensingStatusCode["LicenseSessionOrClientIDIsNullOrEmpty"] = 22;
    LicensingStatusCode[22] = "LicenseSessionOrClientIDIsNullOrEmpty";
    LicensingStatusCode[LicensingStatusCode["LicenseAllInUse"] = 23] = "LicenseAllInUse";
    LicensingStatusCode["LicenseAlreadyAssignedForThisSessionAndClientID"] = 24;
    LicensingStatusCode[24] = "LicenseAlreadyAssignedForThisSessionAndClientID";
    LicensingStatusCode[LicensingStatusCode["ApplicationNotRunning"] = 29] = "ApplicationNotRunning";
    LicensingStatusCode[LicensingStatusCode["LoginRequired"] = 30] = "LoginRequired";


    //================================================================================================

    return {
        VPAdminPingServer: VPAdminPingServer,
        LicensingStatusCode: LicensingStatusCode
    };

});