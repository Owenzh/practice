// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, navigator, window*/
/*jshint sub:true, bitwise: false*/

angular.module('vpServiceModule')

.config(['$provide', function ($provide) {
    "use strict";
    $provide.decorator("$q", ['$delegate', function ($delegate) {
        function allSettled(promises) {
            var deferred = $delegate.defer(),
                counter = 0,
                resultsFulfilled = angular.isArray(promises) ? [] : {},
                resultsRejected = angular.isArray(promises) ? [] : {};

            angular.forEach(promises, function (promise, key) {
                counter++;
                $delegate.when(promise).then(function (value) {
                      if (resultsFulfilled.hasOwnProperty(key)) {return;}
                      resultsFulfilled[key] = value;
                      if (!(--counter)) {
                         deferred.resolve([resultsFulfilled, resultsRejected]);
                      }
                }, function(reason) {
                      if (resultsRejected.hasOwnProperty(key)) {return;}
                      resultsRejected[key] = reason;
                      if (!(--counter)) {
                         deferred.resolve([resultsFulfilled, resultsRejected]);
                      }
                });
            });

            if (counter === 0) {
                deferred.resolve([resultsFulfilled, resultsRejected]);
            }

            return deferred.promise;
        }

        $delegate.allSettled = allSettled;
        return $delegate;
    }]);
}])

/**
 * @ngdoc service
 * @module vpServiceModule
 * @name vpServiceModule.vpAppUtilSvc
 * @description this service provide several utility methods for app.
 */

.factory('vpAppUtilSvc', [
    '$injector',
    function($injector) {
        "use strict";

        //Converts XML DOM to "json like" object
        //borrowed from viewpointHTML5
        function xML2jsobj(node) {
            var data = {};

            // element attributes
            var c, cn;
            var isFirefox = navigator.userAgent.search('Firefox') !== -1;
            if (node.hasAttributes()) {
                for (c = 0; cn = node.attributes[c],cn; c++) {
                    xml2Add(cn.name, cn.value, data);
                }
            }

            // child elements
            if (node.hasChildNodes()) {
                for (c = 0; cn = node.childNodes[c], cn; c++) {
                    if (cn.nodeType === 1) {
                        if (isFirefox &&
                            (cn.nodeName === "GetUpdatesResult" || cn.nodeName === "strDatasets")
                        ) {
                            xml2Add(cn.nodeName, cn.textContent, data);
                        } else {
                            if (cn.childNodes.length === 1 && cn.firstChild.nodeType === 3) {
                                // text value
                                xml2Add(cn.nodeName, cn.firstChild.nodeValue, data, cn);
                            } else if (cn.childNodes.length === 1 && cn.firstChild.nodeType === 4) {
                                // text value
                                xml2Add(cn.nodeName, cn.firstChild.wholeText, data, cn);
                            } else {
                                // sub-object
                                xml2Add(cn.nodeName, xML2jsobj(cn), data);
                            }
                        }
                    }
                }
            }

            return data;
        }

        // append a value
        function xml2Add(name, value, data, cn) {
            if (name === "string") {
                name = "Text";
            }

            if (data[name]) {
                if (data[name].constructor !== Array) {
                    data[name] = [data[name]];
                }
                data[name][data[name].length] = value;
            } else {
                data[name] = value;

                if (cn && name === "V" && cn.attributes[0]) {
                    try  {
                        var type = cn.attributes[0].value.replace("xsd:", "");
                        data["V_Type"] = type;
                    } catch (e) {
                        data["V_Type"] = "";
                    }
                }
            }
        }



        function createClientID(){
            var s = [];
            var hexDigits = "0123456789abcdef";

            for (var i = 0; i < 36; i++) {
                s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
            }

            s[14] = "4";  // bits 12-15 of the time_hi_and_version field to 0010
            s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);
            s[8] = s[13] = s[18] = s[23] = "-";
            return  s.join("");
        }

        function getTopWinLocationSvc () {
            function updateTopLocation(url, replace) {
                try {
                    top.history[replace ? 'replaceState' : 'pushState'](null, '', url);
                } catch (e) {
                    top.location[replace ? 'replace' : 'assign'](url);
                }
            }

            return {
                removeTopLocationErrorMsg: function () {
                    updateTopLocation(top.location.href.replace(/&?\breason=\d+/i,''), true);
                },

                update: function (newUrlFragment) {
                    var newUrl = '';
                    var loc = top.location;
                    var href = loc.href;

                    newUrlFragment = newUrlFragment || "#";

                    if (loc.hash.length) {
                        newUrl = href.replace(loc.hash, newUrlFragment);
                    } else {
                        newUrl = href + newUrlFragment;
                    }

                    updateTopLocation(newUrl, true);
                },

                updateOld: function (newUrlFragment, isHash, preChar) {
                    var newUrl = '';
                    var loc = top.location;
                    var href = loc.href;

                    if (isHash) {
                        newUrlFragment = newUrlFragment || "#";

                        if (loc.hash.length) {
                            newUrl = href.replace(loc.hash, newUrlFragment);
                        } else {
                            newUrl = href + newUrlFragment;
                        }
                    } else {
                        preChar = preChar || 'route';
                        newUrlFragment = newUrlFragment ?  ('?' + preChar + '=' + newUrlFragment) : '';
                        var locsearch = loc.search;

                        if (locsearch.length) {
                            newUrl = href.replace(locsearch, newUrlFragment);
                        } else {
                            newUrl = href + newUrlFragment;
                        }
                    }

                    updateTopLocation(newUrl, true);
                }
            };
        }



        /*
            * desktop os: windows only.
            * desktop browser:  chrome (no version limited) (IE11+ should be an option,but not in FRS.)
            * mobile os: android 4.4, ios 8, windows 8.1
            * mobile browser: chrome 40+, safari on ios8, ie11+ on windows 8.1
        */
        function detectDeviceBrowser() {
            var pass = true;
            var ua = navigator.userAgent.toLowerCase();
            var isOpera = !!window.opera || ua.indexOf(' opr/') >= 0;
            var isChrome = !!window.chrome && !isOpera;

            var windowKernelVersion = ua.match(/windows\s+(?:nt|phone)\s+([\d\.]+)/i);
            windowKernelVersion = windowKernelVersion && parseFloat(windowKernelVersion[1]);

            if (windowKernelVersion) {
                var isIE11 = !(window.ActiveXObject) && ("ActiveXObject" in window);

                if (/\btouch\b/i.test(ua)) {  //Surface
                    pass = isIE11;
                    if (/windows\s+phone/i.test(ua)) {
                        //windows iphone
                        pass = pass && windowKernelVersion >= 8.1;
                    } else {
                        //Surface
                        pass = pass && windowKernelVersion >= 6.2;
                    }
                } else {
                    pass = isChrome || isIE11;
                }
            } else if (/(iphone|ipad)/i.test(ua)) {
                var iosVersion = ua.match(/os\s+([\d\_]+)/i);
                iosVersion = iosVersion && parseFloat(iosVersion[1].replace('_','.'));
                pass = iosVersion >= 8;
            } else {
                var androidVersion =  parseFloat(ua.slice(ua.indexOf("android")+8));
                var chromeVersion = isChrome && ua.match(/chrom(?:e|ium)\/([0-9]+)\./);

                chromeVersion = chromeVersion && parseFloat(chromeVersion[1]);
                pass = androidVersion >= 4.4 && chromeVersion >= 40;
            }

            return pass;
        }

        //we use response.status == 0 as the symbol of network disconnection
        //need to investigate furthermore.
        function detectNetworkIsOffline(url, timeout) {
            var $http = $injector.get('$http');
            timeout = timeout || $http.defaults.timeout || 5000;

            var rndSuffix = Date.now();
            if (url.indexOf('?') >= 0) {
                url += '&' + rndSuffix;
            } else {
                url += '?' + rndSuffix;
            }

            return $http.head(url, {
                timeout: timeout
            }).then(function() {
                return {
                    isOffline: false
                };

            })["catch"](function(error) {
                return {
                    isOffline: error.status === 0,
                    timeout: Date.now() - rndSuffix >= timeout
                };
            });
        }

        /*
        *  from: a=x&b=y&c=z
        *  to: {a:'x',b:'y',c:'z'}
        */
        function parseSearchFragments (strSearch, needDecode) {
            if (!strSearch || !angular.isString(strSearch)) {
                return false;
            }

            strSearch = strSearch.replace(/^\?/,''); //strip leading '?'

            var fragments = {};
            strSearch.split('&').forEach(function (item) {
                var _it = item.split('=');
                fragments[_it[0]] = needDecode ? decodeURIComponent(_it[1]) : _it[1];
            });

            return fragments;
        }
		function currentBrowser() {
			var _userAgent = "";
			var _browserName = "";
			return{
				IsEdgeBrowser: function () {
					if (navigator.userAgent.search('Edge') !== -1) {
						return true;
					}
					return false;
				},
				IsWin10IE: function(){
					if (navigator.userAgent.search('Windows NT 10.0;') !== -1 && document.documentMode !== undefined) {
						return true;
					}
					return false;
				},
				browserName: function () {
					if (_userAgent == "")
						_userAgent = navigator.userAgent;
					if (_browserName != "")
						return _browserName;
					if (_userAgent.search('Firefox') !== -1)
						_browserName = 'Firefox';
					else if (_userAgent.search('Edge') !== -1)
						_browserName = 'Edge';
					else if (_userAgent.search('Chrome') !== -1)
						_browserName = 'Chrome';
					else if (document.documentMode !== undefined)
						_browserName = 'IE';
					else if (_userAgent.search('Safari') !== -1)
						_browserName = 'Safari';
					else
						_browserName = 'unknown';
					return _browserName;
				}
			}
		}
		function isCookiesEnable() {
			try {
				var cookieEnabled;
				if ((typeof navigator.cookieEnabled == "undefined") || currentBrowser().IsEdgeBrowser() || currentBrowser().IsWin10IE()) {
					document.cookie = "testcookie";
					cookieEnabled = (document.cookie.indexOf("testcookie") != -1) ? true : false;
				}else {
					cookieEnabled = (navigator.cookieEnabled) ? true : false;
				}
				return (cookieEnabled);
			}catch (_) {
				return false;
			}
		}
		function displayCookieDisabledErrorPage() {
            var _rootScope = $injector.get("$rootScope");
            _rootScope.$emit('app:displayErrorPage', 'cookiesDisable');
            _rootScope.showLoading = false;
            return false;
        }
		
        return {
            xmlToJson: xML2jsobj,
            createClientID: createClientID,
            detectDeviceBrowser: detectDeviceBrowser,
            detectNetworkIsOffline: detectNetworkIsOffline,
            parseSearchFragments: parseSearchFragments,
            topWinLocationSvc: getTopWinLocationSvc(),
			isCookiesEnable: isCookiesEnable,
			displayCookieDisabledErrorPage: displayCookieDisabledErrorPage
        };
    }
])

//my simplified sanitize service
//to avoid including ng-sanitize service which is not necessary now.
.factory('$sanitize', [
    function() {
        "use strict";
        return function(html){
            return html;
        };
    }
]);

