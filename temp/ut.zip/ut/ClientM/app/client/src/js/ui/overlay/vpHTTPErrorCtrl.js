// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular*/

angular.module('appModule')

/**
 * @ngdoc controller
 * @module appModule
 * @name appModule.vpHTTPErrorCtrl
 * @description this controller is used to display the  http error .
 */

.controller('vpHTTPErrorCtrl', [
    '$scope',
    'config',
    '$state',
    function ($scope, config, $state) {
        'use strict';

        $scope.retryAction = function () {
            $scope.$close(true);
        };

        $scope.homeAction = function () {
            $state.go('home');
        };

        $scope.content = {
            "title": config.title,
            "confirmationDesc": config.confirmationDesc
        };
    }
]);