/*global angular*/
(function() {
  'use strict';

  /**
   * @ngdoc directive
   * @module vpDirectiveModule
   * @name vpDirectiveModule.directive:vpAlarmPopupFilter
   *
   * @description
   * This directive is to add some functionalities to MFT's `ra-item-filter` directive, in order to
   * meet our mobile alarm's requirement.
   *
   * It should be used on the parent element of a `ra-item-filter` directive.
   * 
   * # New features
   *
   * 1. The filter icon is clickable. It will show a popup filter when clicked.
   *
   * According to mobile alarm design, when click filter icon, a popup filter will be shown.
   * Currently, there're 3 dropdown select: "ACK Status", "State" or "Priority" on the overlay.
   * User could use it to do an accurate filtering.
   *
   * 2. Filter icon colors should be able to reflect the new added popup filter.
   *
   * When any of the popup filter option is applied, the filter icon should in `filtered-state` state.
   *
   * @element ANY
   * @scope
   * @param {expression} vpAlarmPopupFilter Expression to evaluate upon click
   */
  angular.module('vpDirectiveModule')
    .directive('vpAlarmPopupFilter', vpAlarmPopupFilterDirective);

  vpAlarmPopupFilterDirective.$inject = ['$rootScope'];

  function vpAlarmPopupFilterDirective($rootScope) {
    return {
      scope: {
        onClick: '&vpAlarmPopupFilter'
      },
      link: function($scope, $element, $attrs) {
        var FILTER_ACTIVE_CSS_CLASS = 'vp-filtered-state';

        var $filterIconSpan = $('.input-group-addon', $element[0]);

        var unwatchFilterChanged = $rootScope.$on('vp.alarm.popupFilterChanged', updateFilterIconStatus);
        $filterIconSpan.on('click', $scope.onClick);

        $scope.$on('$destroy', function() {
          $filterIconSpan.off('click', $scope.onClick);
          unwatchFilterChanged();
        });

        function updateFilterIconStatus(evt, isFilterApplied) {
          if (isFilterApplied) {
            $filterIconSpan.addClass(FILTER_ACTIVE_CSS_CLASS);

          } else {
            $filterIconSpan.removeClass(FILTER_ACTIVE_CSS_CLASS);
          }
        }
      }
    };
  }
})();
