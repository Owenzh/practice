// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

angular.module('vpDataSvcModule')

/**
 * @ngdoc service
 * @module vpDataSvcModule
 * @name vpDataSvcModule.vpAdminPingDataSvc
 * @description this service will communicate with adminping soap server to
 * manipulate ftvp administration related data.
 */

.provider('vpAdminPingDataSvc', function () {
    'use strict';

    this.$get = [
        '$http',
        '$q',
        'vpErrorHandlerSvc',
        'vpSoapSvc',
        'vpSoapConstSvc',
        function ($http, $q, vpErrorHandlerSvc, vpSoapSvc, vpSoapConstSvc) {
            var AdminPingSoapWorkerSvc = vpSoapSvc.WebworkerSoapServiceBase.extend({
                soapEndPoint: '/FTVP/VPAdminPingServer/Service.asmx'
            });

            var AdminPingSoapSvc = vpSoapSvc.SoapServiceBase.extend({
                soapEndPoint: '/FTVP/VPAdminPingServer/Service.asmx'
            });

            var AdminPingServices = {};
            AdminPingServices.licenseDaemon = AdminPingSoapWorkerSvc.extend({
                name: 'GetCurrentStatus',
                defaultConfig: {
                    currentStatusPingRate: 10
                },

                getBodyContent: function () {
                    var sessionID = app.env.get('SessionID');
                    var clientID = app.env.get('clientID');

                    return "<GetCurrentStatus xmlns=\"http://tempuri.org/\">" +
                           "<sessionID>" + sessionID + "</sessionID>" +
                           "<clientID>" + clientID + "</clientID>" +
                           "</GetCurrentStatus>";
                },

                getConfig: function () {
                    var config = AdminPingSoapWorkerSvc.getConfig.apply(this, arguments);

                    config.currentRate = app.env.get('CurrentStatusPingRate') ||
                        this.defaultConfig.currentStatusPingRate;

                    return config;
                },

                checkServerStatus: function (data) {
                    return data && data.GetCurrentStatusResult;
                },

                onsuccess: function (data) {
                    data = AdminPingSoapWorkerSvc.onsuccess.apply(this, arguments);
                    if(this.worker && this.worker.employer) {
                        this.worker.employer.onsuccess(data);
                    }

                },

                onerror: function (err, data) {
                    if(this.worker && this.worker.employer) {
                        this.worker.employer.onerror(err, data);
                    }
                }
            });

            AdminPingServices.resetSessionTimeout = AdminPingSoapSvc.extend({
                name: 'ResetSessionTimeout',
                //resultTagName: 'ResetSessionTimeoutResult',

                getBodyContent: function () {
                    var sessionID = app.env.get('SessionID');
                    var clientID = app.env.get('clientID');

                    return  "<ResetSessionTimeout xmlns=\"http://tempuri.org/\">" +
                            "<sessionID>" + sessionID + " </sessionID >" +
                            "<clientID>" + clientID + " </clientID >" +
                            "</ResetSessionTimeout>";
                },

                onsuccess: function (data) {
                    data = AdminPingSoapSvc.onsuccess.apply(this, arguments);
                    return data.ResetSessionTimeoutResult;
                }
            });

            return {
                licenseDaemon: AdminPingServices.licenseDaemon,
                getServiceConsts: function () {
                    return vpSoapConstSvc.VPAdminPingServer;
                },
                resetSessionTimeout: function () {
                    AdminPingServices.resetSessionTimeout.call();
                }
            };
        }
    ];
});