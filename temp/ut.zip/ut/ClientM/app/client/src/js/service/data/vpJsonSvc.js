// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app, $*/

angular.module('vpDataSvcModule')

/**
 * @ngdoc service
 * @module vpDataSvcModule
 * @name vpDataSvcModule.vpJsonSvc 
 * @description this service will communicate with alarm server to manipulate ftvp alarm related data.
 */
.factory('vpJsonSvc', [
    '$http',
    '$q',
    'vpSecuritySvc',
    'vpAppUtilSvc',
    function($http, $q, vpSecuritySvc, vpAppUtilSvc){
 	  'use strict';

       var JsonServiceBase =  {
            caches: {},
            method: 'POST', // or 'GET'
            name: '', //service name
            dataType: 'json',
            extend: function (obj) {
                var subService = angular.extend({}, this, obj);
                subService.parent = this;
                return subService;
            },
            super: function (methodName, baseClass) {
                baseClass = baseClass || this.parent;

                if (!baseClass && this !== JsonServiceBase) {
                    baseClass = JsonServiceBase;
                }

                var method = baseClass && baseClass[methodName];
                var res = false;

                if (method && angular.isFunction(method)) {
                    res = method.bind(this);
                }

                return res;
            },

            getBody: function (args) {
                var body = '';

                if (this.method === 'POST') {
                    body = this.getBodyContent(args);
                }

                return body;
            },

            getRequestHeader: function () {
                return {
                    'Content-Type': 'application/json; charset=utf-8'
                };
            },

            onsuccess: function (data) {
                return data;
            },

            onerror: function (data) {
                var error = {};

                if (!data) {
                    error.Message = "fail to fetch data";
                }
            
                return {
                    error: error
                };
            },


            call: function (args) {
                if (!this.jsonEndPoint || !this.name) {
                    return false;
                }

                var result = $q.defer();
                var that = this;
                var reqHeaders = this.getRequestHeader();

                $http({
                    url: this.jsonEndPoint,
                    method: this.method,
                    data: this.getBody(args),
                    headers: reqHeaders
                })
                .success(function(data) {
                    if (that.onsuccess) {
                        data = that.onsuccess.apply(that, arguments);
                    }

                    if (data === false) {
                        data = {
                            error: {
                                Message: "fail to fetch data"
                            }
                        };
                    }

                    if (data.error) {
                        result.reject(data);
                    } else {
                        result.resolve(data);
                    }
                })

                .error(function(data) {
                    if (that.onerror) {
                        data = that.onerror.apply(that, arguments);
                    }

                    result.reject(data);
                });
        
                return result.promise;
            }

       };


       var WebWorkerJsonSvcHandlers = {

       	    bind: function (ctx) {
                this.context = ctx;
            },

            handleMessage: function (e) {
                var data = e.data;
                var that = this.context;
                var cmd = data.cmd;

                var method = that['on' + cmd];
                if (method && angular.isFunction(method)) {
                    data = method.call(that, data.data);
                }


            },

            handleError: function(e) {
                var that = this.context;
                that.worker.handleError.call(that.worker, e.data);
            }

       };


       var WebworkerJsonServiceBase = JsonServiceBase.extend({
            setWebWorker: function (worker) {
                var workerInst = worker.getInstance();
                this.worker = worker;
                this.dfd = $q.defer();

                WebWorkerJsonSvcHandlers.bind(this);
                worker.setConfigData(this.getConfig());

                workerInst.addEventListener('message',
                    WebWorkerJsonSvcHandlers.handleMessage.bind(WebWorkerJsonSvcHandlers));
                workerInst.addEventListener('error',
                    WebWorkerJsonSvcHandlers.handleError.bind(WebWorkerJsonSvcHandlers));
            },

            getConfig: function () {
                var reqHeaders = this.getRequestHeader();

                return {
                    url: this.jsonEndPoint,
                    name: this.name,
                    method: this.method,
                    data: this.getBody(),
                    headers: reqHeaders,
                    dataType: this.dataType
                };
            },

            checkServerStatus: function () {
                return true;
            },

            onsuccess: function (data) {
                var body = data.body;

                if (!body) {
                    this.onerror(new Error('error while fetching data.'), data);
                    body = false;

                } else {
                    body = this.super('onsuccess', JsonServiceBase)(body);
                }

                body.serverStatus = this.checkServerStatus(body);
                return body;
            },

            onerror: function (err , data) {
                return {
                    error: err,
                    data: data
                };
            },

            call: function (cmd, data) {
                if (!this.jsonEndPoint || !this.name || !this.worker || !cmd) {
                    return false;
                }

                this.worker.invoke(cmd, data);
            },

            terminate: function () {
                this.worker.terminate();
            }
        });

        return {
            JsonServiceBase: JsonServiceBase,
            WebworkerJsonServiceBase: WebworkerJsonServiceBase
        };

 }]);