// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

angular.module('vpFilterModule')

    .filter('vpAlarmBlank', function() {
        return function(value) {
            if(value && value !== ""){
                return value;
            }
            else{
                return '\u00A0 '
            }
        }
    });
