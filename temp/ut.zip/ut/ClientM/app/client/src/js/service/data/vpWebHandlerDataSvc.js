// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*global angular, app*/

angular.module('vpDataSvcModule')

/**
 * @ngdoc service
 * @module vpDataSvcModule
 * @name vpDataSvcModule.vpWebHandlerDataSvc
 * @description this service will communicate with admin soap server to manipulate ftvp administration related data.
 */

.factory('vpWebHandlerDataSvc', [
    '$http',
    '$q',
    function($http, $q) {
        "use strict";
        var apiBase = '/FTVP/VPWebHandler.ashx';


        function buildAPIUrl(params){
            var urlSuffix = [];
            if (params) {
                for (var key in params) {
                    if (params.hasOwnProperty(key)) {
                        urlSuffix.push(key + '=' + encodeURIComponent(params[key]));
                    }
                }
            }

            urlSuffix = urlSuffix.join('&');
            urlSuffix = urlSuffix.length ? ('?' + urlSuffix) : '';
            return encodeURI(apiBase + urlSuffix);
        }

        function webHandlerSvcBase(options,onsuccess, onerror){
            var apiUrl = buildAPIUrl(options);
            var timeoutDefer = $q.defer();
            var timeout = false;
            var timeoutValue = app.env.get('WebRequestCommandTimeout');
            var result = $q.defer();

            setTimeout(function() {
                timeout = true;
                timeoutDefer.resolve();
            }, timeoutValue * 1000 + 1);

            $http.get(apiUrl, {
                timeout: timeoutDefer.promise
            })

            .success(function(data, status) {
                if (onsuccess && angular.isFunction(onsuccess)) {
                    data = onsuccess.apply(null, [data, status, apiUrl]);
                }

                result.resolve(data);
            })

            .error(function(data, status) {
                if (onerror && angular.isFunction(onerror)) {
                    data = onerror.apply(null, [data, status, apiUrl, timeout]);
                }

                result.reject(data);
            });

            return result.promise;
        }

        return {
            /**
             * @ngdoc method
             * @name vpDataSvcModule.vpWebHandlerDataSvc#getClientLicense
             * @methodOf vpDataSvcModule.vpWebHandlerDataSvc
             * @param  none
             * @returns {Object} Promise
             * @description  get license information
             */

            getClientLicense: function() {
                var SessionID = app.env.get('SessionID');
                var ClientID = app.env.get('clientID');

                return webHandlerSvcBase({
                    op: 'getclientlicense',
                    isReadOnlyActivation: true,
                    SessionID: SessionID,
                    ClientID: ClientID
                }, function onsuccess(data, status, apiUrl) {
                    return {
                        status: status,
                        response: data,
                        RequestUri: apiUrl
                    };
                }, function onerror(data, status, apiUrl, timeout) {
                    return {
                        status: status,
                        response: data,
                        RequestUri: apiUrl,
                        timeout: timeout
                    };
                });
            },

            /**
             * @ngdoc method
             * @name vpDataSvcModule.vpWebHandlerDataSvc#returnClientLicense
             * @methodOf vpDataSvcModule.vpWebHandlerDataSvc
             * @param  none
             * @returns {Object} Promise
             * @description  get license information
             */

            returnClientLicense: function(clientOnly) {
                var SessionID = app.env.get('SessionID');
                var ClientID = app.env.get('clientID');

                return webHandlerSvcBase({
                    op: 'returnclientlicense',
                    isReadOnlyActivation: true,
                    SessionID: SessionID,
                    ClientID: (clientOnly ? ClientID : "")
                });
            }
        };
    }
]);